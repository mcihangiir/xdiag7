# Profesyonel OBD2 Teşhis Uygulaması Mimari Özeti

## 1. Uygulama Ekran Akışı
- **Dashboard (Ana Hub):** Kullanıcının OBD cihazına bağlandığı ve diagnostik menülerini ("Akıllı Teşhis", "Yerel Teşhis - Marka Seçimi", "Canlı Veri/Dashboard", "Özel Fonksiyonlar") gördüğü merkez ekran.
- **Marka / Yerel Teşhis Ekranı:** Araçların Avrupa, Asya, Amerika, Çin tabları altında gruplandığı ve manuel olarak sistem taramasına geçiş yapılabilen ekran.
- **Akıllı Teşhis (Auto-Detect):** VIN okuyup `doc_toyota_database.json` gibi veritabanlarından eşleşen aracı direkt bularak tam sistem 0-100% taraması baştlatan ekran.
- **Sistem Modülleri ve Canlı Veri:** İlgili ECU (Örn. Toyota EFI/Denso) seçildikten sonra DTC'leri Listeleme (DTC Okuma/Silme) veya Parametre İzleme (Live Data - Misfire, O2 sensörleri vb.) yapılan ekran.
- **Special Functions (Özel Fonksiyonlar):** Güvenlik duvarını geçerek "Active Test" (örn: Enjektör Kapatma, VVT-i testi) gibi işlemlerin tetiklendiği bölüm.

## 2. Auto-Detection (Akıllı Tanımlama) Algoritması
1. **Bağlantı Kurulumu:** `BluetoothOBDManager` ELM327 çipi ile Bluetooth SPP üzerinden soket açar.
2. **Protokol Tespiti:** Cihazlara `AT SP 0` (Auto Protocol) gönderilerek CAN Bus hızı veya K-Line protokolü belirlenir (Toyota'nız için ISO 15765-4 Yüksek Hızlı CAN).
3. **VIN Okuması:** OBD2 Mode 09 PID 02 (`0902` komutu) kullanılarak Şasi numarası çekilir (örn: `SB1KT31E30E039202`).
4. **Kalibrasyon ID Tespiti:** Mode 09 PID 04 (`0904`) ile ECU yazılım revizyonu okunur.
5. **Veritabanı Eşleştirmesi:** Alınan VIN'in WMI (ilk 3 hane) kısmına göre Marka bulunur (`SB1` = Toyota Europe). Daha sonra tüm veritabanı (önce yerel JSON, yoksa bulut API) taranıp ilgili aracın ECU adresleri UI tarafına basılır.

## 3. Toyota 1NR-FE İçin Önemli Enhanced PID Örnekleri
Standart Mode 01 PID'lerinin ötesine geçmek için Toyota'ya özel Mode 21 ve Mode 22 komutları kullanılır.
- **VVT-i Açı İlerlemesi:** `21 44` hex komutu ile okunur.
- **Misfire (Silindir Yanma Kaçırmaları):** `21 3C` gibi Mode 21 komutlarından anlık kaçırmalar izlenebilir.
- **Freeze Frame:** Hata gerçekleştiği andaki ECU anlık durumu Mode 02 PIDs ile alınır.
- **Aktif Test (Enjektör Kill):** `30` modu üzerinden belirli silindirlere "Cut/Kill" komutu yollanır (Örn: `30 01 00` -> 1. Silindir Enjektör Kapat). *Bu sistem `ToyotaAurisSpecialOps.kt` içinde modüllendirilmiştir.*

## 4. Güvenlik Katmanları (Risk Yönetimi)
- **Varsayılan "Read-Only" İlkesi:** Canlı izleme ve hata kodu tarama (Mode 01, 03, 09, 0A) tamamen risksizdir. Sadece okunur işlemler varsayılan olarak serbesttir.
- **Yazılım Voltaj Kontrolü:** Uygulama modül bağlantısı yaparken `AT RV` ile batarya voltajını izler. Eğer 12.1V altındaysa uyarı verip Active Test veya Hata Kodu silme işlemine kısıt getirir ki ECU bağlantı sırasında voltaj kaybından çökmesin.
- **Riskli İşlem Uyarıları:** Enjektör testleri, fren bakım modları gibi işlemler öncesi AlertDialog ile son kullanıcıya kalıcı etkiler bırakabileceği ve "Sadece Rölanti'de" yapılması gerektiği uyarısı dayatılır.

## 5. Uygulama Mimari Özeti (MVVM + Compose)
- Mimaride `DiangosticViewModel.kt` tüm durumların (OBD bağlantısı, aktif araç, hata kodları) StateFlow'da yönetildiği merkezdir.
- Room Veritabanı (`AppDatabase.kt`) diagnostik geçmiş kayıtları ve sürüş logları (Trip Computer) için kullanılır.
- Kotlin Coroutines ve asenkron I/O yapıları yardımıyla OBD cihazına gönderilen HEX komutların dönüşleri bloklamadan okutulur.
