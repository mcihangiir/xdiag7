package com.example

import android.os.Bundle


import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.DiagnosticViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    val viewModel: DiagnosticViewModel = viewModel()

                    NavHost(
                        navController = navController,
                        startDestination = Screen.Splash.route
                    ) {
                        composable(Screen.Splash.route) {
                            SplashScreen(
                                onNavigateToDashboard = {
                                    navController.navigate(Screen.Dashboard.route) {
                                        popUpTo(Screen.Splash.route) { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable(Screen.Dashboard.route) {
                            DashboardScreen(
                                viewModel = viewModel,
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }
                        composable(Screen.IntelligentScan.route) {
                            IntelligentDiagnoseScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onViewFaults = { navController.navigate(Screen.FaultCodes.route) },
                                onNavigateToVinScanner = { navController.navigate(Screen.VinScanner.route) }
                            )
                        }
                        composable(Screen.LocalDiagnose.route) {
                            LocalDiagnoseScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onViewFaults = { navController.navigate(Screen.FaultCodes.route) },
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }
                        composable(Screen.ModuleInspect.route) { backStackEntry ->
                            val systemId = backStackEntry.arguments?.getString("systemId") ?: ""
                            ModuleInspectScreen(
                                viewModel = viewModel,
                                systemId = systemId,
                                onBack = { navController.popBackStack() },
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }
                        composable(Screen.SpecialFunctions.route) {
                            SpecialFunctionsScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }
                        composable(Screen.History.route) {
                            HistoryReportsScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onViewStatistics = { navController.navigate(Screen.Statistics.route) },
                                onNavigateToServiceHistory = { vin ->
                                    viewModel.selectVinPair(vin)
                                    navController.navigate(Screen.ServiceHistory.route)
                                },
                                onNavigateToTechDashboard = { navController.navigate(Screen.TechDashboard.route) }
                            )
                        }
                        composable(Screen.SoftwareUpdate.route) {
                            SoftwareUpdateScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.Settings.route) {
                            SettingsScreen(
                                viewModel = viewModel,
                                onNavigateToBleInspector = { navController.navigate(Screen.BleGattInspector.route) },
                                onNavigateToProtocolGuide = { navController.navigate(Screen.DeviceProtocolGuide.route) },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.BleGattInspector.route) {
                            BleGattInspectorScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.DeviceProtocolGuide.route) {
                            DeviceProtocolGuideScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.UnifiedConnection.route) {
                            UnifiedConnectionScreen(
                                viewModel = viewModel,
                                onNavigateToProtocolGuide = { navController.navigate(Screen.DeviceProtocolGuide.route) },
                                onNavigateToBleInspector = { navController.navigate(Screen.BleGattInspector.route) },
                                onNavigateToDeviceProbe = { navController.navigate(Screen.DeviceProbe.route) },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.SmartConnect.route) {
                            SmartConnectScreen(
                                viewModel = viewModel,
                                onNavigateToRecordingGuide = { navController.navigate(Screen.RecordingGuide.route) },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.RecordingGuide.route) {
                            RecordingGuideScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.UserInfo.route) {
                            UserInfoScreen(
                                onNavigate = { route -> navController.navigate(route) },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.VciManager.route) {
                            SmartConnectScreen( 
                                viewModel = viewModel,
                                onNavigateToRecordingGuide = { navController.navigate(Screen.RecordingGuide.route) },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.AdasCalibration.route) {
                            AdasCalibrationScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.FaultCodes.route) {
                            FaultCodesScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.LiveChart.route) {
                            LiveChartScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onNavigateToMultiChart = { navController.navigate(Screen.MultiChart.route) },
                                onNavigateToGauge = { navController.navigate(Screen.GaugeDashboard.route) }
                            )
                        }
                        composable(Screen.MultiChart.route) {
                            MultiChartScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onNavigateToLiveChart = { navController.navigate(Screen.LiveChart.route) }
                            )
                        }
                        composable(Screen.GaugeDashboard.route) {
                            GaugeDashboardScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onNavigateToLiveChart = { navController.navigate(Screen.LiveChart.route) }
                            )
                        }
                        composable(Screen.AiDiagnose.route) {
                            AiDiagnoseScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.MisfireMonitor.route) {
                            com.example.ui.screens.MisfireMonitorScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.DeviceProbe.route) {
                            com.example.ui.screens.DeviceProbeScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.Statistics.route) {
                            StatisticsScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.VinScanner.route) {
                            VinScannerScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.FreezeFrame.route) {
                            FreezeFrameScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.PidSelection.route) {
                            PidSelectionScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.OilReset.route) {
                            OilResetScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.SasCalibration.route) {
                            SasCalibrationScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.BmsReset.route) {
                            BmsResetScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.Tpms.route) {
                            TpmsScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.ImReadiness.route) {
                            ImReadinessScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onNavigateToDriveCycle = { navController.navigate(Screen.DriveCycle.route) }
                            )
                        }
                        composable(Screen.Mode06.route) {
                            Mode06Screen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.DataRecording.route) {
                            DataRecordingScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.DriveCycle.route) {
                            DriveCycleScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onNavigateToMonitors = {
                                    navController.popBackStack()
                                    navController.navigate(Screen.ImReadiness.route)
                                }
                            )
                        }
                        composable(Screen.VoltageAnalysis.route) {
                            VoltageAnalysisScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.ServiceHistory.route) {
                            ServiceHistoryScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.TechDashboard.route) {
                            TechDashboardScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(Screen.RepairInfo.route) {
                            RepairInfoScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() },
                                onNavigate = { route -> navController.navigate(route) }
                            )
                        }
                    }
                }
            }
        }
    }
}
