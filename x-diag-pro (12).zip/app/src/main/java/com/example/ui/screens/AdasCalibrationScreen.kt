package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdasCalibrationScreen(onBack: () -> Unit) {
    var currentStep by remember { mutableStateOf(0) } // 0: Hazırlık, 1: Hizalama, 2: Kalibrasyon, 3: Tamam
    var alignmentProgress by remember { mutableStateOf(0f) }
    var isCalibrating by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ADAS KALİBRASYON WIZARD", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            when (currentStep) {
                0 -> {
                    // Hazırlık Ekranı
                    Icon(Icons.Default.FilterCenterFocus, contentDescription = null, tint = MatcoRed, modifier = Modifier.size(80.dp).align(Alignment.CenterHorizontally))
                    Text("ÖN KAMERA & RADAR KALİBRASYONU", fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
                    Text(
                        "Bu işlem, ön cam değişimi, kamera onarımı veya hizalama kayması sonrası zorunludur. Araç düz bir zeminde ve motor rölantide olmalıdır.",
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp,
                        color = MatcoTextMuted
                    )

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, MatcoCardBorder)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("ÖN KOŞULLAR", fontWeight = FontWeight.Bold, color = MatcoRed)
                            BulletItem("Araç düz ve teraziye alınmış zeminde olsun")
                            BulletItem("Direksiyon tam düz konumda kilitli olsun")
                            BulletItem("Lastik basınçları fabrika değerlerinde olsun")
                            BulletItem("Kalibrasyon hedef tahtası aracın tam ortasına yerleştirilsin")
                        }
                    }

                    Button(
                        onClick = { currentStep = 1 },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                    ) {
                        Text("KALİBRASYONU BAŞLAT", fontWeight = FontWeight.Bold)
                    }
                }

                1 -> {
                    // Hizalama Ekranı
                    Text("HEDEF TAHTASI HİZALAMA", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MatcoRed)
                    Text("Kameradan gelen canlı görüntüde hedef tahtası ile kırmızı artı tam örtüşene kadar lazeri ayarlayın.", textAlign = TextAlign.Center, fontSize = 12.sp)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.Black)
                            .border(3.dp, MatcoRed, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Kamera hedef hizalama kutusu
                        Box(modifier = Modifier.size(180.dp).border(4.dp, Color.Red.copy(0.7f), RoundedCornerShape(8.dp)))

                        // Canlı tarama çizgisi
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .background(Color.Red.copy(0.8f))
                                .offset(y = (alignmentProgress * 200 - 100).dp)
                        )
                    }

                    Button(
                        onClick = {
                            scope.launch {
                                currentStep = 2
                                isCalibrating = true
                                alignmentProgress = 0f
                                while (alignmentProgress < 1f) {
                                    delay(40)
                                    alignmentProgress += 0.012f
                                }
                                delay(600)
                                currentStep = 3
                                isCalibrating = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text("HEDEF HİZALANDI → KALİBRE ET", fontWeight = FontWeight.Bold)
                    }
                }

                2 -> {
                    // Kalibrasyon Progress
                    CircularProgressIndicator(
                        progress = { alignmentProgress },
                        modifier = Modifier.size(110.dp).align(Alignment.CenterHorizontally),
                        strokeWidth = 10.dp,
                        color = MatcoRed
                    )
                    Text("KALİBRASYON YAPILIYOR...", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("${(alignmentProgress * 100).toInt()}% Tamamlandı", fontSize = 14.sp, color = MatcoAccent)
                }

                3 -> {
                    // Başarı Ekranı
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(90.dp).align(Alignment.CenterHorizontally))
                    Text("ADAS KALİBRASYONU BAŞARILI!", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF10B981))
                    Text("Kamera ve radar açıları ECU’ya kaydedildi. Araç artık güvenli sürüş modunda.", textAlign = TextAlign.Center)

                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                    ) {
                        Text("WIZARD’I KAPAT")
                    }
                }
            }
        }
    }
}

@Composable
private fun BulletItem(text: String) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp).padding(top = 2.dp))
        Text(text, fontSize = 12.sp, color = MatcoTextMuted)
    }
}