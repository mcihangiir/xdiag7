package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.DiagnosticViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingGuideScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val recordedTraffic by viewModel.recordedTraffic.collectAsState()
    
    LaunchedEffect(Unit) {
        viewModel.startTrafficRecording()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Öğrenme Modu", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.stopTrafficRecording(); onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Şimdi cihazınızı normal şekilde kullanın:", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("1. Orijinal yazılımı (veya başka bir OBD uygulamasını) açmayın. Biz otomatik tarayacağız.")
                    Text("2. Aşağıdaki 'TÜM BİLİNEN KOMUTLARI DENE' butonuna basın.")
                    Text("3. Yeşil renkli (yanıt gelen) satırı bulunca üzerine tıklayıp profil oluşturun.")
                }
            }

            Button(
                onClick = { viewModel.testAllKnownCommands() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("🧪 TÜM BİLİNEN KOMUTLARI SIRAYLA DENE")
            }

            Text("Canlı Trafik:", fontWeight = FontWeight.Bold)

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().background(Color(0xFF1E1E1E)),
                contentPadding = PaddingValues(8.dp)
            ) {
                items(recordedTraffic) { event ->
                    val isRx = event.direction == "ALINAN"
                    val textColor = if (isRx) Color(0xFF10B981) else Color(0xFF3B82F6)
                    val prefix = if (isRx) "←" else "→"
                    
                    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Text("$prefix ${event.asciiAttempt.ifEmpty { "(ASCII Yok)" }}", color = textColor, fontSize = 14.sp)
                        Text("HEX: ${event.hexData}", color = Color.Gray, fontSize = 10.sp)
                        if (isRx && event.asciiAttempt.isNotBlank()) {
                            TextButton(onClick = { viewModel.createProfileFromResponse(event) }) {
                                Text("✅ BU YANITI TEMEL AL")
                            }
                        }
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { /* Export File Logic Here (e.g. create intent) */ },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("📤 Dışa Aktar")
                }
                Button(
                    onClick = { viewModel.stopTrafficRecording(); onBack() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("BİTTİ")
                }
            }
        }
    }
}
