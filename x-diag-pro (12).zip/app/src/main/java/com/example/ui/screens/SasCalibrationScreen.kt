package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.SasState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SasCalibrationScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val sasState by viewModel.sasCalibrationState.collectAsState()
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()
    val rawSpeed by viewModel.liveSpeed.collectAsState()

    DisposableEffect(Unit) {
        onDispose {
            viewModel.resetSasCalibration()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DIREKSIYON AÇI KALİBRASYONU (SAS)", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.CompassCalibration,
                contentDescription = null,
                tint = MatcoRed,
                modifier = Modifier.size(64.dp)
            )

            Text(
                "SAS DIREKSİYON AÇI SENSÖRÜ KALİBRASYONU",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )

            Text(
                "Açı sensörünü sıfırlamak için direksiyon simidini düz konuma getirin ve aracı tamamen durdurun. Kontak açık ve motor çalışmıyorken işlemi başlatabilirsiniz.",
                color = MatcoTextMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Live status & checklist
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("GÜVENLİK KONTROLLERİ", color = MatcoAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Akü Gerilim Durumu (>12.1V):", fontSize = 12.sp, color = Color.White)
                        Text(
                            "${String.format("%.2f", batteryVoltage)} V",
                            fontWeight = FontWeight.Bold,
                            color = if (batteryVoltage >= 12.1f) Color(0xFF10B981) else Color.Red,
                            fontSize = 12.sp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Sürüş Hızı (Duruş Gereklidir):", fontSize = 12.sp, color = Color.White)
                        Text(
                            "$rawSpeed km/h",
                            fontWeight = FontWeight.Bold,
                            color = if (rawSpeed == 0) Color(0xFF10B981) else Color.Red,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            when (val current = sasState) {
                is SasState.Idle -> {
                    Button(
                        onClick = { viewModel.startSasCalibration() },
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("SENSÖR SIFIRLAMAYI BAŞLAT", fontWeight = FontWeight.Bold)
                    }
                }
                is SasState.CheckingPrerequisites -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(color = MatcoRed)
                        Text("Sistem parametreleri ve akü voltaj stabilizasyonu kontrol ediliyor...", fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                    }
                }
                is SasState.WaitingForCenter -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.NotificationImportant, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(48.dp))
                        Text(
                            "DİKKAT: Lütfen direksiyon simidini düz (merkez) noktaya hizalayın! Sistem 2 saniye içinde kalibrasyona başlayacaktır.",
                            fontSize = 13.sp,
                            color = Color(0xFFFBBF24),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )
                        LinearProgressIndicator(color = Color(0xFFFBBF24), modifier = Modifier.fillMaxWidth().height(6.dp))
                    }
                }
                is SasState.Sending -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(color = MatcoRed)
                        Text("SAS kalibrasyon komutları ve açı adaptasyonu ECU'ya yazılıyor (ATSH 7B0)...", fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                    }
                }
                is SasState.Success -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, Color(0xFF10B981)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("İŞLEM BAŞARIYLA TAMAMLANDI!", fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                            Text("Direksiyon açı sensörü sıfır noktası ve rotasyonel sapma ölçüm aralığı başarıyla kalibre edildi.", fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                            Button(
                                onClick = onBack,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                            ) {
                                Text("TAMAM")
                            }
                        }
                    }
                }
                is SasState.Failed -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, Color.Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("İŞLEM BAŞARISIZ OLDU", fontWeight = FontWeight.Bold, color = Color.Red)
                            Text(current.reason, fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                            Button(
                                onClick = { viewModel.resetSasCalibration() },
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                            ) {
                                Text("YENİDEN DENE")
                            }
                        }
                    }
                }
            }
        }
    }
}
