package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.DiagnosticViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntelligentDiagnoseScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onViewFaults: () -> Unit,
    onNavigateToVinScanner: () -> Unit
) {
    val isScanning by viewModel.isScanning.collectAsState()
    val isConnected by viewModel.isConnected.collectAsState()
    val scanProgress by viewModel.scanProgress.collectAsState()
    val currentSystem by viewModel.currentScanningSystem.collectAsState()
    val scannedSystems by viewModel.scannedSystemsResult.collectAsState()
    val vehicle by viewModel.activeVehicle.collectAsState()

    val totalDtcCount = remember(vehicle) {
        vehicle?.systems?.sumOf { it.troubleCodes.size } ?: 0
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AKILLI TEŞHİS", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!isConnected) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, MatcoCardBorder),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BluetoothDisabled,
                                contentDescription = null,
                                tint = MatcoRed,
                                modifier = Modifier.size(64.dp)
                            )
                            Text(
                                text = "BAĞLANTI KESİK",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MatcoRed
                            )
                            Text(
                                text = "Akıllı teşhis taraması gerçekleştirmek için aktif bir OBD2 / VCI bluetooth cihaz bağlantısına sahip olmanız gerekmektedir. Lütfen ana sayfaya dönüp cihazı bağlayın.",
                                fontSize = 13.sp,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = onBack,
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("ANA SAYFAYA DÖN VE BAĞLAN", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else if (vehicle == null && !isScanning && scannedSystems.isEmpty()) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Icon(Icons.Default.Memory, contentDescription = null, tint = MatcoRed, modifier = Modifier.size(80.dp))
                        Text("VCI Bağlanıyor...", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Araç VIN kodu otomatik olarak ODB üzerinden okunacak.", color = MatcoTextMuted)
                        Button(
                            onClick = { viewModel.startIntelligentScan() },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                            modifier = Modifier.fillMaxWidth(0.8f).height(50.dp)
                        ) {
                            Text("OTOMATİK TARAMA BAŞLAT")
                        }
                        Button(
                            onClick = onNavigateToVinScanner,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9)),
                            modifier = Modifier.fillMaxWidth(0.8f).height(50.dp)
                        ) {
                            Text("📷 KAMERA İLE VIN TARA")
                        }
                    }
                }
            } else if (isScanning) {
                Card(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            progress = { scanProgress },
                            modifier = Modifier.size(120.dp),
                            color = MatcoRed,
                            strokeWidth = 8.dp,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(currentSystem, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MatcoAccent)
                        Text("%${(scanProgress * 100).toInt()}", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else if (vehicle != null) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MatcoRed)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("${vehicle?.make} ${vehicle?.model}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                                Text("VIN: ${vehicle?.vin}", fontSize = 12.sp, color = Color.White)
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        val scanFailureReason by viewModel.scanFailureReason.collectAsState()
                        if (scanFailureReason != null) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                                border = BorderStroke(1.dp, MatcoRed),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Error, tint = Color.White, contentDescription = null, modifier = Modifier.size(24.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text("TARAMA GÜVENİLİR DEĞİL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(scanFailureReason!!, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                                        Text("Bu sonuç KAYDEDİLMEDİ.", color = Color.White, fontSize = 11.sp, 
                                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, modifier = Modifier.padding(top = 4.dp))
                                    }
                                }
                            }
                        } else {
                            Card(
                                onClick = onViewFaults,
                                colors = CardDefaults.cardColors(containerColor = if (totalDtcCount > 0) Color.Red.copy(0.15f) else Color(0xFF10B981).copy(0.15f)),
                                border = BorderStroke(1.dp, if (totalDtcCount > 0) Color.Red else Color(0xFF10B981)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Icon(
                                            imageVector = if (totalDtcCount > 0) Icons.Default.Error else Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = if (totalDtcCount > 0) Color.Red else Color(0xFF10B981),
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Column {
                                            Text(
                                                text = if (totalDtcCount > 0) "$totalDtcCount Hata Kodu Tespit Edildi" else "Tüm Sistemler Sağlıklı",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = if (totalDtcCount > 0) "Hata kodlarını görmek ve silmek için tıklayın" else "Hata detay ekranı için tıklayın",
                                                fontSize = 11.sp,
                                                color = MatcoTextMuted
                                            )
                                        }
                                    }
                                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Taranan Sistem Modülleri", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    items(scannedSystems) { system ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, MatcoCardBorder)
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(system.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(system.abbreviation, fontSize = 12.sp, color = MatcoTextMuted)
                                }
                                if (system.errorCount > 0) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.Default.Error, null, tint = Color.Red, modifier = Modifier.size(16.dp))
                                        Text("${system.errorCount} Hata", color = Color.Red, fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF10B981))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
