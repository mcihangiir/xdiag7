package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.ConnectionState
import com.example.data.ConnectionType
import com.example.ui.theme.MatcoRed
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnifiedConnectionScreen(
    viewModel: DiagnosticViewModel,
    onNavigateToProtocolGuide: () -> Unit,
    onNavigateToBleInspector: () -> Unit,
    onNavigateToDeviceProbe: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedMode by remember { mutableStateOf<String?>(null) }
    
    val bleConnectionState by viewModel.bleConnectionState.collectAsState()
    val bleScannedDevices by viewModel.bleScannedDevices.collectAsState()
    
    val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    val blePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            viewModel.scanForBleDevices()
        } else {
            Toast.makeText(context, "BLE taraması için izin vermelisiniz.", Toast.LENGTH_LONG).show()
        }
    }
    
    fun requestScan() {
        val hasPermissions = requiredPermissions.all { perm ->
            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
        }
        if (hasPermissions) {
            viewModel.scanForBleDevices()
        } else {
            blePermissionLauncher.launch(requiredPermissions)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bağlantı Yöntemi", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("Cihaz Modu Seçin", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ModeCard("Standart OBD2", "ELM327", selectedMode == "BT_CLASSIC", Modifier.weight(1f)) {
                            selectedMode = "BT_CLASSIC"
                            viewModel.stopBleScanning()
                        }
                        ModeCard("Launch Pro", "XJLDS401", selectedMode == "LAUNCH_PRO", Modifier.weight(1f)) {
                            selectedMode = "LAUNCH_PRO"
                            requestScan()
                        }
                    }
                }
                
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ModeCard("Diğer BLE", "BLE / Özel", selectedMode == "BLE_ELM", Modifier.weight(1f)) {
                            selectedMode = "BLE_ELM"
                            requestScan()
                        }
                        ModeCard("📡 Wi-Fi", "Ağ", selectedMode == "WIFI", Modifier.weight(1f)) {
                            selectedMode = "WIFI"
                            viewModel.stopBleScanning()
                        }
                    }
                }
                
                item {
                    when (selectedMode) {
                        "BT_CLASSIC" -> {
                            var showBluetoothDialog by remember { mutableStateOf(false) }
                            var pairedDevices by remember { mutableStateOf<List<android.bluetooth.BluetoothDevice>>(emptyList()) }
                            val btConnectionState by viewModel.bluetoothOBDManager.connectionState.collectAsState()
                            
                            val btPermissionLauncher = rememberLauncherForActivityResult(
                                ActivityResultContracts.RequestMultiplePermissions()
                            ) { permissions ->
                                if (permissions.values.all { it }) {
                                    try {
                                        pairedDevices = viewModel.bluetoothOBDManager.getPairedDevices()
                                        showBluetoothDialog = true
                                    } catch (e: SecurityException) {
                                        Toast.makeText(context, "Cihazlar alınamadı", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                            
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Klasik Bluetooth SPP", fontWeight = FontWeight.Bold)
                                    Text("Eski nesil veya standart ELM327 adaptörleri.", fontSize = 12.sp, color = Color.DarkGray)
                                    Spacer(Modifier.height(12.dp))
                                    Button(
                                        onClick = {
                                            val hasPermissions = requiredPermissions.all { perm ->
                                                ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
                                            }
                                            if (hasPermissions) {
                                                try {
                                                    pairedDevices = viewModel.bluetoothOBDManager.getPairedDevices()
                                                    showBluetoothDialog = true
                                                } catch (e: SecurityException) {
                                                    Toast.makeText(context, "Cihazlar alınamadı", Toast.LENGTH_LONG).show()
                                                }
                                            } else {
                                                btPermissionLauncher.launch(requiredPermissions)
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("EŞLEŞMİŞ CİHAZLARI GÖSTER")
                                    }
                                }
                            }
                            
                            if (showBluetoothDialog) {
                                AlertDialog(
                                    onDismissRequest = { showBluetoothDialog = false },
                                    title = { Text("Eşleşmiş Cihazlar", fontWeight = FontWeight.Bold, color = MatcoRed) },
                                    text = {
                                        if (pairedDevices.isEmpty()) {
                                            Text("Cihaz bulunamadı.\nTelefonun Ayarlarından eşleştirme yapın.")
                                        } else {
                                            LazyColumn {
                                                items(pairedDevices.size) { index ->
                                                    val device = pairedDevices[index]
                                                    ListItem(
                                                        headlineContent = { Text(device.name ?: "Bilinmeyen") },
                                                        supportingContent = { Text(device.address) },
                                                        trailingContent = {
                                                            Button(onClick = {
                                                                viewModel.connectToDevice(device)
                                                                showBluetoothDialog = false
                                                            }) { Text("BAĞLAN") }
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        TextButton(onClick = { showBluetoothDialog = false }) { Text("İPTAL") }
                                    }
                                )
                            }
                        }
                        "WIFI" -> {
                            var localWifiHost by remember { mutableStateOf("192.168.0.10") }
                            var localWifiPort by remember { mutableStateOf("35000") }
                            val wifiConnectionState by viewModel.wifiOBDManager.connectionState.collectAsState()
                            
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Wi-Fi Bağlantısı", fontWeight = FontWeight.Bold)
                                    Text("Telefonunuzu cihazın Wi-Fi ağına bağlayın.", fontSize = 12.sp, color = Color.DarkGray)
                                    Spacer(Modifier.height(12.dp))
                                    OutlinedTextField(
                                        value = localWifiHost,
                                        onValueChange = { localWifiHost = it },
                                        label = { Text("IP Adresi") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = localWifiPort,
                                        onValueChange = { localWifiPort = it },
                                        label = { Text("Port") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    Button(
                                        onClick = { viewModel.connectViaWifi(localWifiHost, localWifiPort.toIntOrNull() ?: 35000) },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("WI-FI İLE BAĞLAN")
                                    }
                                }
                            }
                        }
                        "LAUNCH_PRO" -> {
                            val hardwareVoltage by viewModel.launchConnector.hardwareVoltage.collectAsState()
                            val hardwareFirmware by viewModel.launchConnector.hardwareFirmware.collectAsState()
                            val deviceSerial by viewModel.launchConnector.deviceSerial.collectAsState()
                            
                            var connectionResultMessage by remember { mutableStateOf<String?>(null) }
                            var showRetryWithRecordingButton by remember { mutableStateOf(false) }
                            val coroutineScope = rememberCoroutineScope()

                            Text("XJLDS401 Telemetri Paneli", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(Modifier.height(8.dp))
                            
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MatcoRed.copy(alpha = 0.1f)),
                                border = BorderStroke(1.dp, MatcoRed),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("📡 Multiplexer MCU Analizi", fontWeight = FontWeight.Bold, color = MatcoRed)
                                    Spacer(Modifier.height(8.dp))
                                    Text("Voltaj: ${String.format("%.1f", hardwareVoltage)}V", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                    Text("S/N: $deviceSerial", fontSize = 12.sp)
                                    Text("F/W: $hardwareFirmware", fontSize = 12.sp)
                                }
                            }
                            Spacer(Modifier.height(16.dp))

                            if (connectionResultMessage != null) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = if (showRetryWithRecordingButton) Color.Red.copy(alpha = 0.1f) else Color.Green.copy(alpha = 0.1f)),
                                    border = BorderStroke(1.dp, if (showRetryWithRecordingButton) Color.Red else Color.Green),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text(if (showRetryWithRecordingButton) "Bağlantı Başarısız" else "Bağlantı İşlemi", fontWeight = FontWeight.Bold)
                                        Text(connectionResultMessage!!, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                                        if (showRetryWithRecordingButton) {
                                            Spacer(Modifier.height(8.dp))
                                            Button(
                                                onClick = onNavigateToBleInspector,
                                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("🎬 TRAFİK KAYDEDİCİ İLE ANALİZ ET")
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(16.dp))
                            }
                            
                            Button(onClick = { requestScan() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)) {
                                Text("PRO CİHAZLARI TARAMAYA BAŞLA")
                            }

                            if (bleScannedDevices.isNotEmpty()) {
                                Spacer(Modifier.height(16.dp))
                                bleScannedDevices.forEach { device ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(device.name, fontWeight = FontWeight.Bold)
                                                Text(device.address, fontSize = 12.sp, color = Color.Gray)
                                            }
                                            Button(
                                                onClick = {
                                                    viewModel.startLaunchTelemetry()
                                                    coroutineScope.launch {
                                                        connectionResultMessage = "Bağlanıyor..."
                                                        showRetryWithRecordingButton = false
                                                        val gattConnected = viewModel.bleCore.connectAndDiscover(device.device)
                                                        if (!gattConnected) {
                                                            connectionResultMessage = "Cihaza bağlanılamadı"
                                                            showRetryWithRecordingButton = false
                                                        } else {
                                                            val connected = viewModel.bleProprietaryManager.connect()
                                                            if (!connected) {
                                                                connectionResultMessage = "DS401 GATT seviyesinde görüldü ama hiçbir komuta yanıt vermedi. Bu cihaz farklı bir protokol kullanıyor olabilir. BLE Trafik Kaydedici ile cihazın ham protokolünü analiz edebilirsiniz."
                                                                showRetryWithRecordingButton = true
                                                            } else {
                                                                connectionResultMessage = "Bağlandı!"
                                                                viewModel.switchConnectionType(com.example.data.ConnectionType.BLE)
                                                                viewModel.connectAdapter(true)
                                                            }
                                                        }
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                                            ) {
                                                Text("DOĞRULA & BAĞLAN")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        "BLE_ELM" -> {
                            Text("BLE Cihaz Taraması", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(Modifier.height(8.dp))
                            
                            if (bleConnectionState == ConnectionState.SCANNING) {
                                Text("Taranıyor...", color = Color.Gray)
                            } else if (bleScannedDevices.isEmpty()) {
                                Button(onClick = { requestScan() }) { Text("YENİDEN TARA") }
                            }
                            
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                bleScannedDevices.forEach { device ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text(device.name, fontWeight = FontWeight.Bold)
                                                Text(device.address, fontSize = 12.sp, color = Color.Gray)
                                            }
                                            Button(onClick = { 
                                                viewModel.connectToBleDeviceSmart(device.device) 
                                            }) {
                                                Text("BAĞLAN")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        "BLE_PROP" -> {
                            val prefs = context.getSharedPreferences("ble_proprietary_config", Context.MODE_PRIVATE)
                            val serviceUuid = prefs.getString("service_uuid", "")
                            
                            if (serviceUuid.isNullOrBlank()) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MatcoRed.copy(alpha = 0.1f)),
                                    border = BorderStroke(1.dp, MatcoRed),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("⚠️ Özel Protokol Yapılandırması Eksik", fontWeight = FontWeight.Bold, color = MatcoRed)
                                        Text("Lütfen cihazınızın protokolünü analiz edin ve UUID bilgilerini kaydedin.", fontSize = 12.sp)
                                        Spacer(Modifier.height(12.dp))
                                        Button(onClick = onNavigateToProtocolGuide, colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)) {
                                            Text("🔬 PROTOKOL ANALİZ REHBERİ")
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedButton(onClick = onNavigateToBleInspector) {
                                            Text("🔧 GATT İNCELEYİCİSİ")
                                        }
                                    }
                                }
                            } else {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("Manuel Ayarlar Kaydedilmiş:", fontWeight = FontWeight.Bold)
                                        Text("Servis: $serviceUuid\n" +
                                             "Yazma: ${prefs.getString("write_uuid", "")}\n" +
                                             "Bildirim: ${prefs.getString("notify_uuid", "")}", 
                                             fontSize = 10.sp, color = Color.DarkGray)
                                        
                                        Spacer(Modifier.height(12.dp))
                                        Button(onClick = { requestScan() }, modifier = Modifier.fillMaxWidth()) {
                                            Text("YAKINDAKİ CİHAZLARI TARA VE BAĞLAN")
                                        }
                                        
                                        if (bleScannedDevices.isNotEmpty()) {
                                            Spacer(Modifier.height(16.dp))
                                            bleScannedDevices.forEach { device ->
                                                OutlinedButton(
                                                    onClick = { viewModel.connectToBleDeviceSmart(device.device) },
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text("${device.name} (${device.address})")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            // DESTEK VE SİMÜLASYON YARDIMCILARI (BAĞLANTI SORUNU YAŞAYANLAR İÇİN)
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                
                Text(
                    text = "⚙️ BAĞLANTI & DONANIM DESTEK SEÇENEKLERİ", 
                    fontSize = 11.sp, 
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val report = viewModel.getVciLogsReport()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            val clip = android.content.ClipData.newPlainText("XDiagLogs", report)
                            clipboard.setPrimaryClip(clip)
                            
                            try {
                                val sendIntent = android.content.Intent().apply {
                                    action = android.content.Intent.ACTION_SEND
                                    putExtra(android.content.Intent.EXTRA_TEXT, report)
                                    type = "text/plain"
                                }
                                val shareIntent = android.content.Intent.createChooser(sendIntent, "Bağlantı Teşhis Loglarını Paylaş")
                                context.startActivity(shareIntent)
                                Toast.makeText(context, "Bağlantı raporu kopyalandı ve paylaşım başlatıldı!", Toast.LENGTH_LONG).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Loglar panoya kopyalandı! Sohbet ekranından bana gönderebilirsiniz.", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("📤 CIHAZ LOGU GÖNDER", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Button(
                    onClick = onNavigateToDeviceProbe,
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.CompassCalibration, contentDescription = null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("🔬 DS401 FİZİKSEL KANITLI TANI VE BAĞLANTI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
            
            // Alt durum çubuğu
            Surface(shadowElevation = 8.dp, color = MaterialTheme.colorScheme.surface) {
                Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center) {
                    val statusText = when (bleConnectionState) {
                        ConnectionState.SCANNING -> "🔍 Taranıyor..."
                        ConnectionState.CONNECTING -> "🔗 Bağlanıyor..."
                        ConnectionState.CONNECTED -> "✅ Bağlandı"
                        ConnectionState.ERROR -> "❌ Bağlantı Hatası"
                        ConnectionState.DISCONNECTED -> "Bağlı Değil"
                        else -> ""
                    }
                    Text(statusText, fontWeight = FontWeight.Bold, color = if(bleConnectionState == ConnectionState.CONNECTED) Color(0xFF10B981) else Color.Gray)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModeCard(iconTitle: String, subtitle: String, isSelected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(iconTitle, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if(isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, fontSize = 10.sp, color = if(isSelected) MaterialTheme.colorScheme.onPrimaryContainer else Color.Gray)
        }
    }
}
