package com.example.ui.components

import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import java.io.ByteArrayOutputStream

@Composable
fun SignatureDialog(
    onDismissRequest: () -> Unit,
    onSignatureCaptured: (String) -> Unit
) {
    // Collect coordinates in continuous offsets
    val pointsList = remember { mutableStateListOf<Offset?>() }
    var size by remember { mutableStateOf(IntSize.Zero) }

    Dialog(onDismissRequest = onDismissRequest) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MatcoCard),
            border = BorderStroke(1.dp, MatcoCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Teknisyen Onay İmzası",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp
                )
                Text(
                    text = "Rapor geçerliliği için parmağınızla imzalayın.",
                    color = MatcoTextMuted,
                    fontSize = 11.sp
                )

                // The signature field canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(Color(0xFF161616), RoundedCornerShape(8.dp))
                        .border(BorderStroke(1.dp, MatcoCardBorder), RoundedCornerShape(8.dp))
                        .onGloballyPositioned { size = it.size }
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    pointsList.add(offset)
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    pointsList.add(change.position)
                                },
                                onDragEnd = {
                                    pointsList.add(null) // indicate line break
                                }
                            )
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        for (i in 0 until pointsList.size - 1) {
                            val p1 = pointsList[i]
                            val p2 = pointsList[i + 1]
                            if (p1 != null && p2 != null) {
                                drawLine(
                                    color = Color.White,
                                    start = p1,
                                    end = p2,
                                    strokeWidth = 6f,
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // OUTLINED TEMİZLE button
                    OutlinedButton(
                        onClick = {
                            pointsList.clear()
                        },
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, MatcoRed),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MatcoRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("TEMİZLE", fontSize = 12.sp)
                    }

                    // FILLED KAYDET button
                    Button(
                        onClick = {
                            if (size.width > 0 && size.height > 0) {
                                val bitmapWidth = size.width
                                val bitmapHeight = size.height
                                val bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888)
                                val canvas = android.graphics.Canvas(bitmap)
                                
                                // Draw solid white background for high contrast signature placement in official PDFs
                                canvas.drawColor(android.graphics.Color.WHITE)
                                
                                val paint = android.graphics.Paint().apply {
                                    color = android.graphics.Color.parseColor("#0F172A") // Premium Navy dark ink
                                    style = android.graphics.Paint.Style.STROKE
                                    strokeWidth = 8f
                                    isAntiAlias = true
                                    strokeCap = android.graphics.Paint.Cap.ROUND
                                    strokeJoin = android.graphics.Paint.Join.ROUND
                                }

                                for (i in 0 until pointsList.size - 1) {
                                    val p1 = pointsList[i]
                                    val p2 = pointsList[i + 1]
                                    if (p1 != null && p2 != null) {
                                        canvas.drawLine(p1.x, p1.y, p2.x, p2.y, paint)
                                    }
                                }

                                val outputStream = ByteArrayOutputStream()
                                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                                val bytes = outputStream.toByteArray()
                                val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                                onSignatureCaptured(base64)
                            } else {
                                onDismissRequest()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("İMZAYI KAYDET", fontSize = 12.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
