package com.example.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.TimelineEvent
import com.example.viewmodel.TimelineEventType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceHistoryScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val vins by viewModel.vehicleVins.collectAsState()
    val selectedVin by viewModel.selectedVin.collectAsState()
    val events by viewModel.timelineEvents.collectAsState()
    val loading by viewModel.timelineLoading.collectAsState()

    var expanded by remember { mutableStateOf(false) }
    var currentFilter by remember { mutableStateOf("Tümü") }

    LaunchedEffect(Unit) {
        viewModel.loadVehicleVins()
    }

    val filteredEvents = remember(events, currentFilter) {
        when (currentFilter) {
            "Hatalar" -> events.filter { it.eventType == TimelineEventType.DTC_APPEARED || it.dtcCodes.isNotEmpty() }
            "Servis" -> events.filter { it.eventType == TimelineEventType.SPECIAL_FUNCTION || it.eventType == TimelineEventType.OIL_RESET || it.eventType == TimelineEventType.DTC_CLEARED }
            "Temiz" -> events.filter { it.dtcCodes.isEmpty() && it.eventType == TimelineEventType.SCAN }
            else -> events
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ARAÇ SERVİS GEÇMİŞİ", fontWeight = FontWeight.Black, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoBlack,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Dropdown Menu section
            Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedVin ?: "Araç Seçin",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Seçili Araç VIN", color = MatcoTextMuted) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                            focusedBorderColor = MatcoAccent,
                            unfocusedBorderColor = MatcoCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.background(MatcoCard)
                    ) {
                        vins.forEach { vinStr ->
                            DropdownMenuItem(
                                text = { Text(vinStr, color = Color.White) },
                                onClick = {
                                    viewModel.selectVinPair(vinStr)
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }

            if (selectedVin.isNullOrEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Lütfen geçmişini görmek için bir araç (VIN) seçiniz.", color = MatcoTextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
                }
            } else if (events.isEmpty() && !loading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Bu araca ait kayıtlı rapor bulunamadı.", color = MatcoTextMuted, textAlign = TextAlign.Center)
                }
            } else {
                // Filters
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Tümü", "Hatalar", "Servis", "Temiz").forEach { filter ->
                        val selected = currentFilter == filter
                        FilterChip(
                            selected = selected,
                            onClick = { currentFilter = filter },
                            label = { Text(filter) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color.Transparent,
                                selectedContainerColor = MatcoRed,
                                labelColor = MatcoTextMuted,
                                selectedLabelColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                borderColor = MatcoCardBorder,
                                selectedBorderColor = MatcoRed,
                                enabled = true,
                                selected = selected
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Chart
                if (events.size > 1 && currentFilter == "Tümü") {
                    MiniHealthChart(events = events)
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Timeline
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)
                ) {
                    items(filteredEvents) { event ->
                        TimelineEventItem(event)
                    }
                }
            }
        }
    }
}

@Composable
fun MiniHealthChart(events: List<TimelineEvent>) {
    // Reverse events to plot chronologically (old -> new)
    val chronologicalEvents = events.sortedBy { it.timestamp }
    if (chronologicalEvents.size < 2) return

    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("SAĞLIK SKORU TRENDİ", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Canvas(
                modifier = Modifier.fillMaxWidth().height(80.dp)
            ) {
                val width = size.width
                val height = size.height

                val points = chronologicalEvents.mapIndexed { idx, point ->
                    val x = if (chronologicalEvents.size > 1) {
                        idx.toFloat() / (chronologicalEvents.size - 1) * width
                    } else width / 2f
                    val y = height - (point.healthScore / 100f * height)
                    Offset(x, y)
                }

                val path = Path().apply {
                    points.forEachIndexed { idx, offset ->
                        if (idx == 0) moveTo(offset.x, offset.y)
                        else lineTo(offset.x, offset.y)
                    }
                }

                drawPath(
                    path = path,
                    color = Color(0xFF6366F1), // Indigo
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )

                points.forEachIndexed { idx, point ->
                    val event = chronologicalEvents[idx]
                    val dotColor = when {
                        event.healthDelta > 0 -> Color(0xFF10B981)
                        event.healthDelta < 0 -> Color(0xFFEF4444)
                        else -> Color.White
                    }
                    drawCircle(
                        color = dotColor,
                        radius = 4.dp.toPx(),
                        center = point
                    )
                }
            }
        }
    }
}

@Composable
fun TimelineEventItem(event: TimelineEvent) {
    var expanded by remember { mutableStateOf(false) }
    
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("tr", "TR"))
    val dateStr = sdf.format(Date(event.timestamp))

    val dotColor = when (event.eventType) {
        TimelineEventType.SCAN -> Color(0xFF9CA3AF)
        TimelineEventType.DTC_APPEARED -> Color(0xFFEF4444)
        TimelineEventType.DTC_RESOLVED -> Color(0xFF10B981)
        TimelineEventType.DTC_CLEARED -> Color(0xFF3B82F6)
        TimelineEventType.SPECIAL_FUNCTION -> Color(0xFFF59E0B)
        TimelineEventType.OIL_RESET -> Color(0xFFF59E0B)
    }

    Row(
        modifier = Modifier.fillMaxWidth().animateContentSize().height(IntrinsicSize.Min)
    ) {
        // Vertical line + Dot column
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxHeight().width(32.dp)
        ) {
            Box(
                modifier = Modifier.padding(top = 8.dp).size(16.dp).clip(CircleShape).background(dotColor).border(2.dp, Color.Black, CircleShape)
            )
            // Vertical line
            Box(
                modifier = Modifier.fillMaxHeight().width(2.dp).background(Color(0xFFEF4444))
            )
        }
        
        Spacer(modifier = Modifier.width(8.dp))

        // Content Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MatcoCard),
            border = BorderStroke(1.dp, MatcoCardBorder),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp).clickable { expanded = !expanded }
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(event.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(dateStr, color = MatcoTextMuted, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sistem Sağlığı: %${event.healthScore}", color = Color.White, fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    if (event.healthDelta > 0) {
                        Text("↑ +${event.healthDelta}%", color = Color(0xFF10B981), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    } else if (event.healthDelta < 0) {
                        Text("↓ ${event.healthDelta}%", color = Color(0xFFEF4444), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("→ Değişmedi", color = MatcoTextMuted, fontSize = 13.sp)
                    }
                }

                if (event.dtcCodes.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    @OptIn(ExperimentalLayoutApi::class)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        event.dtcCodes.forEach { code ->
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFFEF4444).copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                    .border(1.dp, Color(0xFFEF4444).copy(alpha=0.5f), RoundedCornerShape(4.dp))
                            ) {
                                Text(code, color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (expanded) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MatcoCardBorder)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(event.description, color = MatcoTextMuted, fontSize = 13.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}
