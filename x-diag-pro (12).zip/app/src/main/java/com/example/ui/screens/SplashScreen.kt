package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onNavigateToDashboard: () -> Unit
) {
    // Background and theme colors
    val darkBgColor = Color(0xFF0F172A) // Dark blue-grey slate (premium feel)
    val accentRed = Color(0xFFDC2626) // Matco-like deep Red

    // Animations
    val logoScale = remember { Animatable(0.5f) }
    val logoAlpha = remember { Animatable(0.0f) }
    val textAlpha = remember { Animatable(0.0f) }
    var countdownSeconds by remember { mutableStateOf(5) }

    LaunchedEffect(Unit) {
        // Run animations concurrently
        logoScale.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 1200)
        )
    }
    LaunchedEffect(Unit) {
        logoAlpha.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 1000)
        )
        textAlpha.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 1200)
        )
    }

    // Timer effect for 5 seconds countdown
    LaunchedEffect(Unit) {
        for (i in 5 downTo 1) {
            countdownSeconds = i
            delay(1000)
        }
        onNavigateToDashboard()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        darkBgColor,
                        Color(0xFF020617)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            // Recreated circular logo from Emrah Oto
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(260.dp)
                    .scale(logoScale.value)
                    .shadow(16.dp, CircleShape, clip = false)
                    .border(
                        width = 4.dp,
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFFFFD700), // Gold
                                Color(0xFFCD7F32), // Bronze
                                Color(0xFFFFD700)
                            )
                        ),
                        shape = CircleShape
                    )
                    .background(Color.White, CircleShape)
                    .padding(4.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_emrah_logo_1781878443334),
                    contentDescription = "Emrah Oto Logo",
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Subtitle info and style
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "EMRAH OTO",
                    fontWeight = FontWeight.Black,
                    fontSize = 32.sp,
                    color = Color.White,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "ELEKTRİK & KLİMA",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = accentRed,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "PROFESYONEL VE TEKNİK TEŞHİS SİSTEMİ",
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp,
                        color = Color.LightGray,
                        letterSpacing = 1.5.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Bottom loading status with countdown
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CircularProgressIndicator(
                    progress = { 1f - (countdownSeconds / 5f) },
                    color = accentRed,
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(36.dp),
                    trackColor = Color.White.copy(alpha = 0.1f)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Sistem yükleniyor...",
                        color = Color.Gray,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Normal
                    )
                    Text(
                        text = "${countdownSeconds}sn",
                        color = accentRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Skip splash button
                TextButton(
                    onClick = onNavigateToDashboard,
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)
                ) {
                    Text(
                        text = "Hızlı Geç",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
