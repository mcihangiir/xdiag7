package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.AiMessage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiDiagnoseScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val activeVehicle by viewModel.activeVehicle.collectAsState()
    val liveRpm by viewModel.liveRpm.collectAsState()
    val liveSpeed by viewModel.liveSpeed.collectAsState()
    val liveCoolantTemp by viewModel.liveCoolantTemp.collectAsState()
    val liveO2Voltage by viewModel.liveO2Voltage.collectAsState()
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()

    val aiLoading by viewModel.aiAnalysisLoading.collectAsState()
    val aiError by viewModel.aiAnalysisError.collectAsState()
    val conversation by viewModel.aiConversationHistory.collectAsState()

    var showApiKeyDialog by remember { mutableStateOf(false) }
    var apiKeyInput by remember { mutableStateOf(viewModel.getApiKey()) }
    var userMsgText by remember { mutableStateOf("") }

    val listState = rememberLazyListState()

    // Scroll to bottom when conversation size changes or ai loading finishes
    LaunchedEffect(conversation.size, aiLoading) {
        if (conversation.isNotEmpty()) {
            listState.animateScrollToItem(conversation.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI ARAÇ ARIZA ANALİZİ", fontWeight = FontWeight.Black, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        apiKeyInput = viewModel.getApiKey()
                        showApiKeyDialog = true
                    }) {
                        Icon(Icons.Default.Settings, contentDescription = "API Anahtarı Ayarı")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoBlack,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // BÖLÜM 1 — BAĞLAM KARTI
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val vehicle = activeVehicle
                    if (vehicle != null) {
                        Text(
                            text = "${vehicle.year} ${vehicle.make} ${vehicle.model}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        val dtcs = remember(vehicle) { vehicle.systems.flatMap { it.troubleCodes } }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = MatcoRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Aktif DTC Hata Kodu Sayısı: ${dtcs.size}",
                                fontSize = 13.sp,
                                color = MatcoRed,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (dtcs.isNotEmpty()) {
                            Text(
                                text = "Hata Kodları: " + dtcs.take(3).joinToString(", ") { it.code } + if (dtcs.size > 3) "..." else "",
                                fontSize = 11.sp,
                                color = MatcoTextMuted,
                                modifier = Modifier.padding(start = 20.dp, top = 2.dp)
                            )
                        }
                    } else {
                        Text(
                            text = "Seçili aktif araç bulunmuyor.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MatcoRed
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Canlı Ölçüm Verileri: $liveRpm RPM | $liveSpeed km/h | $liveCoolantTemp °C | Akü: $batteryVoltage V",
                            fontSize = 11.sp,
                            color = MatcoAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Bu veriler otomatik analiz için güvenli şekilde AI modeline gönderilecektir.",
                        fontSize = 10.sp,
                        color = MatcoTextMuted
                    )
                }
            }

            // BÖLÜM 2 — SOHBET ALANI (LazyColumn)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                if (conversation.isEmpty() && !aiLoading) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Psychology,
                                contentDescription = null,
                                tint = Color(0xFF6366F1),
                                modifier = Modifier.size(64.dp)
                            )
                            Text(
                                text = "Yapay Zeka Destekli Arıza Teşhisi",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 16.sp,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Gemini AI, aktif hata kodlarınızı ve canlı sensör verilerinizi analiz ederek detaylı bir teşhis ve tamir önerisinde bulunur.",
                                color = MatcoTextMuted,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(conversation) { msg ->
                            val isUser = msg.role == "user"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                            ) {
                                Card(
                                    shape = RoundedCornerShape(
                                        topStart = 16.dp,
                                        topEnd = 16.dp,
                                        bottomStart = if (isUser) 16.dp else 4.dp,
                                        bottomEnd = if (isUser) 4.dp else 16.dp
                                    ),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isUser) MatcoRed else MatcoCard
                                    ),
                                    border = if (isUser) null else BorderStroke(1.dp, MatcoCardBorder),
                                    modifier = Modifier.widthIn(max = 280.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        if (isUser) {
                                            Text(
                                                text = msg.content,
                                                color = Color.White,
                                                fontSize = 14.sp
                                            )
                                        } else {
                                            // Split by lines and highlight headings
                                            val lines = msg.content.split("\n")
                                            lines.forEachIndexed { index, line ->
                                                val isTitle = line.contains("GENEL DEĞERLENDİRME") ||
                                                        line.contains("EN KRİTİK SORUN") ||
                                                        line.contains("OLASI NEDENLER") ||
                                                        line.contains("ÖNERİLEN TAMİR SIRASI") ||
                                                        line.contains("SÜRÜŞ GÜVENLİĞİ") ||
                                                        line.contains("TAHMİNİ TAMİR SÜRESİ")
                                                
                                                if (isTitle) {
                                                    Text(
                                                        text = line,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MatcoAccent,
                                                        fontSize = 14.sp,
                                                        modifier = Modifier.padding(top = if (index > 0) 8.dp else 0.dp)
                                                    )
                                                } else {
                                                    Text(
                                                        text = line,
                                                        color = Color.White,
                                                        fontSize = 13.sp,
                                                        lineHeight = 16.sp
                                                    )
                                                }
                                            }
                                        }
                                        
                                        Spacer(modifier = Modifier.height(4.dp))
                                        
                                        val timeStr = remember(msg.timestamp) {
                                            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                                            sdf.format(Date(msg.timestamp))
                                        }
                                        Text(
                                            text = timeStr,
                                            fontSize = 9.sp,
                                            color = if (isUser) Color.White.copy(alpha = 0.7f) else MatcoTextMuted,
                                            modifier = Modifier.align(Alignment.End)
                                        )
                                    }
                                }
                            }
                        }

                        if (aiLoading) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Start
                                ) {
                                    Card(
                                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 4.dp, bottomEnd = 16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                                        border = BorderStroke(1.dp, MatcoCardBorder),
                                        modifier = Modifier.widthIn(max = 240.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                ThreeDotLoadingAnimation()
                                                Text(
                                                    text = "AI analiz yapıyor...",
                                                    color = MatcoTextMuted,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (aiError != null) {
                            item {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.Red.copy(0.15f)),
                                    border = BorderStroke(1.dp, Color.Red),
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Error, contentDescription = null, tint = Color.Red, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = aiError ?: "Bilinmeyen bir hata",
                                            color = Color.Red,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // BÖLÜM 3 — GİRDİ ALANI
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // İlk analiz butonu (DTC varsa ve konuşma boşsa)
                val vehicle = activeVehicle
                val dtcs = remember(vehicle) { vehicle?.systems?.flatMap { it.troubleCodes } ?: emptyList() }
                if (dtcs.isNotEmpty() && conversation.isEmpty() && !aiLoading) {
                    Button(
                        onClick = { viewModel.performAiAnalysis() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Default.Psychology, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🤖 OTOMATİK ARIZA ANALİZİ YAP",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                    }
                }

                // API Key uyarısı (API key girilmemişse)
                val currentKey = remember(viewModel) { viewModel.getApiKey() }
                if (currentKey.isEmpty() || currentKey == "MY_GEMINI_API_KEY") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFF9800).copy(0.15f)),
                        border = BorderStroke(1.dp, Color(0xFFFF9800)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF9800), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Gemini API Anahtarı eksik! Analiz için lütfen kurun.",
                                    color = Color(0xFFFF9800),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            TextButton(onClick = {
                                apiKeyInput = viewModel.getApiKey()
                                showApiKeyDialog = true
                            }) {
                                Text("GİRİŞ", color = Color(0xFFFF9800), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }

                // Row barındıran Girdi Alanı
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextField(
                        value = userMsgText,
                        onValueChange = { userMsgText = it },
                        placeholder = { Text("AI'ya soru sorun...", fontSize = 13.sp, color = MatcoTextMuted) },
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, MatcoCardBorder, RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp)),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = MatcoCard,
                            unfocusedContainerColor = MatcoCard,
                            disabledContainerColor = MatcoCard,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = false,
                        maxLines = 3
                    )

                    IconButton(
                        onClick = {
                            if (userMsgText.isNotBlank()) {
                                val messageToSubmit = userMsgText
                                viewModel.sendAiMessage(messageToSubmit)
                                userMsgText = ""
                            }
                        },
                        enabled = userMsgText.isNotBlank() && !aiLoading,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(if (userMsgText.isNotBlank() && !aiLoading) MatcoRed else MatcoCard)
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "Gönder",
                            tint = if (userMsgText.isNotBlank() && !aiLoading) Color.White else MatcoTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }

    // API Key Dialog
    if (showApiKeyDialog) {
        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = { Text("Gemini API Anahtarı Kurulumu", fontWeight = FontWeight.Bold, color = MatcoRed) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Uygulamanın Gemini AI yeteneğini kullanabilmek için geçerli bir API Anahtarına ihtiyacı vardır.",
                        fontSize = 12.sp,
                        color = Color.White
                    )

                    TextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        placeholder = { Text("AIzaSy...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveApiKey(apiKeyInput.trim())
                        showApiKeyDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                ) {
                    Text("KAYDET")
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("İPTAL")
                }
            }
        )
    }
}

@Composable
fun ThreeDotLoadingAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "dots")
    val dotCount = 3
    val dots = List(dotCount) { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.2f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = keyframes {
                    durationMillis = 600
                    0.2f at 0
                    1f at 300
                    0.2f at 600
                },
                repeatMode = RepeatMode.Reverse,
                initialStartOffset = StartOffset(150 * index)
            ),
            label = "dot alpha $index"
        )
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        dots.forEach { alphaVal ->
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF6366F1))
                    .alpha(alphaVal.value)
            )
        }
    }
}
