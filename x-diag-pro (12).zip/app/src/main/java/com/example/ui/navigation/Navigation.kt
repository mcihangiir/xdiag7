package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Dashboard : Screen("dashboard")
    object IntelligentScan : Screen("intelligent_scan")
    object LocalDiagnose : Screen("local_diagnose")
    object SystemSelect : Screen("system_select/{brand}") {
        fun createRoute(brand: String) = "system_select/$brand"
    }
    object ModuleInspect : Screen("module_inspect/{systemId}") {
        fun createRoute(systemId: String) = "module_inspect/$systemId"
    }
    object SpecialFunctions : Screen("special_functions")
    object History : Screen("history")
    object SoftwareUpdate : Screen("software_update")
    object Settings : Screen("settings")
    object AdasCalibration : Screen("adas_calibration")
    object FaultCodes : Screen("fault_codes")
    object LiveChart : Screen("live_chart")
    object FreezeFrame : Screen("freeze_frame")
    object PidSelection : Screen("pid_selection")
    object OilReset : Screen("oil_reset")
    object SasCalibration : Screen("sas_calibration")
    object BmsReset : Screen("bms_reset")
    object Tpms : Screen("tpms")
    object ImReadiness : Screen("im_readiness")
    object Mode06 : Screen("mode_06")
    object DataRecording : Screen("data_recording")
    object VoltageAnalysis : Screen("voltage_analysis")
    object MultiChart : Screen("multi_chart")
    object GaugeDashboard : Screen("gauge_dashboard")
    object AiDiagnose : Screen("ai_diagnose")
    object VinScanner : Screen("vin_scanner")
    object Statistics : Screen("statistics")
    object DriveCycle : Screen("drive_cycle")
    object ServiceHistory : Screen("service_history")
    object TechDashboard : Screen("tech_dashboard")
    object BleGattInspector : Screen("ble_gatt_inspector")
    object DeviceProtocolGuide : Screen("device_protocol_guide")
    object UnifiedConnection : Screen("unified_connection")
    object SmartConnect : Screen("smart_connect")
    object RecordingGuide : Screen("recording_guide")
    object UserInfo : Screen("user_info")
    object VciManager : Screen("vci_manager")
    object RepairInfo : Screen("repair_info")
    object MisfireMonitor : Screen("misfire_monitor")
    object DeviceProbe : Screen("device_probe")
}
