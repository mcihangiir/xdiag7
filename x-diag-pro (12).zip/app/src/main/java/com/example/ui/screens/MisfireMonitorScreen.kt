package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MatcoRed
import com.example.ui.theme.MatcoTextMuted
import com.example.viewmodel.DiagnosticViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MisfireMonitorScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val misfireData by viewModel.misfireData.collectAsState()
    val isPolling by viewModel.misfirePolling.collectAsState()

    DisposableEffect(Unit) {
        onDispose {
            viewModel.stopMisfireMonitoring()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("4 Silindir Ateşleme İzleyici", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // ÜST UYARI (DAİMA GÖSTER)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D).copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "⚠️ Bu veri BİRİKİMLİ sayaçtır (son sürüş döngülerinin toplamı), 'şu an oluyor' canlı bir olay değildir. Standart OBD2'de gerçek zamanlı silindir-bazlı ateşleme verisi YOKTUR.",
                    fontSize = 12.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }

            // 4 SİLİNDİR KARTI (2x2)
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(if (misfireData.isNotEmpty()) misfireData else List(4) { DiagnosticViewModel.CylinderMisfireData(it+1, -1, false) }) { item ->
                    Card(
                        border = if (item.isAbnormal) BorderStroke(2.dp, MatcoRed) else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Silindir ${item.cylinderNumber}", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            if (item.misfireCount == -1) {
                                Text("Desteklenmiyor", color = MatcoTextMuted, fontSize = 12.sp)
                            } else {
                                Text(
                                    "${item.misfireCount}", 
                                    fontSize = 32.sp, 
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.isAbnormal) MatcoRed else Color(0xFF22C55E)
                                )
                                Text("kaçırma", fontSize = 11.sp, color = MatcoTextMuted)
                                if (item.isAbnormal) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        "🔴 Ortalamanın 3x üstünde — bobin/buji kontrolü önerilir", 
                                        fontSize = 10.sp, 
                                        color = MatcoRed
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ALT BUTON
            Button(
                onClick = { 
                    if (isPolling) viewModel.stopMisfireMonitoring() 
                    else viewModel.startMisfireMonitoring() 
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isPolling) MatcoRed else MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(if (isPolling) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (isPolling) "⏹ DURDUR" else "▶ İZLEMEYİ BAŞLAT")
            }

            // BİLGİ KARTI
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "💡 Yüksek sayım gördüğünüz silindirin bobin, buji veya enjektörünü diğer silindirlerle karşılaştırarak kontrol edin. Tek silindirde sürekli yüksek sayım = mekanik/elektrik arıza şüphesi.",
                    fontSize = 12.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
}
