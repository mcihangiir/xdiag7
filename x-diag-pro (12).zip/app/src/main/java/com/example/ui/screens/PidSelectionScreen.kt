package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.data.ObdPidDefinition

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PidSelectionScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val availablePids by viewModel.availablePids.collectAsState()
    val selectedPids by viewModel.selectedPids.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    val filteredPids = remember(availablePids, searchQuery) {
        if (searchQuery.isEmpty()) {
            availablePids
        } else {
            availablePids.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.pid.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("PID SEÇİM LİSTESİ", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Summary indicator card
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("AKTİF SEÇİM SAYISI", fontSize = 11.sp, color = MatcoTextMuted, fontWeight = FontWeight.Bold)
                        Text("${selectedPids.size} / 10 PID Seçildi", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("Panelinizde canlı olarak görüntülemek için en fazla 10 adet parametre seçebilirsiniz.", color = MatcoTextMuted, fontSize = 11.sp, lineHeight = 14.sp)
                    }
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(MatcoRed.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.BarChart, contentDescription = null, tint = MatcoRed, modifier = Modifier.size(28.dp))
                    }
                }
            }

            // Search Filter input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Parametre veya PID ara...", color = MatcoTextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MatcoRed) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MatcoRed,
                    unfocusedBorderColor = MatcoCardBorder,
                    focusedContainerColor = MatcoCard,
                    unfocusedContainerColor = MatcoCard,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            // Dynamic Checklist
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredPids) { pidDef ->
                    PidListItem(pidDef) {
                        viewModel.togglePidSelection(pidDef.pid)
                    }
                }
            }
        }
    }
}

@Composable
fun PidListItem(
    item: ObdPidDefinition,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, if (item.isSelected) MatcoRed.copy(0.4f) else MatcoCardBorder),
        onClick = onToggle
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(item.pid, fontSize = 11.sp, color = MatcoRed, fontWeight = FontWeight.Bold)
                    }
                    Text(item.unit, fontSize = 11.sp, color = MatcoTextMuted)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Formula: ${item.parseFormula}", color = MatcoTextMuted, fontSize = 10.sp)
            }
            Checkbox(
                checked = item.isSelected,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = MatcoRed,
                    uncheckedColor = MatcoTextMuted,
                    checkmarkColor = Color.White
                )
            )
        }
    }
}
