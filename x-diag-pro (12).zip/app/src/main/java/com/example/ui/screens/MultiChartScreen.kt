package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Maximize
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel

enum class GridMode {
    TWO_BY_TWO,
    TWO_BY_THREE
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun MultiChartScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onNavigateToLiveChart: () -> Unit
) {
    val gridChartData by viewModel.gridChartData.collectAsState()
    var gridMode by remember { mutableStateOf(GridMode.TWO_BY_TWO) }
    
    // Default selected PIDs
    var selectedPids by remember { 
        mutableStateOf(listOf("RPM", "Hız", "Soğutma", "Voltaj", "Motor Yükü", "O2 Voltaj")) 
    }
    
    var showPidSelector by remember { mutableStateOf(false) }
    var fullScreenPid by remember { mutableStateOf<String?>(null) }
    
    // Calculate PIDs to display based on selected mode
    val pidsToDisplay = remember(gridMode, selectedPids) {
        val limit = if (gridMode == GridMode.TWO_BY_TWO) 4 else 6
        selectedPids.take(limit)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = if (fullScreenPid != null) "${fullScreenPid} MULTİ PANEL" else "ÇOKLU PRO GRAFİK SEVENEK", 
                        fontWeight = FontWeight.Bold, 
                        color = MatcoRed
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (fullScreenPid != null) {
                            fullScreenPid = null
                        } else {
                            onBack()
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            if (fullScreenPid == null) {
                FloatingActionButton(
                    onClick = { showPidSelector = true },
                    containerColor = MatcoRed,
                    contentColor = Color.White,
                    modifier = Modifier.padding(bottom = 16.dp, end = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.List, contentDescription = null)
                        Text("PID SEÇ", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (fullScreenPid != null) {
                // Full Screen Mode visualizer
                val pid = fullScreenPid!!
                val points = gridChartData[pid] ?: emptyList()
                val color = viewModel.pidColors[pid] ?: MatcoRed
                val range = viewModel.pidRanges[pid] ?: (0f to 100f)
                val unit = when (pid) {
                    "RPM" -> "RPM"
                    "Hız" -> "km/h"
                    "Soğutma" -> "°C"
                    "O2 Voltaj" -> "V"
                    "Motor Yükü" -> "%"
                    "Voltaj" -> "V"
                    else -> ""
                }
                val currentValue = if (points.isNotEmpty()) points.last() else 0f

                Box(modifier = Modifier.weight(1f)) {
                    MiniChartPanel(
                        pidName = pid,
                        points = points,
                        color = color,
                        unit = unit,
                        range = range,
                        currentValue = currentValue,
                        isFullScreen = true,
                        onClick = {
                            viewModel.setSelectedChartMetric(pid)
                            onNavigateToLiveChart()
                        },
                        onLongClick = { fullScreenPid = null }
                    )
                }
                
                Button(
                    onClick = { fullScreenPid = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MatcoCardBorder, RoundedCornerShape(10.dp)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("GRID GÖRÜNÜMÜNE GERİ DÖN", color = Color.White, fontWeight = FontWeight.Bold)
                }

            } else {
                // Layout Mode selector Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    listOf(GridMode.TWO_BY_TWO to "2x2 (4 PID)", GridMode.TWO_BY_THREE to "2x3 (6 PID)").forEach { (mode, label) ->
                        val isSelected = gridMode == mode
                        Button(
                            onClick = { gridMode = mode },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) MatcoRed else MatcoCard
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(
                                    1.dp,
                                    if (isSelected) Color.Transparent else MatcoCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                        ) {
                            Text(
                                text = label,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isSelected) Color.White else MatcoTextMuted
                            )
                        }
                    }
                }

                // Grid mapping to display active mini charts
                val cellHeight = if (gridMode == GridMode.TWO_BY_TWO) 180.dp else 150.dp
                
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(pidsToDisplay) { pid ->
                        val points = gridChartData[pid] ?: emptyList()
                        val color = viewModel.pidColors[pid] ?: MatcoRed
                        val range = viewModel.pidRanges[pid] ?: (0f to 100f)
                        val unit = when (pid) {
                            "RPM" -> "RPM"
                            "Hız" -> "km/h"
                            "Soğutma" -> "°C"
                            "O2 Voltaj" -> "V"
                            "Motor Yükü" -> "%"
                            "Voltaj" -> "V"
                            else -> ""
                        }
                        val currentValue = if (points.isNotEmpty()) points.last() else 0f

                        Box(modifier = Modifier.height(cellHeight)) {
                            MiniChartPanel(
                                pidName = pid,
                                points = points,
                                color = color,
                                unit = unit,
                                range = range,
                                currentValue = currentValue,
                                isFullScreen = false,
                                onClick = {
                                    viewModel.setSelectedChartMetric(pid)
                                    onNavigateToLiveChart()
                                },
                                onLongClick = {
                                    fullScreenPid = pid
                                }
                            )
                        }
                    }
                }
                
                Text(
                    text = "* Grafiği tam ekran yapmak için üzerine uzun basın.\n* Canlı veri kaydını büyük görmek için panele dokunun.",
                    color = MatcoTextMuted,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    textAlign = TextAlign.Start,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                )
            }
        }

        // Bottom Sheet PID Selector code block
        if (showPidSelector) {
            val maxLimit = if (gridMode == GridMode.TWO_BY_TWO) 4 else 6
            ModalBottomSheet(
                onDismissRequest = { showPidSelector = false },
                containerColor = MatcoCard,
                dragHandle = { BottomSheetDefaults.DragHandle(color = MatcoCardBorder) }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 40.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "GÖSTERİLECEK PID SEÇİMİ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MatcoRed
                    )
                    
                    Text(
                        text = "Mevcut düzen için en fazla $maxLimit adet PID seçebilirsiniz. (Seçilen: ${selectedPids.size})",
                        fontSize = 12.sp,
                        color = MatcoTextMuted
                    )

                    val allAvailablePids = listOf("RPM", "Hız", "Soğutma", "O2 Voltaj", "Motor Yükü", "Voltaj")
                    
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        allAvailablePids.forEach { pid ->
                            val isChecked = selectedPids.contains(pid)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        if (isChecked) {
                                            if (selectedPids.size > 1) {
                                                selectedPids = selectedPids.filter { it != pid }
                                            }
                                        } else {
                                            if (selectedPids.size < maxLimit) {
                                                selectedPids = selectedPids + pid
                                            }
                                        }
                                    }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(viewModel.pidColors[pid] ?: MatcoRed, RoundedCornerShape(2.dp))
                                    )
                                    Text(pid, color = Color.White, fontWeight = FontWeight.Medium)
                                }
                                
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        if (checked) {
                                            if (selectedPids.size < maxLimit) {
                                                selectedPids = selectedPids + pid
                                            }
                                        } else {
                                            if (selectedPids.size > 1) {
                                                selectedPids = selectedPids.filter { it != pid }
                                            }
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = MatcoRed,
                                        uncheckedColor = MatcoCardBorder,
                                        checkmarkColor = Color.White
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { showPidSelector = false },
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("UYGULA", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MiniChartPanel(
    pidName: String,
    points: List<Float>,
    color: Color,
    unit: String,
    range: Pair<Float, Float>,
    currentValue: Float,
    isFullScreen: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxSize()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header: Left (PID), Right (Value + unit)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = pidName,
                    fontSize = if (isFullScreen) 16.sp else 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    val formattedValue = if (pidName == "O2 Voltaj" || pidName == "Voltaj") {
                        String.format("%.2f", currentValue)
                    } else {
                        String.format("%.0f", currentValue)
                    }
                    Text(
                        text = formattedValue,
                        fontSize = if (isFullScreen) 24.sp else 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                    Text(
                        text = unit,
                        fontSize = if (isFullScreen) 12.sp else 9.sp,
                        color = MatcoTextMuted
                    )
                }
            }

            // Real-time Canvas plotting
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(MatcoDark.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .clip(RoundedCornerShape(8.dp))
                    .border(0.5.dp, MatcoCardBorder.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 6.dp)) {
                    val w = size.width
                    val h = size.height
                    
                    // Draw 3 horizontal grid lines
                    val gridLines = 3
                    for (i in 1..gridLines) {
                        val yGrid = h * i / (gridLines + 1)
                        drawLine(
                            color = Color.White.copy(alpha = 0.05f),
                            start = Offset(0f, yGrid),
                            end = Offset(w, yGrid),
                            strokeWidth = 1f
                        )
                    }

                    if (points.isNotEmpty()) {
                        val (minVal, maxVal) = range
                        val path = Path()
                        val areaPath = Path()
                        
                        val stepX = w / 60f
                        
                        points.forEachIndexed { idx, value ->
                            val x = idx * stepX
                            val normY = h - (((value - minVal) / (maxVal - minVal)).coerceIn(0f, 1f) * h)
                            
                            if (idx == 0) {
                                path.moveTo(x, normY)
                                areaPath.moveTo(x, h)
                                areaPath.lineTo(x, normY)
                            } else {
                                path.lineTo(x, normY)
                                areaPath.lineTo(x, normY)
                            }
                        }
                        
                        // Close area gradient path
                        if (points.size > 1) {
                            val lastX = (points.size - 1) * stepX
                            areaPath.lineTo(lastX, h)
                            areaPath.close()
                        }

                        // Clip and draw gradient fill
                        clipPath(areaPath) {
                            drawRect(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        color.copy(alpha = 0.35f),
                                        color.copy(alpha = 0f)
                                    )
                                )
                            )
                        }

                        // Draw main stroke line path
                        drawPath(
                            path = path,
                            color = color,
                            style = Stroke(width = if (isFullScreen) 5f else 3f)
                        )

                        // Draw live tracking dot at the last point
                        val lastIdx = points.size - 1
                        val lastX = lastIdx * stepX
                        val lastY = h - (((points.last() - minVal) / (maxVal - minVal)).coerceIn(0f, 1f) * h)
                        drawCircle(
                            color = color,
                            radius = if (isFullScreen) 6.dp.toPx() else 4.dp.toPx(),
                            center = Offset(lastX, lastY)
                        )
                    }
                }
            }

            // Footer display bounds
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val formattedMin = if (pidName == "O2 Voltaj" || pidName == "Voltaj") {
                    String.format("%.1f", range.first)
                } else {
                    String.format("%.0f", range.first)
                }
                
                val formattedMax = if (pidName == "O2 Voltaj" || pidName == "Voltaj") {
                    String.format("%.1f", range.second)
                } else {
                    String.format("%.0f", range.second)
                }

                Text(
                    text = "Min: $formattedMin",
                    fontSize = 8.sp,
                    color = MatcoTextMuted
                )
                Text(
                    text = "Max: $formattedMax",
                    fontSize = 8.sp,
                    color = MatcoTextMuted
                )
            }
        }
    }
}
