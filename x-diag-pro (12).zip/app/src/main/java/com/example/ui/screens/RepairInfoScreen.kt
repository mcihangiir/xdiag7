package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.navigation.Screen
import com.example.viewmodel.DiagnosticViewModel

val ALL_REPAIR_GUIDES = listOf(
    RepairGuide(
        id = "toyota_injector_coding",
        brand = "Toyota",
        title = "2AD-FHV Engine - Injector Coding Procedure",
        description = "ECU değişimi veya enjektör yenileme sonrasında enjektör kompanzasyon kodlarının (30 haneli) motor beynine yazılması talimatları.",
        difficulty = "Orta Seviye",
        timeRequired = "20 Dk",
        tools = listOf("X-DIAG Pro VCI", "Enjektör Kod Anahtarı"),
        specs = listOf(
            "Sıralama: Silindir 1'den 4'e kadar",
            "Kod Formatı: 30 Hex Haneli Alfa-Nümerik",
            "Min Voltaj: 12.2V Kontak Açık, Motor Kapalı"
        ),
        steps = listOf(
            "Silindir kapak muhafazası üzerindeki enjektör kare kodlarını veya 30 haneli kodları not edin.",
            "X-DIAG Pro cihazınızı OBD2 soketine bağlayın ve kontağı açın (Motor kapalı).",
            "Özel Fonksiyonlar menüsünden 'Enjektör Kodlama' seçeneğini başlatın.",
            "Değiştirdiğiniz silindir numarasını seçin (örn: Silindir 1).",
            "Eski 30 haneli kodu temizleyin ve yeni kodu girerek 'KAYDET' butonuna tıklayın.",
            "Kontak anahtarını kapatın, 15 saniye bekleyin ve kontağı tekrar açıp arıza kodlarını tarayın."
        ),
        associatedSpecialFunctionRoute = "special_functions",
        relatedDtcCodes = listOf("P00BC")
    ),
    RepairGuide(
        id = "volvo_epb_service",
        brand = "Volvo",
        title = "Volvo XC60 - Rear Electronic Parking Brake Pad Service",
        description = "Arka elektrikli park freni kaliperlerinin servis / balata değişim moduna alınması ve işlem sonrası kalibrasyon adımları.",
        difficulty = "Zor Seviye",
        timeRequired = "45 Dk",
        tools = listOf("Kriko", "Servis Anahtar Seti", "X-DIAG Pro"),
        specs = listOf(
            "Sıkma Torku: 35 Nm (Kaliper Cıvataları)",
            "Akü Voltajı > 12.0 Volt limitsiz destek",
            "Solenoid Direnci: 2.1 Ω"
        ),
        steps = listOf(
            "Aracı düz zemine kaldırın ve tekerlekleri sökün.",
            "Aracın el frenini indirin. X-DIAG Pro cihazına girip 'EPB Servisi' seçeneğini çalıştırın.",
            "'Kaliperleri Aç (Retract Solenoid)' komutunu göndererek kaliper pistonlarının tamamen geriye çekilmesini bekleyin.",
            "Fren balatalarını değiştirin ve kaliper cıvatalarını 35 Nm tork ile sıkın.",
            "X-DIAG Pro üzerinden 'Kaliperleri Kapat (Calibrate EPB)' komutunu gönderin.",
            "Park frenini 3 kez çekip bırakarak mekanizmanın kendini hizalamasını sağlayın."
        ),
        associatedSpecialFunctionRoute = "special_functions",
        relatedDtcCodes = listOf("C0021")
    ),
    RepairGuide(
        id = "peugeot_dpf_regen",
        brand = "Peugeot",
        title = "PSA BlueHDi 1.6 - DPF Manual Regeneration static",
        description = "Dizel Partikül Filtresi doluluk oranı aşırı yükseldiğinde araç park halindeyken zorunlu yüksek ısıda rejenerasyon basamakları.",
        difficulty = "Orta Seviye",
        timeRequired = "30 Dk",
        tools = listOf("Yangın Söndürücü", "Dış Mekan Alanı"),
        specs = listOf(
            "Egzoz Sıcaklığı: > 600°C",
            "Motor Devri: Otomatik 3200 RPM",
            "Minimum Yakıt Seviyesi: %25 Çeyrek Depo"
        ),
        steps = listOf(
            "Aracı yanıcı maddelerden uzak, açık havadaki güvenli bir konuma park edin.",
            "Motorun çalışma sıcaklığında (soğutma suyu > 80°C) olduğundan emin olun.",
            "Kaputu kapatın, vitesi boşa (veya P konumuna) alın ve el frenini sonuna kadar çekin.",
            "Klimayı ve tüm elektrik tüketicilerini kapatın.",
            "X-DIAG Pro cihazına girerek 'DPF Rejenerasyon' fonksiyonunu tetikleyin.",
            "Motor otomatik olarak 3200 devire yükselecektir. İşlem tamamlanana (yaklaşık 25 dakika) kadar gaza veya frene basmayın."
        ),
        associatedSpecialFunctionRoute = "special_functions",
        relatedDtcCodes = listOf("P1116", "P1116-06", "P1703")
    ),
    RepairGuide(
        id = "citroen_sas_calibration",
        brand = "Citroen",
        title = "Citroen C4 - Steering Angle Sensor (SAS) Calibration",
        description = "Rot ayarı, direksiyon kutusu değişimi veya süspansiyon onarımı sonrasında direksiyon açısının 0 dereceye kalibre edilmesi.",
        difficulty = "Kolay Seviye",
        timeRequired = "15 Dk",
        tools = listOf("X-DIAG Pro VCI"),
        specs = listOf(
            "Kabul Edilebilir Sapma: < ±1.5 derece",
            "Kontak Konumu: ON (Motor Kapalı)",
            "Lastik Pozisyonu: Tam Hizalı Düz"
        ),
        steps = listOf(
            "Aracı rot ayar standında veya düz zeminde konumlandırın.",
            "Direksiyon simidini tekerleklerle birlikte tam düz (0°) konuma getirin.",
            "X-DIAG Pro cihazınızı bağlayın ve 'Direksiyon Açı Kalibrasyonu (SAS)' menüsüne girin.",
            "Kontak açık ve motor kapalıyken 'Kalibre Et' butonuna dokunun.",
            "Ekranda 'İşlem Başarılı' uyarısı gelene kadar direksiyonu kesinlikle oynatmayın.",
            "Kontak kapatıp 10 saniye bekleyin, motoru çalıştırıp direksiyonu sola ve sağa tam kırarak ESP lambasının söndüğünü doğrulayın."
        ),
        associatedSpecialFunctionRoute = "sas_calibration",
        relatedDtcCodes = listOf("B1088", "B129C", "B129D")
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RepairInfoScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedGuide by remember { mutableStateOf<RepairGuide?>(null) }

    val selectedDtcByVM by viewModel.selectedDtcCodeForRepair.collectAsState()

    LaunchedEffect(selectedDtcByVM) {
        selectedDtcByVM?.let { code ->
            val matchedGuide = com.example.data.RepairGuideMatcher.findGuideForDtc(code, ALL_REPAIR_GUIDES)
            if (matchedGuide != null) {
                selectedGuide = matchedGuide
                selectedCategory = matchedGuide.brand
            }
            viewModel.selectedDtcCodeForRepair.value = null
        }
    }

    val categories = listOf(
        CategoryItem("All", "Tümü", Icons.Default.AllInbox),
        CategoryItem("Toyota", "Toyota V49.50", Icons.Default.DirectionsCar),
        CategoryItem("Volvo", "Volvo Service", Icons.Default.Build),
        CategoryItem("Peugeot", "PSA Peugeot", Icons.Default.Handyman),
        CategoryItem("Citroen", "PSA Citroen", Icons.Default.Settings)
    )

    val guides = remember { ALL_REPAIR_GUIDES }

    val filteredGuides = guides.filter {
        (selectedCategory == "All" || it.brand.equals(selectedCategory, ignoreCase = true)) &&
        (it.title.contains(searchQuery, ignoreCase = true) || it.description.contains(searchQuery, ignoreCase = true))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ONARIM KILAVUZLARI & TALİMATLAR", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedGuide != null) {
                            selectedGuide = null
                        } else {
                            onBack()
                        }
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            if (selectedGuide == null) {
                // Search box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Kılavuz veya hata kodu ile arayın...", color = MatcoTextMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MatcoRed) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MatcoRed,
                        unfocusedBorderColor = MatcoCardBorder,
                        focusedContainerColor = MatcoCard,
                        unfocusedContainerColor = MatcoCard
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                // Category selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat.id,
                            onClick = { selectedCategory = cat.id },
                            label = { Text(cat.label, color = if (selectedCategory == cat.id) Color.White else MatcoTextMuted) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MatcoRed,
                                selectedLabelColor = Color.White,
                                containerColor = MatcoCard
                            ),
                            border = BorderStroke(1.dp, if (selectedCategory == cat.id) MatcoRed else MatcoCardBorder)
                        )
                    }
                }

                // Guides List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (filteredGuides.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.HelpOutline, null, tint = MatcoTextMuted, modifier = Modifier.size(48.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Aramanıza uygun talimat kılavuzu bulunamadı.", color = MatcoTextMuted, fontSize = 14.sp)
                                }
                            }
                        }
                    }

                    items(filteredGuides) { guide ->
                        Card(
                            onClick = { selectedGuide = guide },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MatcoCardBorder),
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(MatcoRed.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(guide.brand, color = MatcoRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(guide.difficulty, color = Color.Yellow, fontSize = 11.sp)
                                        Text("•", color = MatcoTextMuted, fontSize = 11.sp)
                                        Text(guide.timeRequired, color = MatcoTextMuted, fontSize = 11.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(guide.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(guide.description, fontSize = 12.sp, color = MatcoTextMuted, maxLines = 2)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Task, null, tint = MatcoAccent, modifier = Modifier.size(14.dp))
                                    Text("Görüntüle", fontSize = 12.sp, color = MatcoAccent, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            } else {
                // Guide Detail
                val guide = selectedGuide!!
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, MatcoCardBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = guide.brand.uppercase(),
                                    color = MatcoRed,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = guide.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = guide.description,
                                    fontSize = 13.sp,
                                    color = MatcoTextMuted
                                )
                            }
                        }
                    }

                    // Key specifications & tools
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                                border = BorderStroke(1.dp, MatcoCardBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Build, null, tint = MatcoAccent, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Gerekli Aletler", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MatcoAccent)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    guide.tools.forEach { tool ->
                                        Text("• $tool", fontSize = 11.sp, color = Color.White)
                                    }
                                }
                            }

                            Card(
                                modifier = Modifier.weight(1f),
                                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                                border = BorderStroke(1.dp, MatcoCardBorder)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Info, null, tint = MatcoRed, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Kritik Değerler", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MatcoRed)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    guide.specs.forEach { spec ->
                                        Text("• $spec", fontSize = 11.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    }

                    // Procedure steps
                    item {
                        Text("ADIM ADIM UYGULAMA TALİMATLARI", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MatcoAccent)
                    }

                    items(guide.steps.size) { index ->
                        val stepText = guide.steps[index]
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, MatcoCardBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(MatcoRed, RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text((index + 1).toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Text(
                                    text = stepText,
                                    fontSize = 13.sp,
                                    color = Color.White,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Bottom Action Panel
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { onNavigate(guide.associatedSpecialFunctionRoute) },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Build, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("İLGİLİ HİZMET FONKSİYONUNU ÇALIŞTIR", fontWeight = FontWeight.Bold)
                        }
                        
                        OutlinedButton(
                            onClick = { selectedGuide = null },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Text("GERİ DÖN")
                        }
                    }
                }
            }
        }
    }
}

data class CategoryItem(
    val id: String,
    val label: String,
    val icon: ImageVector
)

data class RepairGuide(
    val id: String,
    val brand: String,
    val title: String,
    val description: String,
    val difficulty: String,
    val timeRequired: String,
    val tools: List<String>,
    val specs: List<String>,
    val steps: List<String>,
    val associatedSpecialFunctionRoute: String,
    val relatedDtcCodes: List<String> = emptyList()
)
