package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ImMonitor
import com.example.data.ImMonitorStatus
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImReadinessScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onNavigateToDriveCycle: () -> Unit
) {
    val result by viewModel.imReadinessResult.collectAsState()
    val isLoading by viewModel.imReadinessLoading.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    // Shimmer setup for loading skeleton
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerAlpha"
    )

    // Automatically trigger read on entrance
    LaunchedEffect(Unit) {
        viewModel.readImReadiness()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "I/M Emisyon Hazırlık",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("im_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoDark,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = MatcoBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Check if there is data
            val currentResult = result

            if (isLoading) {
                // SKELETON LOADER
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Shimmer Card for Header
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(MatcoCard.copy(alpha = shimmerAlpha), RoundedCornerShape(12.dp))
                            .border(BorderStroke(1.dp, MatcoCardBorder.copy(alpha = shimmerAlpha)), RoundedCornerShape(12.dp))
                    )

                    // Text Placeholder
                    Box(
                        modifier = Modifier
                            .width(220.dp)
                            .height(16.dp)
                            .background(MatcoTextMuted.copy(alpha = shimmerAlpha), RoundedCornerShape(4.dp))
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Group 1 Header
                    Box(
                        modifier = Modifier
                            .width(160.dp)
                            .height(14.dp)
                            .background(MatcoTextMuted.copy(alpha = shimmerAlpha), RoundedCornerShape(3.dp))
                    )

                    // 3 continuous monitors skeleton rows
                    repeat(3) {
                        SkeletonRow(alpha = shimmerAlpha)
                    }

                    // Group 2 Header
                    Box(
                        modifier = Modifier
                            .width(240.dp)
                            .height(14.dp)
                            .background(MatcoTextMuted.copy(alpha = shimmerAlpha), RoundedCornerShape(3.dp))
                    )

                    // some non-continuous monitors skeleton rows
                    repeat(4) {
                        SkeletonRow(alpha = shimmerAlpha)
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Button Skeleton
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .background(MatcoRed.copy(alpha = shimmerAlpha), RoundedCornerShape(24.dp))
                    )
                }
            } else {
                // ACTUAL CONTENT
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. TOP CARDS
                    if (currentResult != null) {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                                border = BorderStroke(1.dp, MatcoCardBorder),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    // Row of Stats
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        StatColumn(
                                            value = "${currentResult.readyCount}",
                                            label = "HAZIR",
                                            color = Color(0xFF22C55E)
                                        )

                                        Box(
                                            modifier = Modifier
                                                .width(1.dp)
                                                .height(40.dp)
                                                .background(MatcoCardBorder.copy(alpha = 0.3f))
                                        )

                                        StatColumn(
                                            value = "${currentResult.incompleteCount}",
                                            label = "BEKLİYOR",
                                            color = Color(0xFFF59E0B)
                                        )

                                        Box(
                                            modifier = Modifier
                                                .width(1.dp)
                                                .height(40.dp)
                                                .background(MatcoCardBorder.copy(alpha = 0.3f))
                                        )

                                        StatColumn(
                                            value = "${currentResult.unsupportedCount}",
                                            label = "DESTEK YOK",
                                            color = Color(0xFF64748B)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Divider(color = MatcoCardBorder.copy(alpha = 0.3f), thickness = 1.dp)

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // MIL and DTC Row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // MIL State Indicator
                                        if (currentResult.mil) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                modifier = Modifier
                                                    .background(Color(0x26EF4444), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Warning,
                                                    contentDescription = "MIL On Warning",
                                                    tint = MatcoRed,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Text(
                                                    text = "MIL AÇIK ⚠️",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MatcoRed
                                                )
                                            }
                                        } else {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .background(Color(0x1A22C55E), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text(
                                                    text = "MIL KAPALI ✅",
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF22C55E)
                                                )
                                            }
                                        }

                                        // Active DTC count
                                        Text(
                                            text = "Aktif Hata Kodu: ${currentResult.dtcCount}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MatcoTextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Notice Text
                    item {
                        Text(
                            text = "Tüm monitörler hazır ise emisyon testine girebilirsiniz.",
                            fontSize = 13.sp,
                            color = MatcoTextMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        )
                    }

                    if (currentResult != null) {
                        val monitors = currentResult.monitors
                        val continuous = monitors.take(3)
                        val nonContinuous = monitors.drop(3)

                        // 2. CONTINUOUS GROUP
                        item {
                            Text(
                                text = "⚡ SÜREKLİ MONİTÖRLER",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MatcoTextMuted,
                                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                            )
                        }

                        items(continuous) { monitor ->
                            MonitorRowItem(monitor = monitor)
                        }

                        // 3. NON-CONTINUOUS GROUP
                        item {
                            Text(
                                text = "🔄 SÜREKSİZ MONİTÖRLER (Sürüş Döngüsü Gerekli)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MatcoTextMuted,
                                modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                            )
                        }

                        items(nonContinuous) { monitor ->
                            MonitorRowItem(monitor = monitor)
                        }
                    }
                }

                // Bottom Action Buttons
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                ) {
                    currentResult?.let { res ->
                        if (res.incompleteCount > 0) {
                            Button(
                                onClick = onNavigateToDriveCycle,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp)
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF6366F1), // Indigo
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Text(
                                    text = "🚗 SÜRÜŞ DÖNGÜSÜ (DRIVE CYCLE) REHBERİ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                viewModel.readImReadiness()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("read_im_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MatcoRed,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Text(
                            text = "📡 MONİTÖRLERİ YENİLE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MonitorRowItem(monitor: ImMonitor) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = monitor.nameTr,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = monitor.name,
                    fontSize = 11.sp,
                    color = MatcoTextMuted
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            val (chipText, chipColor) = when (monitor.status) {
                ImMonitorStatus.COMPLETE -> Pair("HAZIR", Color(0xFF22C55E))
                ImMonitorStatus.INCOMPLETE -> Pair("BEKLİYOR", Color(0xFFF59E0B))
                ImMonitorStatus.NOT_SUPPORTED -> Pair("YOK", Color(0xFF64748B))
            }

            Box(
                modifier = Modifier
                    .background(chipColor.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                    .border(BorderStroke(1.dp, chipColor.copy(alpha = 0.4f)), RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = chipText,
                    color = chipColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun StatColumn(value: String, label: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = value,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black,
            color = color
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MatcoTextMuted
        )
    }
}

@Composable
fun SkeletonRow(alpha: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .background(MatcoCard.copy(alpha = alpha), RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, MatcoCardBorder.copy(alpha = alpha)), RoundedCornerShape(8.dp))
    )
}
