package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DataRecording
import com.example.data.PidSnapshot
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DataRecordingScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("KAYIT ENGELİ / YÖNETİMİ", "SENSÖR OYNAT ICI (REPLAY)")

    val isRecording by viewModel.isRecording.collectAsState()
    val recordingElapsedSeconds by viewModel.recordingElapsedSeconds.collectAsState()
    val recordings by viewModel.recordings.collectAsState()

    val replayRecording by viewModel.replayRecording.collectAsState()
    val replaySnapshots by viewModel.replaySnapshots.collectAsState()
    val replayPosition by viewModel.replayPosition.collectAsState()
    val isReplaying by viewModel.isReplaying.collectAsState()
    val replaySpeed by viewModel.replaySpeed.collectAsState()

    // Breathing red light animation during recording
    val infiniteTransition = rememberInfiniteTransition(label = "recording_pulse")
    val recordingAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    // Automatically switch tabs if a replay starts
    LaunchedEffect(replayRecording) {
        if (replayRecording != null) {
            selectedTab = 1
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sürüş Canlı Veri Kaydı",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("recording_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoDark,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = MatcoBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MatcoDark,
                contentColor = MatcoRed,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = MatcoRed
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp,
                                color = if (selectedTab == index) MatcoRed else MatcoTextMuted
                            )
                        }
                    )
                }
            }

            if (selectedTab == 0) {
                RecordingTab(
                    isRecording = isRecording,
                    elapsedSeconds = recordingElapsedSeconds,
                    recordings = recordings,
                    onStartRecording = { viewModel.startRecording() },
                    onStopRecording = { viewModel.stopRecording() },
                    onPlayReplay = { viewModel.startReplay(it) },
                    onDeleteRecording = { viewModel.deleteRecording(it) },
                    recordingAlpha = recordingAlpha
                )
            } else {
                ReplayTab(
                    replayRecording = replayRecording,
                    replaySnapshots = replaySnapshots,
                    replayPosition = replayPosition,
                    isReplaying = isReplaying,
                    replaySpeed = replaySpeed,
                    onPause = { viewModel.pauseReplay() },
                    onResume = { viewModel.resumeReplay() },
                    onStop = { viewModel.stopReplay() },
                    onSeek = { viewModel.seekReplay(it) },
                    onSetSpeed = { viewModel.setReplaySpeed(it) }
                )
            }
        }
    }
}

@Composable
fun RecordingTab(
    isRecording: Boolean,
    elapsedSeconds: Int,
    recordings: List<DataRecording>,
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    onPlayReplay: (DataRecording) -> Unit,
    onDeleteRecording: (DataRecording) -> Unit,
    recordingAlpha: Float
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Upper action controller card
        Card(
            colors = CardDefaults.cardColors(containerColor = MatcoCard),
            border = BorderStroke(1.dp, if (isRecording) MatcoRed.copy(alpha = 0.5f) else MatcoCardBorder.copy(alpha = 0.25f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!isRecording) {
                    Text(
                        text = "CANLI SÜRÜŞ VERİ KAYDI",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "RPM, Hız, Soğutma Suyu Sıcaklığı, O2 Sensörü gibi kritik parametreler 1 saniye aralıkla arka planda kaydedilecektir.",
                        color = MatcoTextMuted,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onStartRecording,
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("start_recording_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color.White, RoundedCornerShape(4.dp))
                            )
                            Text(
                                text = "KAYDI BAŞLAT",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(MatcoRed.copy(alpha = recordingAlpha), RoundedCornerShape(6.dp))
                            )
                            Text(
                                text = "KAYIT YAPILIYOR...",
                                color = MatcoRed,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }

                        Text(
                            text = String.format("%02d:%02d sn", elapsedSeconds / 60, elapsedSeconds % 60),
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onStopRecording,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("stop_recording_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Durdur",
                                tint = MatcoDark
                            )
                            Text(
                                text = "KAYDI DURDUR VE KAYDET",
                                fontWeight = FontWeight.Bold,
                                color = MatcoDark,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        Text(
            text = "KAYDEDİLEN DOSYALAR",
            fontWeight = FontWeight.Bold,
            color = MatcoTextMuted,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (recordings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CloudQueue,
                        contentDescription = null,
                        tint = MatcoTextMuted,
                        modifier = Modifier.size(60.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Henüz kaydedilmiş sürüş verisi bulunmuyor.",
                        color = MatcoTextMuted,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(recordings) { recording ->
                    SwipeToDeleteContainer(
                        onDelete = { onDeleteRecording(recording) }
                    ) {
                        RecordingCard(
                            recording = recording,
                            onPlay = { onPlayReplay(recording) },
                            onDelete = { onDeleteRecording(recording) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RecordingCard(
    recording: DataRecording,
    onPlay: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = recording.label,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "🚗 ${recording.vehicleName}",
                        color = MatcoAccent,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Sil",
                        tint = MatcoTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text(text = "SÜRE", fontSize = 9.sp, color = MatcoTextMuted)
                        Text(text = "${recording.durationSeconds} sn", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(text = "ÖRNEK", fontSize = 9.sp, color = MatcoTextMuted)
                        Text(text = "${recording.sampleCount}", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = onPlay,
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(text = "OYNAT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ReplayTab(
    replayRecording: DataRecording?,
    replaySnapshots: List<PidSnapshot>,
    replayPosition: Int,
    isReplaying: Boolean,
    replaySpeed: Float,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onSeek: (Int) -> Unit,
    onSetSpeed: (Float) -> Unit
) {
    if (replayRecording == null || replaySnapshots.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.PlayCircleOutline,
                    contentDescription = null,
                    tint = MatcoAccent,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Oynatmak için kayıtlar listesinden seçin",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Kayıt sekmesine gidin ve listelenen sürüş kayıtlarının yanındaki OYNAT tuşuna dokunun.",
                    color = MatcoTextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
    } else {
        // Active Replay Screen Loaded
        val totalPoints = replaySnapshots.size
        val currentSnapshot = replaySnapshots.getOrNull(replayPosition) ?: replaySnapshots.last()
        var selectedPidByPlayer by remember { mutableStateOf("RPM") }

        // Get PIDs listed in the snapshot
        val pidNames = currentSnapshot.values.keys.toList()
        if (!pidNames.contains(selectedPidByPlayer) && pidNames.isNotEmpty()) {
            selectedPidByPlayer = pidNames.first()
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Upper Info panel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = replayRecording.vehicleName,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Text(
                        text = replayRecording.label,
                        color = MatcoTextMuted,
                        fontSize = 11.sp
                    )
                }

                IconButton(
                    onClick = onStop,
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Oynatmayı Kapat",
                        tint = MatcoRed
                    )
                }
            }

            // Interactive Selector row for the Canvas
            Text(
                text = "HEDEF GRAFİK SENSÖRÜ SEÇİN",
                fontWeight = FontWeight.Bold,
                color = MatcoTextMuted,
                fontSize = 10.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .horizontalScrollAndClip(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                pidNames.forEach { pid ->
                    val isSel = selectedPidByPlayer == pid
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSel) MatcoRed else MatcoCard,
                                RoundedCornerShape(12.dp)
                            )
                            .border(
                                BorderStroke(1.dp, if (isSel) MatcoRed else MatcoCardBorder.copy(alpha = 0.4f)),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { selectedPidByPlayer = pid }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = pid,
                            color = if (isSel) Color.White else Color.White.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Premium Replay Line Chart Canvas
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "$selectedPidByPlayer Analitiği",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${currentSnapshot.values[selectedPidByPlayer] ?: 0f} değeri",
                            fontSize = 11.sp,
                            color = MatcoAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Replay Graphic Canvas Drawing logic
                    Box(modifier = Modifier.fillMaxSize()) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            val values = replaySnapshots.map { it.values[selectedPidByPlayer] ?: 0f }
                            val maxVal = values.maxOrNull()?.takeIf { it > 0f } ?: 1f

                            // Draw grid
                            val grids = 3
                            for (i in 0..grids) {
                                val yGrid = h * i / grids
                                drawLine(
                                    color = Color.White.copy(alpha = 0.05f),
                                    start = Offset(0f, yGrid),
                                    end = Offset(w, yGrid),
                                    strokeWidth = 1f
                                )
                            }

                            if (values.isNotEmpty()) {
                                // Draw Gray reference path of the whole recording
                                val totalPath = Path()
                                val stepX = w / (values.size - 1).coerceAtLeast(1)

                                values.forEachIndexed { index, fl ->
                                    val x = index * stepX
                                    val normalizedY = (fl / maxVal).coerceIn(0f, 1f)
                                    val y = h - (normalizedY * h * 0.85f) - (h * 0.05f)

                                    if (index == 0) {
                                        totalPath.moveTo(x, y)
                                    } else {
                                        totalPath.lineTo(x, y)
                                    }
                                }

                                drawPath(
                                    path = totalPath,
                                    color = Color.White.copy(alpha = 0.15f),
                                    style = Stroke(width = 4f)
                                )

                                // Draw colored active trail from 0 to replayPosition
                                val activePath = Path()
                                for (i in 0..replayPosition) {
                                    val fl = values[i]
                                    val x = i * stepX
                                    val normalizedY = (fl / maxVal).coerceIn(0f, 1f)
                                    val y = h - (normalizedY * h * 0.85f) - (h * 0.05f)

                                    if (i == 0) {
                                        activePath.moveTo(x, y)
                                    } else {
                                        activePath.lineTo(x, y)
                                    }
                                }

                                drawPath(
                                    path = activePath,
                                    color = MatcoRed,
                                    style = Stroke(width = 6f)
                                )

                                // Red indicator cursor point & line
                                val currentX = replayPosition * stepX
                                val currentVal = values[replayPosition]
                                val currentNormalizedY = (currentVal / maxVal).coerceIn(0f, 1f)
                                val currentY = h - (currentNormalizedY * h * 0.85f) - (h * 0.05f)

                                // Vertical pointer line
                                drawLine(
                                    color = MatcoRed.copy(alpha = 0.4f),
                                    start = Offset(currentX, 0f),
                                    end = Offset(currentX, h),
                                    strokeWidth = 1.5.dp.toPx()
                                )

                                // Inner pointer node circle
                                drawCircle(
                                    color = MatcoRed,
                                    radius = 5.dp.toPx(),
                                    center = Offset(currentX, currentY)
                                )

                                drawCircle(
                                    color = Color.White,
                                    radius = 2.dp.toPx(),
                                    center = Offset(currentX, currentY)
                                )
                            }
                        }
                    }
                }
            }

            // Timeline slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format("%02d:%02d sn", replayPosition / 60, replayPosition % 60),
                    fontSize = 12.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )

                Slider(
                    value = replayPosition.toFloat(),
                    valueRange = 0f..maxOf(1f, (totalPoints - 1).toFloat()),
                    onValueChange = { onSeek(it.toInt()) },
                    colors = SliderDefaults.colors(
                        activeTrackColor = MatcoRed,
                        inactiveTrackColor = Color(0xFF1E293B),
                        thumbColor = MatcoRed
                    ),
                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
                )

                Text(
                    text = String.format("%02d:%02d sn", totalPoints / 60, totalPoints % 60),
                    fontSize = 12.sp,
                    color = MatcoTextMuted,
                    fontWeight = FontWeight.Medium
                )
            }

            // Speed Selector Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val speeds = listOf(0.5f, 1.0f, 2.0f, 4.0f)
                speeds.forEach { speed ->
                    val isCurrent = replaySpeed == speed
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .background(
                                if (isCurrent) MatcoRed.copy(alpha = 0.2f) else Color.Transparent,
                                RoundedCornerShape(12.dp)
                            )
                            .border(
                                BorderStroke(1.dp, if (isCurrent) MatcoRed else Color.White.copy(alpha = 0.1f)),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onSetSpeed(speed) }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${speed}x",
                            color = if (isCurrent) MatcoRed else MatcoTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Player control buttons row: ⏮ | ⏪ | ⏯ | ⏩ | ⏭
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // ⏮ Back to start
                IconButton(onClick = { onSeek(0) }) {
                    Icon(imageVector = Icons.Default.SkipPrevious, contentDescription = "Sıfırla", tint = Color.White)
                }

                // ⏪ Step backward / decrease index
                IconButton(onClick = { onSeek((replayPosition - 1).coerceAtLeast(0)) }) {
                    Icon(imageVector = Icons.Default.FastRewind, contentDescription = "Geri", tint = Color.White)
                }

                // ⏯ Play / Pause button
                FloatingActionButton(
                    onClick = { if (isReplaying) onPause() else onResume() },
                    containerColor = MatcoRed,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(26.dp),
                    modifier = Modifier.size(52.dp)
                ) {
                    Icon(
                        imageVector = if (isReplaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Oynat / Durdur",
                        modifier = Modifier.size(28.dp)
                    )
                }

                // ⏩ Step forward / increase index
                IconButton(onClick = { onSeek((replayPosition + 1).coerceAtMost(totalPoints - 1)) }) {
                    Icon(imageVector = Icons.Default.FastForward, contentDescription = "İleri", tint = Color.White)
                }

                // ⏭ End of timeline
                IconButton(onClick = { onSeek(totalPoints - 1) }) {
                    Icon(imageVector = Icons.Default.SkipNext, contentDescription = "Son", tint = Color.White)
                }
            }

            // Live PID values visualization grid
            Text(
                text = "ZAMAN SÜRECİNDEKİ SENSÖR VERİLERİ",
                fontWeight = FontWeight.Bold,
                color = MatcoTextMuted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(currentSnapshot.values.toList()) { pair ->
                    val name = pair.first
                    val value = pair.second
                    val unit = when (name) {
                        "RPM" -> "rpm"
                        "Hız" -> "km/h"
                        "Soğutma" -> "°C"
                        "O2 Voltaj" -> "V"
                        "Voltaj" -> "V"
                        else -> "Val"
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = name.uppercase(), color = MatcoTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = String.format("%.2f %s", value, unit),
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }
    }
}

// Inline helper for Horizontal Scroll container
private fun Modifier.horizontalScrollAndClip() = this
    .background(Color.Transparent)
    .fillMaxWidth()

@Composable
fun SwipeToDeleteContainer(
    onDelete: () -> Unit,
    content: @Composable () -> Unit
) {
    var offsetX by remember { mutableStateOf(0f) }
    val animatedOffset = animateFloatAsState(targetValue = offsetX, label = "swipe")

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (offsetX < -120f) {
                            onDelete()
                        }
                        offsetX = 0f
                    },
                    onDragCancel = {
                        offsetX = 0f
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        offsetX = (offsetX + dragAmount).coerceIn(-180f, 0f)
                    }
                )
            }
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MatcoRed),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.matchParentSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(end = 24.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Sil",
                    tint = Color.White
                )
            }
        }

        Box(
            modifier = Modifier
                .offset { IntOffset(animatedOffset.value.roundToInt(), 0) }
                .fillMaxWidth()
                .background(MatcoBlack)
        ) {
            content()
        }
    }
}
