package com.example.ui.screens

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.WorkingDeviceProfile
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceProbeScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    val allResults by viewModel.dualScanner.allResults.collectAsState()
    val scanLog by viewModel.dualScanner.scanLog.collectAsState()
    val lastCapturedResponse by viewModel.dualScanner.lastCapturedResponse.collectAsState()
    
    var isScanning by remember { mutableStateOf(false) }
    var testInProgressDevice by remember { mutableStateOf<String?>(null) }
    var testTypeInProgress by remember { mutableStateOf<String?>(null) } // "SPP", "BLE", "BRUTE_FORCE"
    var showExplanationDialog by remember { mutableStateOf(false) }
    
    val logListState = rememberLazyListState()
    
    // Auto-scroll logic for live diagnosis terminal
    LaunchedEffect(scanLog.size) {
        if (scanLog.isNotEmpty()) {
            logListState.animateScrollToItem(scanLog.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CompassCalibration, 
                            contentDescription = null, 
                            tint = MatcoRed,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text("🔬 DS401 Tanı ve Bağlantı Aracı", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MatcoDark)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MatcoDark)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // ÜST KONTROLLER
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        isScanning = true
                        viewModel.dualScanner.clearLog()
                        viewModel.dualScanner.scanBoth()
                        coroutineScope.launch {
                            kotlinx.coroutines.delay(13000)
                            isScanning = false
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isScanning) MatcoDarkRed else MaterialTheme.colorScheme.primary
                    ),
                    enabled = !isScanning && testInProgressDevice == null
                ) {
                    Icon(
                        imageVector = if (isScanning) Icons.Default.Sync else Icons.Default.Search, 
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isScanning) "Taranıyor (12 sn)..." else "🔍 ÇİFT KATMANLI TARAMA BAŞLATI")
                }
                
                IconButton(
                    onClick = { viewModel.dualScanner.clearLog() },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = MatcoCard)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Logu Temizle", tint = MatcoRed)
                }
            }

            // CANLI TEŞHİS GÜNLÜĞÜ (Monospace Terminal)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                colors = CardDefaults.cardColors(containerColor = MatcoBlack),
                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        "Canlı Teşhis Terminali", 
                        fontSize = 11.sp, 
                        fontWeight = FontWeight.Bold, 
                        color = MatcoAccent, 
                        fontFamily = FontFamily.Monospace
                    )
                    Divider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 4.dp))
                    
                    if (scanLog.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "[Sinyaller ve veriler burada ham olarak listelenecektir]", 
                                fontSize = 11.sp, 
                                color = MatcoTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    } else {
                        LazyColumn(
                            state = logListState,
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            items(scanLog) { line ->
                                Text(
                                    text = line,
                                    fontSize = 10.sp,
                                    color = if (line.contains("✅") || line.contains("🎉")) Color(0xFF22C55E)
                                            else if (line.contains("❌")) MatcoRed
                                            else if (line.contains("⚠️")) Color.Yellow
                                            else MatcoTextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            // EN ALT DURUM DEĞERLENDİRME PANELİ
            if (lastCapturedResponse != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF14532D)),
                    border = BorderStroke(1.dp, Color(0xFF22C55E))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF22C55E))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                "✅ BAĞLANTI YÖNTEMİ DOĞRULANDI & KAYDEDİLDİ!", 
                                fontWeight = FontWeight.Bold, 
                                fontSize = 12.sp,
                                color = Color.White
                            )
                            Text(
                                "Alınan yanıt (HEX): $lastCapturedResponse", 
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF86EFAC)
                            )
                        }
                    }
                }
            }

            // BULUNAN CİHAZLAR LİSTESİ
            Text(
                "Taranan ve Bulunan Cihazlar (${allResults.size})", 
                fontWeight = FontWeight.Bold, 
                fontSize = 14.sp,
                color = MatcoTextPrimary
            )
            
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (allResults.isEmpty() && !isScanning) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "Henüz cihaz bulunamadı. Lütfen çift katmanlı taramayı başlatın.",
                                color = MatcoTextMuted,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                
                items(allResults) { result ->
                    val isLaunchVci = result.name.contains("DS401", ignoreCase = true) || 
                                      result.name.contains("Launch", ignoreCase = true) || 
                                      result.name.contains("XJLDS", ignoreCase = true)
                    
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = if (isLaunchVci) BorderStroke(2.dp, MatcoRed) else BorderStroke(1.dp, Color(0xFF1E293B))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            // Cihaz Detay Başlık
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            result.name, 
                                            fontWeight = FontWeight.Bold, 
                                            fontSize = 15.sp,
                                            color = MatcoTextPrimary
                                        )
                                        if (isLaunchVci) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                "VCI Adayı", 
                                                fontSize = 9.sp, 
                                                color = Color.Black, 
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier
                                                    .background(MatcoRed, RoundedCornerShape(2.dp))
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        result.address, 
                                        color = MatcoTextMuted, 
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                                
                                // Katman Etiketi Chip
                                val chipColor = when(result.layer) {
                                    "CLASSIC_BONDED" -> Color(0xFF2563EB)
                                    "CLASSIC_DISCOVERED" -> Color(0xFFD97706)
                                    else -> Color(0xFF16A34A)
                                }
                                val chipLabel = when(result.layer) {
                                    "CLASSIC_BONDED" -> "Eşleştirilmiş (Classic)"
                                    "CLASSIC_DISCOVERED" -> "Bulundu (Classic)"
                                    else -> "BLE"
                                }
                                Text(
                                    text = chipLabel,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .background(chipColor, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (result.rssi != null) {
                                        Text("RSSI: ${result.rssi} dBm", fontSize = 11.sp, color = MatcoTextMuted)
                                    }
                                    if (result.deviceClass != null) {
                                        Text("Sınıf: ${result.deviceClass}", fontSize = 11.sp, color = MatcoTextMuted)
                                    }
                                }
                                
                                val isTestingThis = testInProgressDevice == result.address
                                
                                Button(
                                    onClick = {
                                        val device: BluetoothDevice? = try {
                                            viewModel.dualScanner.log("BluetoothAdapter.getRemoteDevice(${result.address}) çağrılıyor...")
                                            viewModel.bluetoothOBDManager.getPairedDevices().find { it.address == result.address }
                                                ?: (context.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter.getRemoteDevice(result.address)
                                        } catch (e: Exception) {
                                            viewModel.dualScanner.log("getRemoteDevice hatası: ${e.message}")
                                            null
                                        }
                                        
                                        if (device == null) {
                                            Toast.makeText(context, "Bluetooth Aygıtı Çekilemedi", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        
                                        testInProgressDevice = result.address
                                        coroutineScope.launch {
                                            if (result.layer.startsWith("CLASSIC")) {
                                                testTypeInProgress = "SPP"
                                                viewModel.dualScanner.testClassicConnection(device)
                                            } else {
                                                testTypeInProgress = "BLE"
                                                viewModel.dualScanner.testBleConnection(device)
                                            }
                                            testInProgressDevice = null
                                            testTypeInProgress = null
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.defaultMinSize(minWidth = 1.dp, minHeight = 1.dp),
                                    enabled = testInProgressDevice == null && !isScanning
                                ) {
                                    if (isTestingThis) {
                                        CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 1.5.dp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Test...", fontSize = 12.sp)
                                    } else {
                                        Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("BU CİHAZI TEST ET", fontSize = 12.sp)
                                    }
                                }
                            }
                            
                            // Classic Cihazlar için Brute force Alternatifi
                            if (result.layer.startsWith("CLASSIC") && testInProgressDevice == null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Divider(color = Color(0xFF1E293B))
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = {
                                        val device: BluetoothDevice? = try {
                                            (context.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter.getRemoteDevice(result.address)
                                        } catch (e: Exception) { null }
                                        
                                        if (device == null) {
                                            Toast.makeText(context, "Bluetooth Aygıtı Çekilemedi", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        
                                        testInProgressDevice = result.address
                                        testTypeInProgress = "BRUTE_FORCE"
                                        coroutineScope.launch {
                                            viewModel.dualScanner.bruteForceRfcommChannels(device)
                                            testInProgressDevice = null
                                            testTypeInProgress = null
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = testInProgressDevice == null && !isScanning
                                ) {
                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.Yellow, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("⚡ TÜM KANALLARI ZORLA DENE (1-30)", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }

            // EN ALT EYLEMLER - LOG PAYLAŞ & ÖZET UYARI
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val file = viewModel.dualScanner.shareLogFile()
                        if (file != null && file.exists()) {
                            val uri = FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Fiziksel Teşhis Günlüğünü Paylaş"))
                        } else {
                            Toast.makeText(context, "Log dosyası oluşturulamadı", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    enabled = scanLog.isNotEmpty()
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📋 TÜM LOGU PAYLAŞ")
                }
                
                Button(
                    onClick = { showExplanationDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                ) {
                    Icon(Icons.Default.Help, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("💡 DÜRÜST ÖZET")
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = {
                    val filePath = viewModel.dualScanner.getLogFilePath()
                    val file = java.io.File(filePath)
                    if (file.exists()) {
                        val uri = try {
                            FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                        } catch (e: Exception) {
                            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Tanı Raporunu Paylaş"))
                    } else {
                        Toast.makeText(context, "Tanı Log Dosyası Henüz Oluşturulmadı", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("📤 TANI RAPORUNU PAYLAŞ", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }

    // DÜRÜST ÖZET DIALOG
    if (showExplanationDialog) {
        AlertDialog(
            onDismissRequest = { showExplanationDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CompassCalibration, contentDescription = null, tint = MatcoRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Fiziksel Teşhis Sonuç Özeti", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    text = "X farklı yöntem denendi. Hiçbiri yanıt vermediysa:\n\n" +
                           "Bu, cihazın [Classic/BLE] seviyesinde erişilebilir olduğunu ama [ELM327 AT komutlarına / herhangi bir genel pingsine] yanıt vermediğini KANITLAR.\n\n" +
                           "Sonraki adım: Cihazın kendi orijinal yazılımı ile aynı telefonda bağlanırken Android Geliştirici Seçenekleri > Bluetooth HCI snoop log açıp gerçek trafiği yakalamak (bu en kesin yöntem, kaçınılmaz).",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                TextButton(onClick = { showExplanationDialog = false }) {
                    Text("Anladım")
                }
            }
        )
    }
}
