package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OBDMonitorTest
import com.example.data.TestResult
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Mode06Screen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("TEST SONUÇLARI", "KARŞILAŞTIR")

    val tests by viewModel.mode06Tests.collectAsState()
    val isLoading by viewModel.mode06Loading.collectAsState()
    val snapshots by viewModel.mode06Snapshots.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerAlpha"
    )

    // Trigger test read on screen entrance if list is empty
    LaunchedEffect(Unit) {
        if (tests.isEmpty()) {
            viewModel.readMode06Tests()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "OBD2 Mode 06 Testleri",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("mode06_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoDark,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = MatcoBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // M3 TabRow
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MatcoDark,
                contentColor = MatcoRed,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = MatcoRed
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp,
                                color = if (selectedTab == index) MatcoRed else MatcoTextMuted
                            )
                        }
                    )
                }
            }

            if (selectedTab == 0) {
                // TAB 1: TEST RESULTS
                TestResultsTab(
                    tests = tests,
                    isLoading = isLoading,
                    shimmerAlpha = shimmerAlpha,
                    onReadTests = {
                        coroutineScope.launch {
                            viewModel.readMode06Tests()
                        }
                    },
                    onSaveSnapshot = {
                        viewModel.saveMode06Snapshot()
                    }
                )
            } else {
                // TAB 2: COMPARE TARGET
                CompareTab(
                    snapshots = snapshots,
                    onClear = {
                        viewModel.clearMode06Snapshots()
                    },
                    onTriggerReadAndSave = {
                        coroutineScope.launch {
                            viewModel.readMode06Tests()
                            viewModel.saveMode06Snapshot()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun TestResultsTab(
    tests: List<OBDMonitorTest>,
    isLoading: Boolean,
    shimmerAlpha: Float,
    onReadTests: () -> Unit,
    onSaveSnapshot: () -> Unit
) {
    if (isLoading) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Shimmer Summary Info Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .background(MatcoCard.copy(alpha = shimmerAlpha), RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, MatcoCardBorder.copy(alpha = shimmerAlpha)), RoundedCornerShape(8.dp))
            )

            // Dynamic repeats for groups
            repeat(4) {
                Box(
                    modifier = Modifier
                        .width(140.dp)
                        .height(14.dp)
                        .background(MatcoTextMuted.copy(alpha = shimmerAlpha), RoundedCornerShape(3.dp))
                )
                repeat(2) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(MatcoCard.copy(alpha = shimmerAlpha), RoundedCornerShape(10.dp))
                            .border(BorderStroke(1.dp, MatcoCardBorder.copy(alpha = shimmerAlpha)), RoundedCornerShape(10.dp))
                    )
                }
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Summary bar
                val passed = tests.count { it.result == TestResult.PASSED }
                val failed = tests.count { it.result == TestResult.FAILED }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.35f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(Color(0xFF22C55E), RoundedCornerShape(5.dp))
                                )
                                Text(
                                    text = "$passed GEÇTİ",
                                    color = Color(0xFF22C55E),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .width(1.dp)
                                    .height(24.dp)
                                    .background(MatcoCardBorder.copy(alpha = 0.25f))
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(MatcoRed, RoundedCornerShape(5.dp))
                                )
                                Text(
                                    text = "$failed KALDI",
                                    color = MatcoRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                if (tests.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "No data",
                                tint = MatcoTextMuted,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Kayıtlı Mode 06 verisi bulunmamaktadır.",
                                color = MatcoTextMuted,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    // Group by modules
                    val grouped = tests.groupBy { it.module }

                    grouped.forEach { (module, moduleTests) ->
                        item {
                            Text(
                                text = "▪ ${module.uppercase()}",
                                fontWeight = FontWeight.Bold,
                                color = MatcoTextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }

                        items(moduleTests) { test ->
                            TestResultCard(test = test)
                        }
                    }
                }
            }

            // Bottom Buttons Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onReadTests,
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("mode06_read_button")
                ) {
                    Text(
                        text = "📡 TESTLERİ OKU",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }

                Button(
                    onClick = onSaveSnapshot,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MatcoCard,
                        contentColor = Color.White
                    ),
                    border = BorderStroke(1.dp, MatcoCardBorder),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(12f / 10f)
                        .height(48.dp),
                    enabled = tests.isNotEmpty()
                ) {
                    Text(
                        text = "💾 ANLIK GÖRÜNTÜ",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun TestResultCard(test: OBDMonitorTest) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.25f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = test.description,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "TID: ${test.testId}  •  CID: ${test.componentId}",
                        fontSize = 11.sp,
                        color = MatcoTextMuted,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Result Badge
                val badgeColor = if (test.result == TestResult.PASSED) Color(0xFF22C55E) else MatcoRed
                val labelText = if (test.result == TestResult.PASSED) "✅ GEÇTİ" else "❌ KALDI"

                Box(
                    modifier = Modifier
                        .background(badgeColor.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .border(BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f)), RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = labelText,
                        color = badgeColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Values Metadata Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MİN: ${test.minLimit} ${test.unit}",
                    fontSize = 11.sp,
                    color = MatcoTextMuted,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Mevcut: ${test.actualValue} ${test.unit}",
                    fontSize = 13.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "MAX: ${test.maxLimit} ${test.unit}",
                    fontSize = 11.sp,
                    color = MatcoTextMuted,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Custom Limit Canvas
            MockLimitIndicator(
                min = test.minLimit,
                max = test.maxLimit,
                current = test.actualValue
            )
        }
    }
}

@Composable
fun MockLimitIndicator(min: Float, max: Float, current: Float) {
    // Canvas size parameters
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Calculate ratios & safe coordinates
            val range = max - min
            val drawRange = if (range <= 0) 1.0f else range
            val padding = drawRange * 0.35f
            val startVal = maxOf(0f, min - padding)
            val endVal = max + padding
            val fullSpan = endVal - startVal

            val minX = if (fullSpan > 0f) ((min - startVal) / fullSpan) * width else 0.2f * width
            val maxX = if (fullSpan > 0f) ((max - startVal) / fullSpan) * width else 0.8f * width
            val currentX = if (fullSpan > 0f) ((current - startVal) / fullSpan) * width else 0.5f * width
            val clampedCurrentX = currentX.coerceIn(0f, width)

            // 1. Draw track
            drawRoundRect(
                color = Color(0xFF1E293B),
                size = Size(width, 6.dp.toPx()),
                topLeft = Offset(0f, height / 2 - 3.dp.toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx(), 3.dp.toPx())
            )

            // 2. Draw safe/green zone rectangle
            drawRect(
                color = Color(0x3322C55E),
                topLeft = Offset(minX, height / 2 - 3.dp.toPx()),
                size = Size(maxX - minX, 6.dp.toPx())
            )

            // 3. Draw limit boundary ticks
            drawLine(
                color = Color(0x9964748B),
                start = Offset(minX, height / 2 - 6.dp.toPx()),
                end = Offset(minX, height / 2 + 6.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = Color(0x9964748B),
                start = Offset(maxX, height / 2 - 6.dp.toPx()),
                end = Offset(maxX, height / 2 + 6.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )

            // 4. Draw current red pointer point
            drawCircle(
                color = Color(0xFFEF4444),
                radius = 6.dp.toPx(),
                center = Offset(clampedCurrentX, height / 2)
            )

            // Inner pointer shine
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = Offset(clampedCurrentX, height / 2)
            )
        }
    }
}

@Composable
fun CompareTab(
    snapshots: List<com.example.data.Mode06Snapshot>,
    onClear: () -> Unit,
    onTriggerReadAndSave: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        if (snapshots.isEmpty()) {
            EmptyCompareState(
                message = "Test sonucu kaydetmek için önce TARAYINız",
                buttonText = "İŞLEMİ BAŞLAT VE KAYDET",
                onTrigger = onTriggerReadAndSave
            )
        } else if (snapshots.size == 1) {
            val snap = snapshots[0]
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.25f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "📌 1 Kayıt Alındı",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF22C55E),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = snap.label,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "${snap.tests.size} Test Noktası",
                        color = MatcoTextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            EmptyCompareState(
                message = "İkinci tarama için TESTLERİ OKU ve KAYDET yapın",
                buttonText = "İKİNCİ TARAMAYI YAP VEYA KAYDET",
                onTrigger = onTriggerReadAndSave
            )
        } else {
            // Exactly 2 snapshots
            val s1 = snapshots[0]
            val s2 = snapshots[1]

            // Headers card
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "TARAMA 1",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF59E0B)
                        )
                        Text(
                            text = s1.label.split(" — ").getOrNull(1) ?: s1.label,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.CompareArrows,
                        contentDescription = "Karşılaştır",
                        tint = MatcoRed,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "TARAMA 2",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF22C55E)
                        )
                        Text(
                            text = s2.label.split(" — ").getOrNull(1) ?: s2.label,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Compare Table / LazyColumn
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(s1.tests) { test1 ->
                    // Find matching test in s2
                    val test2 = s2.tests.firstOrNull { it.testId == test1.testId }
                    if (test2 != null) {
                        CompareRowItem(t1 = test1, t2 = test2)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // RESET button
            Button(
                onClick = onClear,
                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Sıfırla", tint = Color.White)
                    Text(
                        text = "SIFIRLA",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun CompareRowItem(t1: OBDMonitorTest, t2: OBDMonitorTest) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.15f)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = t1.description,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "TID: ${t1.testId} • Birim: ${t1.unit}",
                fontSize = 10.sp,
                color = MatcoTextMuted
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // T1 Value
                Column(modifier = Modifier.weight(1f)) {
                    val t1Color = if (t1.result == TestResult.PASSED) Color(0xFF22C55E) else MatcoRed
                    Text(
                        text = "${t1.actualValue} ${t1.unit}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = t1Color
                    )
                    Text(
                        text = if (t1.result == TestResult.PASSED) "GEÇTİ" else "KALDI",
                        fontSize = 9.sp,
                        color = t1Color,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Trend indicator
                // Evaluate smart heuristic
                val (trendIcon, trendColor, trendText) = evaluateTrend(t1, t2)

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Icon(
                        imageVector = trendIcon,
                        contentDescription = trendText,
                        tint = trendColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = trendText,
                        fontSize = 9.sp,
                        color = trendColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                // T2 Value
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.End
                ) {
                    val t2Color = if (t2.result == TestResult.PASSED) Color(0xFF22C55E) else MatcoRed
                    Text(
                        text = "${t2.actualValue} ${t2.unit}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = t2Color
                    )
                    Text(
                        text = if (t2.result == TestResult.PASSED) "GEÇTİ" else "KALDI",
                        fontSize = 9.sp,
                        color = t2Color,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// Evaluate smart trend heuristic
@Composable
fun evaluateTrend(t1: OBDMonitorTest, t2: OBDMonitorTest): Triple<androidx.compose.ui.graphics.vector.ImageVector, Color, String> {
    // If the test result changed
    if (t1.result == TestResult.FAILED && t2.result == TestResult.PASSED) {
        return Triple(Icons.Default.ArrowUpward, Color(0xFF22C55E), "İYİLEŞTİ")
    }
    if (t1.result == TestResult.PASSED && t2.result == TestResult.FAILED) {
        return Triple(Icons.Default.ArrowDownward, MatcoRed, "KÖTÜLEŞTİ")
    }

    // If both passed or both failed, evaluate actual value variation
    val v1 = t1.actualValue
    val v2 = t2.actualValue

    // EVAP or EGR - lower leaks/values are better
    if (t1.module == "EVAP" || t1.module == "EGR") {
        return if (v2 < v1) {
            Triple(Icons.Default.ArrowUpward, Color(0xFF22C55E), "İYİLEŞTİ")
        } else if (v2 > v1) {
            Triple(Icons.Default.ArrowDownward, MatcoRed, "KÖTÜLEŞTİ")
        } else {
            Triple(Icons.Default.CompareArrows, MatcoTextMuted, "STABİL")
        }
    }

    // Voltages or others: closer to limits midpoint is better
    val mid = (t1.minLimit + t1.maxLimit) / 2f
    val dev1 = kotlin.math.abs(v1 - mid)
    val dev2 = kotlin.math.abs(v2 - mid)

    return if (dev2 < dev1 - 0.001f) {
        Triple(Icons.Default.ArrowUpward, Color(0xFF22C55E), "İYİLEŞTİ")
    } else if (dev2 > dev1 + 0.001f) {
        Triple(Icons.Default.ArrowDownward, MatcoRed, "KÖTÜLEŞTİ")
    } else {
        Triple(Icons.Default.CompareArrows, MatcoTextMuted, "STABİL")
    }
}

@Composable
fun EmptyCompareState(
    message: String,
    buttonText: String,
    onTrigger: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = MatcoAccent,
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = message,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MatcoTextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onTrigger,
                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = buttonText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
