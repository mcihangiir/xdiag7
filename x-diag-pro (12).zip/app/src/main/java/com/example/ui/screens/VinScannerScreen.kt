package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size as GeometrySize
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.MatcoBlack
import com.example.ui.theme.MatcoCard
import com.example.ui.theme.MatcoCardBorder
import com.example.ui.theme.MatcoRed
import com.example.ui.theme.MatcoTextMuted
import com.example.viewmodel.DiagnosticViewModel
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VinScannerScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val scannedVin by viewModel.scannedVin.collectAsState()
    val decodeLoading by viewModel.vinDecodeLoading.collectAsState()
    val decodeResult by viewModel.vinDecodeResult.collectAsState()
    
    var manualVin by remember { mutableStateOf("") }
    var showBottomSheet by remember { mutableStateOf(false) }

    LaunchedEffect(scannedVin) {
        if (scannedVin != null) {
            showBottomSheet = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("VIN TARAYICI", fontWeight = FontWeight.Black, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoBlack,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            if (hasCameraPermission) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    // Camera Preview
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx)
                            val executor = ContextCompat.getMainExecutor(ctx)
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }

                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setTargetResolution(Size(1280, 720))
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()

                                val scanner = BarcodeScanning.getClient()

                                imageAnalysis.setAnalyzer(Executors.newSingleThreadExecutor()) { imageProxy ->
                                    val mediaImage = imageProxy.image
                                    if (mediaImage != null && scannedVin == null) {
                                        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                        scanner.process(image)
                                            .addOnSuccessListener { barcodes ->
                                                for (barcode in barcodes) {
                                                    val rawValue = barcode.rawValue ?: continue
                                                    val cleanValue = rawValue.uppercase().replace(Regex("[^A-HJ-NPR-Z0-9]"), "")
                                                    if (cleanValue.length == 17) {
                                                        viewModel.setScannedVin(cleanValue)
                                                        break
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                                imageProxy.close()
                                            }
                                    } else {
                                        imageProxy.close()
                                    }
                                }

                                try {
                                    cameraProvider.unbindAll()
                                    cameraProvider.bindToLifecycle(
                                        lifecycleOwner,
                                        CameraSelector.DEFAULT_BACK_CAMERA,
                                        preview,
                                        imageAnalysis
                                    )
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }, executor)

                            previewView
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay
                    ScannerOverlay()
                }
            } else {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(64.dp), tint = MatcoTextMuted)
                        Text("Kamera izni gerekli", color = Color.White, fontWeight = FontWeight.Bold)
                        Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }, colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)) {
                            Text("İzin İste")
                        }
                    }
                }
            }

            // Manual Entry
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Veya Manuel Olarak Girin", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    OutlinedTextField(
                        value = manualVin,
                        onValueChange = { 
                            val filtered = it.uppercase().replace(Regex("[^A-HJ-NPR-Z0-9]"), "").take(17)
                            manualVin = filtered
                            if (filtered.length == 17) {
                                viewModel.setScannedVin(filtered)
                            }
                        },
                        placeholder = { Text("17 Haneli VIN", color = MatcoTextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MatcoRed,
                            unfocusedBorderColor = MatcoCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Done),
                        trailingIcon = {
                            Text("${manualVin.length}/17", color = MatcoTextMuted, fontSize = 12.sp, modifier = Modifier.padding(end = 12.dp))
                        }
                    )
                }
            }
        }
    }

    if (showBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { 
                showBottomSheet = false 
                // Don't reset scanned VIN so we can open it again if needed,
                // or maybe we should to rescan. Let's reset so user can scan again.
                // Normally we'd add a reset method, but we can manage local state for scan restart.
            },
            containerColor = MatcoCard,
            dragHandle = { BottomSheetDefaults.DragHandle(color = MatcoTextMuted) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = scannedVin ?: manualVin,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp,
                    color = Color.White,
                    letterSpacing = 2.sp
                )

                if (decodeLoading) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(color = MatcoRed, modifier = Modifier.size(36.dp))
                        Text("NHTSA'dan Çözümleniyor...", color = MatcoTextMuted, fontSize = 14.sp)
                    }
                } else {
                    if (decodeResult != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoBlack),
                            modifier = Modifier.fillMaxWidth(),
                            border = borderStroke()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                DetailRow("Marka", decodeResult?.make)
                                DetailRow("Model", decodeResult?.model)
                                DetailRow("Yıl", decodeResult?.year?.toString())
                                DetailRow("Motor", "${decodeResult?.engineDisplacement ?: ""}L ${decodeResult?.engineCylinders ?: ""} Cyl")
                                DetailRow("Yakıt Tipi", decodeResult?.fuelType)
                                DetailRow("Kasa", decodeResult?.bodyClass)
                                DetailRow("Ülke", decodeResult?.country)
                            }
                        }

                        Button(
                            onClick = { 
                                showBottomSheet = false
                                onBack() 
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("BU ARACI SEÇ", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF9800))
                            Text("VIN çözümlenemedi. Model yılı veya marka bulunamadı.", color = Color(0xFFFF9800), fontSize = 14.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            showBottomSheet = false
                            manualVin = ""
                            // Need to clear scannedVin in viewModel to allow rescanning same barcode
                            // For simplicity, we can just close sheet and let CameraX capture again if it's a DIFFERENT barcode,
                            // or better, we restart the scan by clearing it.
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = borderStroke(),
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("YENİDEN TARA", fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun ScannerOverlay() {
    val infiniteTransition = rememberInfiniteTransition(label = "scan")
    val lineOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scan_line"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            val rectWidth = canvasWidth * 0.8f
            val rectHeight = 160.dp.toPx()
            
            val left = (canvasWidth - rectWidth) / 2f
            val top = (canvasHeight - rectHeight) / 2f
            val right = left + rectWidth
            val bottom = top + rectHeight

            // Draw dark overlay covering everything except the center rect
            drawRect(color = Color.Black.copy(alpha = 0.6f))
            drawRect(
                color = Color.Transparent,
                topLeft = Offset(left, top),
                size = GeometrySize(rectWidth, rectHeight),
                blendMode = androidx.compose.ui.graphics.BlendMode.Clear
            )

            // Draw brackets
            val bracketLength = 30.dp.toPx()
            val bracketStroke = 4.dp.toPx()
            val bracketColor = Color(0xFFEF4444) // MatcoRed

            // Top Left
            drawLine(bracketColor, Offset(left, top), Offset(left + bracketLength, top), bracketStroke, StrokeCap.Round)
            drawLine(bracketColor, Offset(left, top), Offset(left, top + bracketLength), bracketStroke, StrokeCap.Round)
            // Top Right
            drawLine(bracketColor, Offset(right, top), Offset(right - bracketLength, top), bracketStroke, StrokeCap.Round)
            drawLine(bracketColor, Offset(right, top), Offset(right, top + bracketLength), bracketStroke, StrokeCap.Round)
            // Bottom Left
            drawLine(bracketColor, Offset(left, bottom), Offset(left + bracketLength, bottom), bracketStroke, StrokeCap.Round)
            drawLine(bracketColor, Offset(left, bottom), Offset(left, bottom - bracketLength), bracketStroke, StrokeCap.Round)
            // Bottom Right
            drawLine(bracketColor, Offset(right, bottom), Offset(right - bracketLength, bottom), bracketStroke, StrokeCap.Round)
            drawLine(bracketColor, Offset(right, bottom), Offset(right, bottom - bracketLength), bracketStroke, StrokeCap.Round)

            // Scanning line
            val scanLineY = top + (rectHeight * lineOffset)
            drawLine(
                color = bracketColor.copy(alpha = 0.8f),
                start = Offset(left + 10f, scanLineY),
                end = Offset(right - 10f, scanLineY),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        Text(
            text = "VIN barkodunu çerçeve içine alın",
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-110).dp),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String?) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MatcoTextMuted, fontSize = 13.sp)
        Text(value ?: "-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun borderStroke() = androidx.compose.foundation.BorderStroke(1.dp, MatcoCardBorder)
