package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.Screen
import com.example.ui.theme.MatcoRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserInfoScreen(
    onNavigate: (String) -> Unit,
    onBack: () -> Unit
) {
    val menuItems = listOf(
        UserInfoItem("Raporum", Icons.Default.Description, Color(0xFF0EA5E9), Screen.History.route),
        UserInfoItem("VCI", Icons.Default.Bluetooth, Color(0xFF84CC16), Screen.VciManager.route),
        UserInfoItem("VCI'yi Etkinleştir", Icons.Default.NetworkCheck, Color(0xFF0EA5E9), Screen.VciManager.route),
        UserInfoItem("Konnektör ürün yazılımı/sistemi düzeltin", Icons.Default.Build, Color(0xFFEF4444), Screen.SoftwareUpdate.route),
        UserInfoItem("ADAS equipment selection", Icons.Default.Monitor, Color(0xFF3B82F6), Screen.AdasCalibration.route),
        UserInfoItem("Veri Akışı Örneği", Icons.Default.ShowChart, Color(0xFF3B82F6), Screen.DataRecording.route),
        UserInfoItem("Araç Voltajı", Icons.Default.BatteryChargingFull, Color(0xFF84CC16), Screen.VoltageAnalysis.route),
        UserInfoItem("Profil", Icons.Default.AccountBox, Color(0xFFF59E0B), ""),
        UserInfoItem("Şifreyi Değiştir", Icons.Default.Lock, Color(0xFF0EA5E9), ""),
        UserInfoItem("Ayarlar", Icons.Default.Settings, Color(0xFF84CC16), Screen.Settings.route),
        UserInfoItem("Tanılama Yazılımı Temizle", Icons.Default.Delete, Color(0xFFEF4444), "")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("User Info", color = Color.White, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFBB1E1E)),
                actions = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.Home, contentDescription = "Home", tint = Color.White)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F0F0))
                .padding(innerPadding)
        ) {
            items(menuItems) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (item.route.isNotEmpty()) onNavigate(item.route) }
                        .background(Color.White)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(item.iconColor, shape = MaterialTheme.shapes.small),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.title,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = item.title,
                        fontSize = 15.sp,
                        color = Color(0xFF333333)
                    )
                }
                HorizontalDivider(color = Color(0xFFDCDCDC), thickness = 1.dp)
            }
        }
    }
}

data class UserInfoItem(
    val title: String,
    val icon: ImageVector,
    val iconColor: Color,
    val route: String
)
