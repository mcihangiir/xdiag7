package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AlternatorStatus
import com.example.data.BatteryHealth
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.VoltageTestPhase
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoltageAnalysisScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()
    val voltageHistory by viewModel.voltageHistory.collectAsState()
    val testResult by viewModel.voltageTestResult.collectAsState()
    val testPhase by viewModel.voltageTestPhase.collectAsState()

    // Gauge or text color based on voltage values
    val voltageColor = when {
        batteryVoltage > 13.5f -> Color(0xFF22C55E) // Green for charging / running
        batteryVoltage >= 12.0f -> Color.White       // Standard offline battery
        else -> MatcoRed                             // Low battery danger
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Akü & Şarj Sistemi Analizi",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("voltage_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoDark,
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = MatcoBlack
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // 1. ÜST BÜYÜK VOLTAJ GÖSTERGESİ (Large Indicator)
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoDark),
                border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ANLIK AKÜ VOLTAJI",
                        fontSize = 11.sp,
                        color = MatcoTextMuted,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.5.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Sparkle gauge circular arc background
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(140.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Draw background faint grey arc
                            drawArc(
                                color = Color.White.copy(alpha = 0.08f),
                                startAngle = 135f,
                                sweepAngle = 270f,
                                useCenter = false,
                                style = Stroke(width = 12.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                            )

                            // Map voltage 10V - 16V to 0 - 270 sweep angle
                            val percent = ((batteryVoltage - 10f) / 6f).coerceIn(0f, 1f)
                            drawArc(
                                color = voltageColor,
                                startAngle = 135f,
                                sweepAngle = 270f * percent,
                                useCenter = false,
                                style = Stroke(width = 12.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                            )
                        }

                        // Inside text
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = String.format("%.2f", batteryVoltage),
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Black,
                                color = voltageColor
                            )
                            Text(
                                text = "Volt GERİLİM",
                                fontSize = 10.sp,
                                color = MatcoTextMuted,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = when {
                            batteryVoltage > 13.5f -> "Alternatör Şarj Ediyor (Motor Çalışıyor)"
                            batteryVoltage >= 12.5f -> "Akü Dinlenme Durumunda (Dolu)"
                            batteryVoltage >= 12.0f -> "Akü Seviyesi Normal (Orta/Zayıf)"
                            else -> "Kritik Derecede Düşük Voltaj!"
                        },
                        color = if (batteryVoltage < 12.0f) MatcoRed else Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // 2. VOLTAJ GRAFİĞİ (Canvas)
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "GERİLİM GRAFİK ANALİZİ (Son 60 Saniye)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MatcoTextMuted
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(modifier = Modifier.fillMaxSize()) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            val minV = 10.0f
                            val maxV = 16.0f
                            val range = maxV - minV

                            fun getRawY(v: Float): Float {
                                val norm = (v - minV) / range
                                return h - (norm.coerceIn(0f, 1f) * h)
                            }

                            // A. DRAW BACKGROUND BANDS
                            // 1. Alternator overcharge (> 14.8V) - Light Red band
                            val y14_8 = getRawY(14.8f)
                            drawRect(
                                color = MatcoRed.copy(alpha = 0.12f),
                                topLeft = Offset(0f, 0f),
                                size = Size(w, y14_8)
                            )

                            // 2. Alternator normal charging (13.8V - 14.8V) - Light Green band
                            val y13_8 = getRawY(13.8f)
                            drawRect(
                                color = Color(0x1522C55E),
                                topLeft = Offset(0f, y14_8),
                                size = Size(w, y13_8 - y14_8)
                            )

                            // 3. Low Battery Danger (< 12.0V) - Light Red band at bottom
                            val y12_0 = getRawY(12.0f)
                            drawRect(
                                color = MatcoRed.copy(alpha = 0.12f),
                                topLeft = Offset(0f, y12_0),
                                size = Size(w, h - y12_0)
                            )

                            // B. DRAW REFERENCE DOTTED HORIZONTAL LINES
                            val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                            val references = listOf(14.8f, 13.8f, 12.6f, 12.0f)
                            references.forEach { rf ->
                                val ry = getRawY(rf)
                                drawLine(
                                    color = Color.White.copy(alpha = 0.2f),
                                    start = Offset(0f, ry),
                                    end = Offset(w, ry),
                                    pathEffect = pathEffect,
                                    strokeWidth = 2f
                                )
                            }

                            // Add labels for references on side
                            // We will approximate drawing but canvas context coordinates are simple.
                            // In Compose DrawScope, we focus simply on lines. Let's draw the history lines.

                            // C. DRAW VOLTAGE HISTORY WAVE
                            if (voltageHistory.isNotEmpty()) {
                                val historyPath = Path()
                                val pts = voltageHistory.takeLast(60)
                                val stepX = w / 59f // up to 60 points

                                pts.forEachIndexed { idx, value ->
                                    val x = idx * stepX
                                    val y = getRawY(value)
                                    if (idx == 0) {
                                        historyPath.moveTo(x, y)
                                    } else {
                                        historyPath.lineTo(x, y)
                                    }
                                }

                                drawPath(
                                    path = historyPath,
                                    color = voltageColor,
                                    style = Stroke(width = 6f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                )

                                // Current pointer point at the rightmost edge
                                val lastX = (pts.size - 1) * stepX
                                val lastY = getRawY(pts.last())
                                drawCircle(
                                    color = MatcoRed,
                                    radius = 5.dp.toPx(),
                                    center = Offset(lastX, lastY)
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 2.dp.toPx(),
                                    center = Offset(lastX, lastY)
                                )
                            }
                        }

                        // Superimpose small labels on the left of Canvas using Column/Box or Compose modifiers
                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(vertical = 2.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("16.0V", fontSize = 8.sp, color = MatcoTextMuted, fontWeight = FontWeight.Bold)
                            Text("14.8V (Limit)", fontSize = 8.sp, color = MatcoRed.copy(0.7f), fontWeight = FontWeight.Bold)
                            Text("13.8V (Şarj)", fontSize = 8.sp, color = Color(0xFF22C55E).copy(0.7f), fontWeight = FontWeight.Bold)
                            Text("12.6V (Dolu)", fontSize = 8.sp, color = MatcoTextMuted, fontWeight = FontWeight.Bold)
                            Text("12.0V (Düşük)", fontSize = 8.sp, color = MatcoRed.copy(0.7f), fontWeight = FontWeight.Bold)
                            Text("10.0V", fontSize = 8.sp, color = MatcoTextMuted, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 3. DIAGNOSTIC PROGRESS STEP INDICATORS (While testing is active)
            if (testPhase != VoltageTestPhase.Idle) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoDark),
                    border = BorderStroke(1.dp, MatcoRed.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "VOLTAJ TEST SÜRECİ AKIŞI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MatcoAccent,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Test current instructions
                        val descriptionString = when(testPhase) {
                            VoltageTestPhase.MeasuringResting -> "FAZ 1: Dinlenim gerilimi ölçülüyor. Marş basmayın..."
                            VoltageTestPhase.WaitingForCrank -> "FAZ 2: Lütfen MOTORU ÇALIŞTIRMAK İÇİN MARŞA BASIN!"
                            VoltageTestPhase.MeasuringCranking -> "FAZ 2: Krank/Marş anındaki dalgalanma ölçülüyor..."
                            VoltageTestPhase.WaitingForEngine -> "FAZ 3: Devirlerin stabilize olması bekleniyor..."
                            VoltageTestPhase.MeasuringCharging -> "FAZ 3: Alternatör şarj gerilimi analiz ediliyor..."
                            VoltageTestPhase.Done -> "Ölçümler bitti! Aşağıdan sonuçları analiz edebilirsiniz."
                            else -> ""
                        }

                        Text(
                            text = descriptionString,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Render Step Nodes (1 to 6)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val steps = listOf(
                                Triple("Dinlenim", VoltageTestPhase.MeasuringResting, 1),
                                Triple("Marş Bekleme", VoltageTestPhase.WaitingForCrank, 2),
                                Triple("Marş Ölçüm", VoltageTestPhase.MeasuringCranking, 3),
                                Triple("Motor Stabil", VoltageTestPhase.WaitingForEngine, 4),
                                Triple("Şarj Ölçüm", VoltageTestPhase.MeasuringCharging, 5),
                                Triple("Tamamlandı", VoltageTestPhase.Done, 6)
                            )

                            steps.forEach { stepTuple ->
                                val stepName = stepTuple.first
                                val stepPhase = stepTuple.second
                                val stepNum = stepTuple.third

                                val isCompleted = getStepIndex(testPhase) >= stepNum
                                val isActive = testPhase == stepPhase

                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(24.dp)
                                            .background(
                                                color = when {
                                                    isActive -> MatcoRed
                                                    isCompleted -> Color(0xFF22C55E)
                                                    else -> Color(0xFF1E293B)
                                                },
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                    ) {
                                        if (isCompleted && !isActive) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        } else {
                                            Text(
                                                text = "$stepNum",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = stepName,
                                        fontSize = 8.sp,
                                        color = if (isActive) MatcoRed else MatcoTextMuted,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 10.sp,
                                        fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 4. CONDITIONAL WARNING BANNERS (UYARI PANKARTLARI)
            testResult?.let { result ->
                // Check failed alternator status
                if (result.alternatorStatus == AlternatorStatus.FAILED) {
                    WarningBanner(
                        title = "⚠️ ALTERNATÖR ARIZASI ŞÜPHESİ!",
                        desc = "Alternatör şarj gerilimi kritik limitin altında (${result.chargingVoltage}V). Akü şarj edilemiyor, alternatör konnektörünü ve kayışı kontrol edin.",
                        color = MatcoRed
                    )
                }
                
                // Check weak or critical battery health
                if (result.batteryHealth == BatteryHealth.CRITICAL) {
                    WarningBanner(
                        title = "🔋 AKÜ DEĞİŞTİRİLMELİ!",
                        desc = "Akü dinlenme gerilimi çok düşük (${result.restingVoltage}V). Akünüz ömrünü doldurmuş olabilir, yetkili servise başvurun.",
                        color = MatcoRed
                    )
                }

                // Check low cranking voltage
                if (result.crankingVoltage < 9.6f) {
                    WarningBanner(
                        title = "⚡ MARŞ VOLTAJI ÇOK DÜŞÜK!",
                        desc = "Marş anındaki çöküş gerilimi oldukça zayıf (${result.crankingVoltage}V). Standart eşik 9.6V'tur. Sıkışık havalarda çalıştırma zorlaşabilir.",
                        color = Color(0xFFF59E0B)
                    )
                }
            }

            // 5. AKÜ SAĞLIĞI KARTI (Test Results Dashboard Card)
            testResult?.let { result ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoDark),
                    border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "AKÜ REÇETESİ VE TEST ÖZETİ",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left Circle health meter gauge
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(100.dp)
                                    .weight(1f)
                            ) {
                                val sweepArc = when (result.batteryHealth) {
                                    BatteryHealth.EXCELLENT -> 270f
                                    BatteryHealth.GOOD -> 210f
                                    BatteryHealth.FAIR -> 150f
                                    BatteryHealth.WEAK -> 90f
                                    BatteryHealth.CRITICAL -> 45f
                                }

                                val arcColor = when (result.batteryHealth) {
                                    BatteryHealth.EXCELLENT -> Color(0xFF22C55E)
                                    BatteryHealth.GOOD -> Color(0xFF84CC16)
                                    BatteryHealth.FAIR -> Color(0xFFEAB308)
                                    BatteryHealth.WEAK -> Color(0xFFF97316)
                                    BatteryHealth.CRITICAL -> MatcoRed
                                }

                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawArc(
                                        color = Color.White.copy(alpha = 0.05f),
                                        startAngle = 135f,
                                        sweepAngle = 270f,
                                        useCenter = false,
                                        style = Stroke(width = 8.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                    )

                                    drawArc(
                                        color = arcColor,
                                        startAngle = 135f,
                                        sweepAngle = sweepArc,
                                        useCenter = false,
                                        style = Stroke(width = 8.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = when(result.batteryHealth) {
                                            BatteryHealth.EXCELLENT -> "MÜKEMMEL"
                                            BatteryHealth.GOOD -> "İYİ"
                                            BatteryHealth.FAIR -> "ORTA"
                                            BatteryHealth.WEAK -> "ZAYIF"
                                            BatteryHealth.CRITICAL -> "KRİTİK"
                                        },
                                        fontWeight = FontWeight.Black,
                                        fontSize = 11.sp,
                                        color = arcColor,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "SAĞLIK",
                                        fontSize = 8.sp,
                                        color = MatcoTextMuted,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            // Right side measurements table
                            Column(
                                modifier = Modifier.weight(1.5f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MeasurementRow(label = "Dinlenim Voltajı", value = String.format("%.2f V", result.restingVoltage))
                                MeasurementRow(label = "Marş Voltajı", value = String.format("%.2f V", result.crankingVoltage), highlight = result.crankingVoltage < 9.6f)
                                MeasurementRow(label = "Şarj Gerilimi", value = String.format("%.2f V", result.chargingVoltage))
                                
                                val statusTextStr = when(result.alternatorStatus) {
                                    AlternatorStatus.GOOD -> "Normal Şarj"
                                    AlternatorStatus.OVERCHARGE -> "Aşırı Şarj!"
                                    AlternatorStatus.UNDERCHARGE -> "Yetersiz Şarj"
                                    AlternatorStatus.FAILED -> "Alternatör Arıza!"
                                }
                                val statusColor = when(result.alternatorStatus) {
                                    AlternatorStatus.GOOD -> Color(0xFF22C55E)
                                    AlternatorStatus.OVERCHARGE -> Color(0xFFF97316)
                                    else -> MatcoRed
                                }
                                MeasurementRow(label = "Şarj Alternatörü", value = statusTextStr, statusColor = statusColor)
                            }
                        }
                    }
                }
            }

            // 6. ACTION TRIGGER BUTTON (“TAM VOLTAJ TESTİ BAŞLAT”)
            val buttonEnabled = testPhase == VoltageTestPhase.Idle || testPhase == VoltageTestPhase.Done
            Button(
                onClick = { viewModel.startVoltageTest() },
                enabled = buttonEnabled,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MatcoRed,
                    disabledContainerColor = MatcoCardBorder.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("start_voltage_test_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!buttonEnabled) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = "TEST KOŞULUYOR...",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.BatteryChargingFull,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Text(
                            text = "🔋 TAM VOLTAJ ANALİZ TESTİNİ BAŞLAT",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            // Quick instruction footer note
            Text(
                text = "Tam voltaj analizi; Dinlenim, Krank/Marş anı düşümü ve Alternatör şarj gerilimlerini kombine ederek akü durumunu hassasiyetle ölçekler.",
                color = MatcoTextMuted,
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                lineHeight = 14.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }
    }
}

@Composable
fun MeasurementRow(
    label: String,
    value: String,
    highlight: Boolean = false,
    statusColor: Color? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = MatcoTextMuted,
            fontWeight = FontWeight.Medium
        )

        Text(
            text = value,
            fontSize = 12.sp,
            color = statusColor ?: if (highlight) MatcoRed else Color.White,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
fun WarningBanner(
    title: String,
    desc: String,
    color: Color
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f)),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )

            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Black,
                    color = color,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

// Map enum phase to index for progress drawing
private fun getStepIndex(phase: VoltageTestPhase): Int {
    return when(phase) {
        VoltageTestPhase.MeasuringResting -> 1
        VoltageTestPhase.WaitingForCrank -> 2
        VoltageTestPhase.MeasuringCranking -> 3
        VoltageTestPhase.WaitingForEngine -> 4
        VoltageTestPhase.MeasuringCharging -> 5
        VoltageTestPhase.Done -> 6
        VoltageTestPhase.Idle -> 0
    }
}
