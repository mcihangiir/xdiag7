package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.DriveCycleStep
import com.example.viewmodel.DriveCycleType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriveCycleScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onNavigateToMonitors: () -> Unit
) {
    val activeCycle by viewModel.activeDriveCycle.collectAsState()
    val isCycleActive by viewModel.driveCycleActive.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("OBD2 SÜRÜŞ DÖNGÜSÜ (DRIVE CYCLE)", fontWeight = FontWeight.Black, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoBlack,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            if (activeCycle.isEmpty() && !isCycleActive) {
                // Tip Seçici Ekranı
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            "DRIVE CYCLE TİPİNİ SEÇİN",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    item {
                        DriveCycleTypeCard(
                            title = "Genel OBD2 Döngüsü",
                            description = "Tüm temel IM Readiness monitörlerini tamamlamak için standart sürüş testi.",
                            durationStr = "~15 Dakika",
                            onClick = { viewModel.startDriveCycle(DriveCycleType.GENERIC_OBD2) }
                        )
                    }
                    item {
                        DriveCycleTypeCard(
                            title = "Katalitik Konvertör Testi",
                            description = "Sadece katalitik konvertör verimliliğini doğrulamak için özel sürüş.",
                            durationStr = "~5 Dakika",
                            onClick = { viewModel.startDriveCycle(DriveCycleType.CATALYST_TEST) }
                        )
                    }
                    item {
                        DriveCycleTypeCard(
                            title = "EVAP Buharlaşma Testi",
                            description = "Yakıt buharlaşma emisyon sistemini test etmek için soğuk başlama döngüsü.",
                            durationStr = "~10 Dakika",
                            onClick = { viewModel.startDriveCycle(DriveCycleType.EVAP_TEST) }
                        )
                    }
                    item {
                        DriveCycleTypeCard(
                            title = "O2 Sensörü Testi",
                            description = "Oksijen sensörü tepki ve kalibrasyon döngüsü.",
                            durationStr = "~8 Dakika",
                            onClick = { viewModel.startDriveCycle(DriveCycleType.O2_SENSOR_TEST) }
                        )
                    }
                }
            } else {
                // Aktif Döngü veya Tamamlanma Ekranı
                val allCompleted = activeCycle.all { it.isCompleted }

                if (allCompleted && activeCycle.isNotEmpty()) {
                    // Tamamlandı
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = "Bitti",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(100.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            "Sürüş Döngüsü Tamamlandı!",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "IM Readiness ekranını kontrol edin. Bazı araçlar döngünün birden fazla yapılmasını gerektirebilir.",
                            color = MatcoTextMuted,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                        Button(
                            onClick = {
                                viewModel.stopDriveCycle()
                                onNavigateToMonitors()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoAccent),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("MONİTÖRLERİ KONTROL ET", fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Aktif Döngü
                    ActiveDriveCycleView(viewModel)
                }
            }
        }
    }
}

@Composable
fun DriveCycleTypeCard(title: String, description: String, durationStr: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFF2E2E38), CircleShape)
                    .clip(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = MatcoRed)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(description, color = MatcoTextMuted, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tahmini Süre: $durationStr", color = MatcoAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ActiveDriveCycleView(viewModel: DiagnosticViewModel) {
    val activeCycle by viewModel.activeDriveCycle.collectAsState()
    val currentIndex by viewModel.currentStepIndex.collectAsState()
    val elapsedSeconds by viewModel.stepElapsedSeconds.collectAsState()
    
    val liveSpeedStr by viewModel.liveSpeed.collectAsState()
    val liveTemp by viewModel.liveCoolantTemp.collectAsState()

    val currentSpeed = liveSpeedStr.toFloat()
    
    val totalSteps = activeCycle.size
    val activeStep = activeCycle.getOrNull(currentIndex)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // İlerleme Çubuğu
        Text(
            "Adım ${currentIndex + 1} / $totalSteps",
            color = MatcoTextMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { if (totalSteps > 0) (currentIndex.toFloat() / totalSteps) else 0f },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp),
            color = MatcoAccent,
            trackColor = MatcoCardBorder
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (activeStep != null) {
            // Uyarı Pankartı (Hız dışındaysa)
            val speedMet = currentSpeed >= activeStep.targetCondition.minSpeedKmh && currentSpeed <= activeStep.targetCondition.maxSpeedKmh
            if (!speedMet) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoRed.copy(alpha = 0.2f)),
                    border = BorderStroke(1.dp, MatcoRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "🏎 Hedef hız: ${activeStep.targetCondition.minSpeedKmh.toInt()}-${activeStep.targetCondition.maxSpeedKmh.toInt()} km/h — Mevcut: ${currentSpeed.toInt()}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // AKTİF ADIM KARTI
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        activeStep.title,
                        color = MatcoAccent,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        activeStep.description,
                        color = Color.White,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    // Koşul göstergeleri
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ConditionItem(
                            label = "HIZ",
                            value = "${currentSpeed.toInt()} km/h",
                            isMet = speedMet
                        )
                        ConditionItem(
                            label = "SICAKLIK",
                            value = "${liveTemp}°C",
                            isMet = liveTemp >= activeStep.targetCondition.minTemp
                        )
                        ConditionItem(
                            label = "GAZ",
                            value = "%0", // Simulated gauge
                            isMet = true
                        )
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    // Dönüş Çemberi (Progress)
                    val progressRatio = if (activeStep.durationSeconds > 0) {
                        (elapsedSeconds.toFloat() / activeStep.durationSeconds).coerceIn(0f, 1f)
                    } else 0f
                    val remainingSeconds = activeStep.durationSeconds - elapsedSeconds
                    
                    val conditionsMet = speedMet && liveTemp >= activeStep.targetCondition.minTemp

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(140.dp)
                    ) {
                        val strokeColor = if (conditionsMet) Color(0xFF10B981) else Color(0xFFEF4444)
                        
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawArc(
                                color = MatcoCardBorder,
                                startAngle = -90f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = strokeColor,
                                startAngle = -90f,
                                sweepAngle = 360f * progressRatio,
                                useCenter = false,
                                style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            if (conditionsMet) {
                                Text(
                                    "${remainingSeconds.coerceAtLeast(0)}s",
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black
                                )
                                Text("KALDI", color = MatcoTextMuted, fontSize = 12.sp)
                            } else {
                                Text(
                                    "⏸",
                                    color = Color.White,
                                    fontSize = 24.sp
                                )
                                Text("KOŞUL BEKLENIYOR", color = MatcoTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "TÜM ADIMLAR (${activeCycle.size})",
            color = MatcoTextMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Adım Listesi
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(activeCycle) { index, step ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    if (step.isCompleted) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(step.title, color = MatcoTextMuted, fontSize = 13.sp)
                    } else if (step.isActive) {
                        // Kırmızı animasyonlu nokta
                        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                        val scale by infiniteTransition.animateFloat(
                            initialValue = 0.5f,
                            targetValue = 1f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1000),
                                repeatMode = RepeatMode.Reverse
                            ), label = "scale"
                        )
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(MatcoRed.copy(alpha = 0.3f * scale)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(modifier = Modifier.size(8.dp).background(MatcoRed, CircleShape))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(step.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Box(modifier = Modifier.size(16.dp), contentAlignment = Alignment.Center) {
                            Box(modifier = Modifier.size(8.dp).background(MatcoCardBorder, CircleShape))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(step.title, color = MatcoTextMuted.copy(alpha=0.5f), fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ConditionItem(label: String, value: String, isMet: Boolean) {
    val color = if (isMet) Color(0xFF10B981) else Color(0xFFEF4444)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = MatcoTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Black)
    }
}
