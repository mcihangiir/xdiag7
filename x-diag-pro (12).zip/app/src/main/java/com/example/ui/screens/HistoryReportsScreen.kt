package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DiagnosticReport
import com.example.ui.components.SignatureDialog
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.ExportState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryReportsScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onViewStatistics: () -> Unit,
    onNavigateToServiceHistory: (String) -> Unit,
    onNavigateToTechDashboard: () -> Unit
) {
    val reports by viewModel.diagnosticReports.collectAsState()
    val exportState by viewModel.pdfExportState.collectAsState()
    
    var selectedReport by remember { mutableStateOf<DiagnosticReport?>(null) }
    var showSignature by remember { mutableStateOf(false) }
    var isZipping by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("Tüm Raporlar") }
    
    val filteredReports = remember(reports, selectedFilter) {
        when (selectedFilter) {
            "Hızlı Tarama" -> reports.filter { it.scanType == "QUICK" }
            "Sistem Taraması" -> reports.filter { it.scanType == "SYSTEM_SCAN" }
            else -> reports
        }
    }
    
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(exportState) {
        when (val state = exportState) {
            is ExportState.Success -> {
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(state.uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                }
                try {
                    context.startActivity(viewIntent)
                } catch (e: Exception) {
                    // Fallback to chooser share/save if no PDF viewer app is found
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, state.uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Raporu Paylaş / Kaydet"))
                }
                viewModel.resetPdfExportState()
            }
            is ExportState.Error -> {
                snackbarHostState.showSnackbar("Hata: ${state.message}")
                viewModel.resetPdfExportState()
            }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("TEŞHİS RAPORLARI", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    if (reports.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                isZipping = true
                                scope.launch(Dispatchers.IO) {
                                    try {
                                        val pdfGenerator = com.example.data.PdfReportGenerator(context)
                                        val tempDir = File(context.cacheDir, "reports")
                                        if (!tempDir.exists()) tempDir.mkdirs()

                                        val zipFile = File(tempDir, "XDiag_Tum_Raporlar_${System.currentTimeMillis()}.zip")
                                        val zipOutputStream = ZipOutputStream(FileOutputStream(zipFile))

                                        reports.forEach { r ->
                                            pdfGenerator.generateReport(r)
                                            // Locate the file in our reports temp folder
                                            val reportFile = File(tempDir, "XDiag_Report_${r.timestamp}.pdf")
                                            if (reportFile.exists()) {
                                                val cleanName = r.vehicleName.replace(" ", "_")
                                                val zipEntry = ZipEntry("XDiag_Rapor_${r.id}_${cleanName}.pdf")
                                                zipOutputStream.putNextEntry(zipEntry)
                                                reportFile.inputStream().use { input ->
                                                    input.copyTo(zipOutputStream)
                                                }
                                                zipOutputStream.closeEntry()
                                            }
                                        }
                                        zipOutputStream.close()

                                        val zipUri = FileProvider.getUriForFile(context, "com.example.fileprovider", zipFile)
                                        withContext(Dispatchers.Main) {
                                            isZipping = false
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/zip"
                                                putExtra(Intent.EXTRA_STREAM, zipUri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "ZIP Arşivini Paylaş"))
                                        }
                                    } catch (e: Exception) {
                                        withContext(Dispatchers.Main) {
                                            isZipping = false
                                            scope.launch {
                                                snackbarHostState.showSnackbar("ZIP hatası: ${e.localizedMessage}")
                                            }
                                        }
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Tümünü ZIP Olarak Paylaş", tint = Color.White)
                        }
                    }
                    IconButton(onClick = onViewStatistics) {
                        Icon(Icons.Default.Analytics, contentDescription = "İstatistikleri Gör", tint = Color.White)
                    }
                    IconButton(onClick = onNavigateToTechDashboard) {
                        Icon(Icons.Default.Dashboard, contentDescription = "Servis Paneli", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        if (reports.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.History, null, tint = MatcoTextMuted, modifier = Modifier.size(90.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Henüz rapor yok", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MatcoTextMuted)
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize().padding(padding)) {
                Column(modifier = Modifier.fillMaxSize()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val filters = listOf("Tüm Raporlar", "Hızlı Tarama", "Sistem Taraması")
                        filters.forEach { filter ->
                            val isSelected = selectedFilter == filter
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = if (isSelected) MatcoRed else MatcoCard,
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .clickable { selectedFilter = filter }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = filter,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else Color.White.copy(0.7f)
                                )
                            }
                        }
                    }

                    if (filteredReports.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text("Bu filtreye uygun rapor bulunamadı.", color = MatcoTextMuted, fontSize = 14.sp)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f).padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filteredReports) { report ->
                                ReportCard(
                                    report = report,
                                    onView = { selectedReport = report },
                                    onExport = {
                                        viewModel.exportReportToPdf(report)
                                    },
                                    onServiceHistory = {
                                        onNavigateToServiceHistory(report.vehicleVin)
                                    }
                                )
                            }
                        }
                    }
                }

                if (exportState is ExportState.Loading || isZipping) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, MatcoCardBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(color = MatcoRed)
                                Text(
                                    if (isZipping) "Tüm Raporlar ZIP Klasörüne Paketleniyor..." else "Ayrıntılı PDF Raporu Oluşturuluyor...",
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Detay + İmza Dialog
    selectedReport?.let { report ->
        AlertDialog(
            onDismissRequest = { selectedReport = null },
            title = { Text("Rapor Detayı") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Araç: ${report.vehicleName}", fontWeight = FontWeight.Bold)
                    Text("VIN: ${report.vehicleVin}")
                    Text("Tarih: ${SimpleDateFormat("dd.MM.yyyy HH:mm").format(Date(report.timestamp))}")
                    Text("Sağlık: %${report.healthPercentage}", color = if (report.healthPercentage > 70) Color(0xFF10B981) else MatcoRed)
                }
            },
            confirmButton = {
                Button(onClick = { showSignature = true }, colors = ButtonDefaults.buttonColors(MatcoRed)) {
                    Text("İMZALA VE PDF PAYLAŞ")
                }
            },
            dismissButton = { TextButton(onClick = { selectedReport = null }) { Text("KAPAT") } }
        )
    }

    if (showSignature) {
        SignatureDialog(
            onDismissRequest = { showSignature = false },
            onSignatureCaptured = { base64 ->
                showSignature = false
                selectedReport?.let {
                    viewModel.saveSignature(it.id, base64)
                    viewModel.exportReportToPdf(it)
                }
                selectedReport = null
            }
        )
    }
}

@Composable
fun ReportCard(report: DiagnosticReport, onView: () -> Unit, onExport: () -> Unit, onServiceHistory: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(report.vehicleName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (report.isSigned) {
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF10B981).copy(0.15f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("İMZALI", fontSize = 9.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                    ) {
                        val scanBadgeText = if (report.scanType == "QUICK") "HIZLI AKILLI TARAMA" else "MANUEL DETAYLI TARAMA" 
                        val badgeBg = if (report.scanType == "QUICK") Color(0xFF6366F1).copy(0.15f) else Color(0xFF10B981).copy(0.15f)
                        val badgeFg = if (report.scanType == "QUICK") Color(0xFF6366F1) else Color(0xFF10B981)
                        
                        Box(
                            modifier = Modifier
                                .background(badgeBg, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(scanBadgeText, fontSize = 9.sp, color = badgeFg, fontWeight = FontWeight.Bold)
                        }

                        if (report.diagSoftVersion.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .background(Color.White.copy(0.08f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("V${report.diagSoftVersion}", fontSize = 9.sp, color = Color.White.copy(0.7f), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    Text(
                        "VIN: ${report.vehicleVin.takeLast(8)}... (Geçmişi Gör)", 
                        fontSize = 12.sp, 
                        color = Color(0xFF6366F1), // Indigo color
                        textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline,
                        modifier = Modifier.clickable { onServiceHistory() }.padding(top = 2.dp, bottom = 4.dp, end = 8.dp)
                    )
                }
                Text("%${report.healthPercentage}", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 18.sp)
            }

            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onExport, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(MatcoRed)) {
                    Icon(Icons.Default.PictureAsPdf, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("PDF PAYLAŞ", fontSize = 12.sp)
                }
                OutlinedButton(onClick = onView, modifier = Modifier.weight(1f)) {
                    Text("DETAY", fontSize = 12.sp)
                }
            }
        }
    }
}