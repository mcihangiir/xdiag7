package com.example.ui.screens

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.ConnectionState
import com.example.data.ConnectionType
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartConnectScreen(
    viewModel: DiagnosticViewModel,
    onNavigateToRecordingGuide: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isConnected by viewModel.isConnected.collectAsState()
    val connectionType by viewModel.connectionType.collectAsState()
    val bleScannedDevices by viewModel.bleScannedDevices.collectAsState()

    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var isBluetoothEnabled by remember { mutableStateOf(true) }

    val bluetoothManager = context.getSystemService(android.bluetooth.BluetoothManager::class.java)
    val bluetoothAdapter = bluetoothManager?.adapter

    val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    fun refreshBluetoothState() {
        isBluetoothEnabled = bluetoothAdapter?.isEnabled ?: false
        if (isBluetoothEnabled) {
            try {
                val hasPermissions = requiredPermissions.all { perm ->
                    ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
                }
                if (hasPermissions) {
                    pairedDevices = viewModel.bluetoothOBDManager.getPairedDevices()
                }
            } catch (e: SecurityException) {
                pairedDevices = emptyList()
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions.values.all { it }) {
            refreshBluetoothState()
            viewModel.scanForBleDevices()
        } else {
            Toast.makeText(context, "Klasik OBD ve DS401 soketlerini listelemek için Bluetooth izinleri gereklidir.", Toast.LENGTH_LONG).show()
        }
    }

    // Auto-scan on load
    LaunchedEffect(Unit) {
        val hasPermissions = requiredPermissions.all { perm ->
            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
        }
        if (hasPermissions) {
            refreshBluetoothState()
            viewModel.scanForBleDevices()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }
    }

    // Keep scanning active while on this screen
    DisposableEffect(Unit) {
        onDispose {
            viewModel.stopBleScanning()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Konnektör / VCI Yönetimi", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { 
                        viewModel.stopBleScanning()
                        onBack() 
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MatcoBlack)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MatcoDark)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Connection Status Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("GÜNCEL BAĞLANTI DURUMU", fontSize = 10.sp, color = MatcoAccent, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                                Spacer(Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .background(if (isConnected) Color(0xFF10B981) else Color(0xFFEF4444), RoundedCornerShape(100.dp))
                                    )
                                    Text(
                                        if (isConnected) {
                                            if (connectionType == ConnectionType.NONE) "Simülasyon Aktif (Sanal)" else "Gerçek Konnektör Bağlı"
                                        } else {
                                            "Bağlantı Yok (Pasif)"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 15.sp
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .background(MatcoRed.copy(0.2f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    connectionType.name,
                                    fontSize = 11.sp,
                                    color = MatcoRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (isConnected) {
                            Spacer(Modifier.height(16.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { 
                                        viewModel.switchConnectionType(ConnectionType.NONE)
                                        Toast.makeText(context, "Bağlantı kesildi.", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.BluetoothDisabled, null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("BAĞLANTIYI KES", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 2. Bluetooth State & Warning Card
            if (!isBluetoothEnabled) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoRed.copy(alpha = 0.15f)),
                        border = BorderStroke(1.dp, MatcoRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Default.Warning, null, tint = MatcoRed, modifier = Modifier.size(28.dp))
                            Column {
                                Text("Bluetooth Kapalı!", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text("Soketleri görebilmek ve bağlantı kurabilmek için telefonun ayarlarından Bluetooth'u açın.", color = MatcoTextMuted, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 3. Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        "BULUNAN VE EŞLEŞMİŞ CİHAZLAR",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MatcoAccent
                    )
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(12.dp), color = MatcoRed, strokeWidth = 1.5.dp)
                        Text("Taranıyor...", fontSize = 10.sp, color = MatcoTextMuted)
                    }
                }
            }

            // Empty state check
            if (pairedDevices.isEmpty() && bleScannedDevices.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, Color.DarkGray.copy(0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Bluetooth, null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                            Text(
                                "Herhangi bir Bluetooth OBDII veya DS401 konnektörü bulunamadı.",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                "Lütfen cihazınızın Bluetooth'unun açık olduğundan, konnektörün araca takılı ve ışığının yandığından emin olun.",
                                color = MatcoTextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { 
                                    refreshBluetoothState()
                                    viewModel.scanForBleDevices()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("LİSTEYİ GÜNCELLE", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // A. Paired Classic Bluetooth Devices
            items(pairedDevices) { device ->
                val name = device.name ?: "Bilinmeyen Adaptör"
                val isDs401 = name.contains("DS401", true) || name.contains("LAUNCH", true) || name.contains("DP", true)
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(
                        1.dp, 
                        if (isConnected && connectionType == ConnectionType.BLUETOOTH) MatcoRed else MatcoCardBorder.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.connectToDevice(device)
                            Toast.makeText(context, "$name Klasik Bluetooth ile bağlanılıyor...", Toast.LENGTH_SHORT).show()
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                if (isDs401) Icons.Default.SettingsInputHdmi else Icons.Default.Bluetooth, 
                                contentDescription = null, 
                                tint = MatcoRed, 
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                    Box(
                                        modifier = Modifier
                                            .background(Color.White.copy(0.12f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text("Klasik BT", fontSize = 8.sp, color = MatcoTextMuted, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text(device.address, fontSize = 11.sp, color = MatcoTextMuted)
                            }
                        }
                        
                        Button(
                            onClick = { 
                                viewModel.connectToDevice(device)
                                Toast.makeText(context, "$name bağlantısı kuruluyor...", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("BAĞLAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // B. Scanned Bluetooth BLE (DS401) Devices
            items(bleScannedDevices) { deviceWrapper ->
                val name = deviceWrapper.name
                val isDs401 = name.contains("DS401", true) || name.contains("LAUNCH", true) || name.contains("DP", true)
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(
                        1.dp, 
                        if (isConnected && connectionType == ConnectionType.BLE) MatcoRed else MatcoCardBorder.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.stopBleScanning()
                            viewModel.connectToBleDeviceSmart(deviceWrapper.device)
                            Toast.makeText(context, "$name BLE üzerinden bağlanılıyor...", Toast.LENGTH_SHORT).show()
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                if (isDs401) Icons.Default.SettingsInputHdmi else Icons.Default.Bluetooth, 
                                contentDescription = null, 
                                tint = MatcoRed, 
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                    Box(
                                        modifier = Modifier
                                            .background(MatcoRed.copy(0.12f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 5.dp, vertical = 2.dp)
                                    ) {
                                        Text("BLE / DS401", fontSize = 8.sp, color = MatcoRed, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text("Sinyal: ${deviceWrapper.rssi} dBm • ${deviceWrapper.address}", fontSize = 11.sp, color = MatcoTextMuted)
                            }
                        }
                        
                        Button(
                            onClick = { 
                                viewModel.stopBleScanning()
                                viewModel.connectToBleDeviceSmart(deviceWrapper.device)
                                Toast.makeText(context, "$name BLE bağlantısı başlatılıyor...", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("BAĞLAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 4. Auxiliary functions (Pinout mode & diagnostic logs)
            item {
                Spacer(Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoCard.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, Color.DarkGray.copy(0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { onNavigateToRecordingGuide() }) {
                            Icon(Icons.Default.Settings, null, modifier = Modifier.size(16.dp), tint = MatcoAccent)
                            Spacer(Modifier.width(6.dp))
                            Text("Özel Pinout / Öğrenme", fontSize = 11.sp, color = MatcoAccent, fontWeight = FontWeight.Bold)
                        }

                        Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color.DarkGray))

                        TextButton(
                            onClick = {
                                val report = viewModel.getVciLogsReport()
                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                val clip = android.content.ClipData.newPlainText("XDiagLogs", report)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Bağlantı raporu kopyalandı! Panele yapıştırabilirsiniz.", Toast.LENGTH_LONG).show()
                            }
                        ) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp), tint = MatcoAccent)
                            Spacer(Modifier.width(6.dp))
                            Text("Cihaz Logunu Kopyala", fontSize = 11.sp, color = MatcoAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
