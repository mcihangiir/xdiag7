package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveChartScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onNavigateToMultiChart: () -> Unit = {},
    onNavigateToGauge: () -> Unit = {}
) {
    val isConnected by viewModel.isConnected.collectAsState()
    val chartData by viewModel.gridChartData.collectAsState()
    val selectedMetric by viewModel.selectedChartMetric.collectAsState()
    var isLiveScrolling by remember { mutableStateOf(true) }
    val activeVehicle by viewModel.activeVehicle.collectAsState()

    val points = chartData[selectedMetric] ?: emptyList()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ZAMAN SERİSİ GRAFİĞİ", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToGauge) {
                        Text("🎛️", fontSize = 20.sp)
                    }
                    TextButton(onClick = onNavigateToMultiChart) {
                        Icon(
                            imageVector = Icons.Default.GridView,
                            contentDescription = "Çoklu Grafik",
                            tint = MatcoRed,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                        Text("⊞ ÇOKLU GRAFİK", color = MatcoRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (!isConnected) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, MatcoCardBorder),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BluetoothDisabled,
                                contentDescription = null,
                                tint = MatcoRed,
                                modifier = Modifier.size(64.dp)
                            )
                            Text(
                                text = "BAĞLANTI KESİK",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MatcoRed
                            )
                            Text(
                                text = "Zaman serisi telemetri grafiği çizebilmek için aktif bir OBD2 / VCI bluetooth cihaz bağlantısına sahip olmanız gerekmektedir. Lütfen ana sayfaya dönüp cihazı bağlayın.",
                                fontSize = 13.sp,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = onBack,
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("ANA SAYFAYA DÖN VE BAĞLAN", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                // Status Info Bar
                Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(
                                    if (isConnected) Color(0xFF10B981) else Color.Red,
                                    RoundedCornerShape(50)
                                )
                        )
                        Text(
                            text = if (isConnected) "Canlı Telemetri Aktif" else "Bağlantı Bekleniyor (Simülasyon Aktif)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(onClick = { isLiveScrolling = !isLiveScrolling }) {
                            Icon(
                                if (isLiveScrolling) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Duraklat",
                                tint = MatcoRed
                            )
                        }
                        IconButton(onClick = { viewModel.clearChartData() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Sıfırla", tint = Color.White)
                        }
                    }
                }
            }

            val allMetrics = listOf("RPM", "Hız", "Soğutma", "O2 Voltaj", "Motor Yükü", "Voltaj")

            // Tab Buttons for selecting the active chart metric
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                allMetrics.forEach { metric ->
                    val isSelected = selectedMetric == metric || 
                        (metric == "Hız" && selectedMetric == "Speed") ||
                        (metric == "Soğutma" && selectedMetric == "Coolant")
                    
                    val metricColor = viewModel.pidColors[metric] ?: MatcoRed

                    Button(
                        onClick = { 
                            val resolvedMetric = when(metric) {
                                "Hız" -> "Hız"
                                "Soğutma" -> "Soğutma"
                                else -> metric
                            }
                            viewModel.setSelectedChartMetric(resolvedMetric) 
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) metricColor else MatcoCard
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .border(
                                1.dp,
                                if (isSelected) Color.Transparent else MatcoCardBorder,
                                RoundedCornerShape(10.dp)
                            )
                    ) {
                        Text(
                            text = when(metric) {
                                "RPM" -> "RPM (Devir)"
                                "Hız" -> "KM/H (Hız)"
                                "Soğutma" -> "°C (Sıcaklık)"
                                else -> metric
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isSelected) Color.White else MatcoTextMuted
                        )
                    }
                }
            }

            // Interactive Time Series Canvas Graph
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clipScrollableGraph()
                    .background(MatcoCard)
                    .border(1.dp, MatcoCardBorder, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                if (points.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("Veri bekleniyor...", color = MatcoTextMuted)
                            CircularProgressIndicator(color = MatcoRed, modifier = Modifier.size(24.dp))
                        }
                    }
                } else {
                    val resolvedMetricKey = when(selectedMetric) {
                        "Speed" -> "Hız"
                        "Coolant" -> "Soğutma"
                        else -> selectedMetric
                    }
                    val range = viewModel.pidRanges[resolvedMetricKey] ?: (0f to 100f)
                    val (minY, maxY) = range
                    val lineColor = viewModel.pidColors[resolvedMetricKey] ?: MatcoRed

                    val titleLabel = when (resolvedMetricKey) {
                        "RPM" -> "Motor Devri"
                        "Hız" -> "Araç Hızı"
                        "Soğutma" -> "Soğutma Sıvısı Sıcaklığı"
                        "O2 Voltaj" -> "O2 Seviyesi"
                        "Motor Yükü" -> "Motor Yükü"
                        "Voltaj" -> "Akü Voltajı"
                        else -> resolvedMetricKey
                    }
                    val unitLabel = when (resolvedMetricKey) {
                        "RPM" -> "RPM"
                        "Hız" -> "km/h"
                        "Soğutma" -> "°C"
                        "O2 Voltaj" -> "V"
                        "Motor Yükü" -> "%"
                        "Voltaj" -> "V"
                        else -> ""
                    }

                    Column(modifier = Modifier.fillMaxSize()) {
                        // Current value display
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                titleLabel,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )

                            val displayValue = if (points.isNotEmpty()) {
                                val lastVal = points.last()
                                if (resolvedMetricKey == "O2 Voltaj" || resolvedMetricKey == "Voltaj") {
                                    String.format("%.2f", lastVal)
                                } else {
                                    String.format("%.0f", lastVal)
                                }
                            } else "0"

                            Text(
                                "$displayValue $unitLabel",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = lineColor
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        val density = LocalDensity.current
                        Canvas(modifier = Modifier.fillMaxSize().weight(1f)) {
                            val w = size.width
                            val h = size.height

                            // Draw grid lines
                            val gridLines = 4
                            for (i in 0..gridLines) {
                                val yGrid = h * i / gridLines
                                drawLine(
                                    color = Color.White.copy(alpha = 0.05f),
                                    start = Offset(0f, yGrid),
                                    end = Offset(w, yGrid),
                                    strokeWidth = 1f
                                )
                            }

                            // Draw time-series graph path
                            val path = Path()
                            val spacing = w / 60f

                            points.forEachIndexed { idx, valRaw ->
                                val x = idx * spacing
                                val normVal = ((valRaw - minY) / (maxY - minY)).coerceIn(0f, 1f)
                                val y = h - (normVal * h)

                                if (idx == 0) {
                                    path.moveTo(x, y)
                                } else {
                                    path.lineTo(x, y)
                                }
                            }

                            drawPath(
                                path = path,
                                color = lineColor,
                                style = Stroke(width = 6f)
                            )
                        }
                    }
                }
            }
            
            if (activeVehicle?.make?.contains("Toyota", ignoreCase = true) == true) {
                val knockRetard by viewModel.liveKnockRetard.collectAsState()
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Vuruntu Geciktirme (Knock Retard)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("0° = Normal, Negatif = Vuruntu var", color = MatcoTextMuted, fontSize = 11.sp)
                        }
                        Text(
                            "${String.format("%.2f", knockRetard)}°",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (knockRetard > -5f) Color(0xFF22C55E) else if (knockRetard > -15f) Color.Yellow else MatcoRed
                        )
                    }
                }
            }
            
        }
        }
    }
}

private fun Modifier.clipScrollableGraph() = this.background(MatcoCard, RoundedCornerShape(12.dp))
