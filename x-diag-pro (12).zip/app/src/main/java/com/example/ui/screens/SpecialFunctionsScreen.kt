package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleSystem
import com.example.ui.theme.*
import com.example.ui.navigation.Screen
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpecialFunctionsScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val activeVehicle by viewModel.activeVehicle.collectAsState()
    var selectedFunction by remember { mutableStateOf<String?>(null) }
    var isExecuting by remember { mutableStateOf(false) }
    var executionProgress by remember { mutableStateOf(0f) }
    var executionLog by remember { mutableStateOf(listOf<String>()) }
    val scope = rememberCoroutineScope()

    val functions = remember(activeVehicle) {
        val baseList = listOf(
            FunctionItem("Yağ Servisi Sıfırlama", "Yağ ömrü ve servis aralığı sıfırlama", Icons.Default.Build, "OIL_RESET"),
            FunctionItem("Direksiyon Açı Kalibrasyonu (SAS)", "SAS kalibrasyonu ve sıfır nokta ayarı", Icons.Default.CompassCalibration, "SAS_CALIBRATION"),
            FunctionItem("Pil Sıfırlama / BMS Kaydı", "BMS adaptasyonu ve yeni pil kayıt işlemi", Icons.Default.BatteryChargingFull, "BMS_RESET"),
            FunctionItem("Gaz Kelebeği Kalibrasyonu", "Elektronik boğaz kelebeği adaptasyon sıfırlama", Icons.Default.Settings, "THROTTLE_ADAPT"),
            FunctionItem("Enjektör Kodlama", "Standard/Denso enjektör kodlama", Icons.Default.Build, "INJECTOR_CODING"),
            FunctionItem("DPF Regenerasyon", "Dizel Partikül Filtresi Yenileme", Icons.Default.Refresh, "DPF_REGEN"),
            FunctionItem("EPB Servis", "Fren Kaliper Açma / Kapatma", Icons.Default.SafetyCheck, "EPB_SERVICE"),
            FunctionItem("TPMS Reset", "Lastik Basınç Sensörü Sıfırlama", Icons.Default.TireRepair, "TPMS_RESET"),
            FunctionItem("Injector Kill Test", "Silindir Kesme Testi", Icons.Default.PowerSettingsNew, "INJECTOR_KILL"),
            FunctionItem("ECU Reset", "Tüm ECU'ları Sıfırla", Icons.Default.RestartAlt, "ECU_RESET")
        )
        if (activeVehicle?.make?.contains("Toyota", ignoreCase = true) == true) {
            listOf(
                FunctionItem("4 Silindir Ateşleme Kaçırma İzleyici", "Anlık/Birikimli silindir ateşleme hataları canlı izleme", Icons.Default.Warning, "MISFIRE_MONITOR"),
                FunctionItem("Enjektör Kodlama (Compensation Code)", "Silindir kafasına göre 30 haneli enjektör kodlarını ECU'ya tanımlama", Icons.Default.VpnKey, "TOYOTA_INJ_CODING"),
                FunctionItem("DPF Rejenerasyonu (DPF Static Regen)", "Dizel Partikül Filtresi manuel yüksek sıcaklık rejenerasyonu", Icons.Default.Refresh, "TOYOTA_DPF_REGEN"),
                FunctionItem("Gaz Kelebeği Öğrenme Sıfırlama (ETCS Reset)", "Temizlik sonrası gaz kelebeği adaptasyon değerleri sıfırlama", Icons.Default.SettingsAccessibility, "TOYOTA_ETCS_RESET"),
                FunctionItem("CVT Yağ Değişim Ömrü Sıfırlama", "CVT sıvı bozulma katsayısının yeni ATF yağına göre sıfırlanması", Icons.Default.Settings, "TOYOTA_CVT_RESET"),
                FunctionItem("Vaka Kalibrasyonu (Solenoid Learn)", "Solenoid debriyaj basma noktalarının öğretilmesi", Icons.Default.PlayArrow, "TOYOTA_SOLENOID_LEARN"),
                FunctionItem("Direksiyon Açı Sensörü Sıfırlama (SAS Reset)", "Direksiyon düz konumdayken açısal sıfır noktası kalibrasyonu", Icons.Default.DirectionsRun, "TOYOTA_SAS_RESET"),
                FunctionItem("Yalpalama ve G-Sensör Kalibrasyonu", "ESP / ABS jiroskop ivme sensörlerinin düz düzlemde sıfırlanması", Icons.Default.Compare, "TOYOTA_YAW_CALIBRATION"),
                FunctionItem("Akıllı Anahtar Tanımlama (IMMO Key Match)", "Transponder akıllı anahtarların immobilizer modülüne tanımlanması", Icons.Default.Lock, "TOYOTA_IMMO_MATCH")
            ) + baseList
        } else {
            baseList
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ÖZEL SERVİS FONKSİYONLARI", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            if (activeVehicle == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Önce bir araç tarayın", fontSize = 18.sp, color = MatcoTextMuted)
                }
                return@Column
            }

            Text(
                text = "${activeVehicle!!.make} ${activeVehicle!!.model} - Özel Fonksiyonlar",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MatcoAccent
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedFunction == null) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(functions) { func ->
                        FunctionCard(func) {
                            if (func.id == "OIL_RESET") {
                                onNavigate(Screen.OilReset.route)
                            } else if (func.id == "MISFIRE_MONITOR") {
                                onNavigate(Screen.MisfireMonitor.route)
                            } else if (func.id == "SAS_CALIBRATION") {
                                onNavigate(Screen.SasCalibration.route)
                            } else if (func.id == "BMS_RESET") {
                                onNavigate(Screen.BmsReset.route)
                            } else {
                                selectedFunction = func.id
                                executionLog = emptyList()
                            }
                        }
                    }
                }
            } else {
                val currentFunc = functions.first { it.id == selectedFunction }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(currentFunc.icon, contentDescription = null, tint = MatcoRed, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(currentFunc.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text(currentFunc.subtitle, fontSize = 13.sp, color = MatcoTextMuted)
                            }
                        }

                        if (isExecuting) {
                            Spacer(modifier = Modifier.height(24.dp))
                            LinearProgressIndicator(
                                progress = { executionProgress },
                                modifier = Modifier.fillMaxWidth(),
                                color = MatcoRed
                            )
                            Text("${(executionProgress * 100).toInt()}% Tamamlanıyor...", modifier = Modifier.padding(top = 8.dp))

                            LazyColumn(modifier = Modifier.height(180.dp).padding(top = 12.dp)) {
                                items(executionLog) { log ->
                                    Text("• $log", fontSize = 12.sp, color = Color(0xFF9CA3AF))
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.height(24.dp))
                            Button(
                                onClick = {
                                    isExecuting = true
                                    executionProgress = 0f
                                    executionLog = listOf("UDS / KWP Otomasyon Motoru Başlatılıyor...")
                                    scope.launch {
                                        viewModel.executeProfessionalSpecialFunction(currentFunc.id).collect { (logOutput, progress) ->
                                            executionLog = executionLog + listOf(logOutput)
                                            executionProgress = progress
                                        }
                                        delay(500)
                                        isExecuting = false
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(54.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                            ) {
                                Text("FONKSİYONU ÇALIŞTIR", fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { selectedFunction = null },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("İptal")
                            }
                        }
                    }
                }
            }
        }
    }
}

data class FunctionItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val id: String
)

@Composable
fun FunctionCard(item: FunctionItem, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(item.icon.tintColor?.copy(alpha = 0.15f) ?: MatcoRed.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(item.icon, contentDescription = null, tint = MatcoRed, modifier = Modifier.size(28.dp))
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(item.subtitle, fontSize = 12.sp, color = MatcoTextMuted)
            }

            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MatcoTextMuted)
        }
    }
}