package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.SpecialFunctionResult

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OilResetScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val oilResult by viewModel.oilResetResult.collectAsState()
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()
    val activeVehicle by viewModel.activeVehicle.collectAsState()

    DisposableEffect(Unit) {
        onDispose {
            viewModel.resetOilResetState()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("YAĞ SERVİSİ SIFIRLAMA", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.Build,
                contentDescription = null,
                tint = MatcoRed,
                modifier = Modifier.size(64.dp)
            )

            Text(
                "YAĞ ÖMRÜ VE BAKIM ARALIĞI SIFIRLAMA",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.White
            )

            Text(
                "Bu işlem, motor yağı değişimi sonrasında gösterge panelindeki servis uyarısını ve ECU bakım aralık sayacını sıfırlamak için kullanılır.",
                color = MatcoTextMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Prerequisite check card
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("GÜVENLİK KOŞULLARI", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MatcoAccent)
                    
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Akü Voltajı (Min 12.1V):", fontSize = 12.sp, color = Color.White)
                        Text(
                            "${String.format("%.2f", batteryVoltage)} V",
                            fontWeight = FontWeight.Bold,
                            color = if (batteryVoltage >= 12.1f) Color(0xFF10B981) else Color.Red,
                            fontSize = 12.sp
                        )
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Seçili Araç Markası:", fontSize = 12.sp, color = Color.White)
                        Text(
                            activeVehicle?.make ?: "Tanımlanmadı",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Status feedback OR action button
            val state = oilResult
            if (state == null) {
                Button(
                    onClick = { viewModel.performOilReset() },
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text("SIFIRLAMA İŞLEMİNİ BAŞLAT", fontWeight = FontWeight.Bold)
                }
            } else {
                when (state) {
                    is SpecialFunctionResult.InProgress -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LinearProgressIndicator(
                                progress = { state.progress },
                                color = MatcoRed,
                                modifier = Modifier.fillMaxWidth().height(8.dp).background(MatcoCard, RoundedCornerShape(8.dp))
                            )
                            Text(
                                state.step,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    is SpecialFunctionResult.Success -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, Color(0xFF10B981)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(40.dp))
                                Text("BAŞARILI", fontWeight = FontWeight.Black, color = Color(0xFF10B981))
                                Text(state.message, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center)
                                Button(
                                    onClick = onBack,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    modifier = Modifier.padding(top = 8.dp)
                                ) {
                                    Text("KAPAT")
                                }
                            }
                        }
                    }
                    is SpecialFunctionResult.Failed -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, Color.Red),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = Color.Red, modifier = Modifier.size(40.dp))
                                Text("BAŞARISIZ", fontWeight = FontWeight.Black, color = Color.Red)
                                Text(state.reason, color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center)
                                Button(
                                    onClick = { viewModel.resetOilResetState() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                    modifier = Modifier.padding(top = 8.dp)
                                ) {
                                    Text("TEKRAR DENE")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
