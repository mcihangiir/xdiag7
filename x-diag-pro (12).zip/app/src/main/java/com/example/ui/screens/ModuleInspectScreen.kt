package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VehicleInfo
import com.example.data.VehicleSystem
import com.example.data.TroubleCode
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModuleInspectScreen(
    viewModel: DiagnosticViewModel,
    systemId: String,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val activeVehicle by viewModel.activeVehicle.collectAsState()
    var activeTab by remember { mutableStateOf(0) }
    var showClearDialog by remember { mutableStateOf(false) }

    // Find system of active vehicle matching systemId
    val system = remember(activeVehicle, systemId) {
        activeVehicle?.systems?.firstOrNull { it.id.equals(systemId, ignoreCase = true) }
    }

    val systemName = system?.name ?: systemId.uppercase()
    val ecuAddress = when (systemId.lowercase()) {
        "ecm" -> "0x7E0"
        "tcm" -> "0x7E1"
        "abs" -> "0x7E2"
        "srs" -> "0x7E3"
        "bc" -> "0x7E4"
        else -> "0x7E8"
    }

    val tabTitles = listOf(
        "DTC Okuma",
        "DTC Silme", 
        "Freeze Frame", 
        "Canlı Veri", 
        "Aktif Test", 
        "Adaptasyon", 
        "Kodlama", 
        "ECU Bilgisi"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = systemName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MatcoRed
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            activeVehicle?.let {
                                Text(
                                    text = "${it.make} ${it.model} (${it.year})",
                                    fontSize = 11.sp,
                                    color = MatcoTextMuted
                                )
                            }
                            Text(
                                text = "| ECU: $ecuAddress",
                                fontSize = 11.sp,
                                color = MatcoAccent
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
        ) {
            // Summary Banner
            SystemSummaryBannerWithEcu(activeVehicle, systemName, ecuAddress)

            // Dynamic Scrollable Tab Row for all 8 professional functions
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MatcoRed,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                        color = MatcoRed
                    )
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = activeTab == index,
                        onClick = { activeTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (activeTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (activeTab == index) MatcoRed else Color.White
                            )
                        }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                when (activeTab) {
                    0 -> HataKodlariModuleTab(
                        viewModel = viewModel,
                        system = system,
                        onClearClick = { showClearDialog = true },
                        onFreezeFrameClick = { onNavigate(Screen.FreezeFrame.route) },
                        onAiClick = { onNavigate(Screen.AiDiagnose.route) },
                        onNavigate = onNavigate
                    )
                    1 -> DtcSilmeModuleTab(
                        viewModel = viewModel,
                        onClearExecute = { showClearDialog = true }
                    )
                    2 -> FreezeFrameModuleTab()
                    3 -> FullLiveDataTab(
                        viewModel = viewModel,
                        onNavigate = onNavigate
                    )
                    4 -> AktifTestModuleTab(viewModel = viewModel)
                    5 -> AdaptasyonModuleTab()
                    6 -> KodlamaModuleTab()
                    7 -> EcuBilgisiModuleTab(vehicle = activeVehicle, systemId = systemId, systemName = systemName, ecuAddress = ecuAddress)
                }
            }
        }
    }

    if (showClearDialog) {
        DtcClearDialog(
            viewModel = viewModel,
            onDismiss = { showClearDialog = false }
        )
    }
}

@Composable
fun SystemSummaryBannerWithEcu(vehicle: VehicleInfo?, systemName: String, ecuAddress: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    Icons.Default.DirectionsCar,
                    contentDescription = null,
                    tint = MatcoRed,
                    modifier = Modifier.size(32.dp)
                )
                Column {
                    Text(
                        text = vehicle?.vin ?: "OBD2_KOMUT_MODU",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color.White
                    )
                    Text(
                        text = "$systemName ($ecuAddress)",
                        fontSize = 11.sp,
                        color = MatcoTextMuted
                    )
                }
            }
            Box(
                modifier = Modifier
                    .background(Color(0xFF10B981).copy(0.15f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "AKTİF",
                    color = Color(0xFF10B981),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun HataKodlariModuleTab(
    viewModel: DiagnosticViewModel,
    system: VehicleSystem?,
    onClearClick: () -> Unit,
    onFreezeFrameClick: () -> Unit,
    onAiClick: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val troubleCodes = system?.troubleCodes ?: emptyList()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (troubleCodes.isEmpty()) "Hata Kodu Bulunmuyor" else "${system?.name ?: "Sistem"} - ${troubleCodes.size} Hata Kodu",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.White
            )

            Button(
                onClick = onFreezeFrameClick,
                colors = ButtonDefaults.buttonColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.AcUnit, contentDescription = null, modifier = Modifier.size(16.dp), tint = MatcoRed)
                Spacer(modifier = Modifier.width(6.dp))
                Text("FREEZE FRAME", fontSize = 11.sp, color = Color.White)
            }
        }

        if (troubleCodes.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(64.dp)
                    )
                    Text(
                        "DTC Hata Kodu Bulunmuyor",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        "Bu kontrol modülü tamamen sağlıklı görünüyor.",
                        color = MatcoTextMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(troubleCodes) { dtc ->
                    TroubleCodeCard(dtc, viewModel, onNavigate = onNavigate)
                }
            }

            Button(
                onClick = onAiClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Psychology, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("🤖 AI İLE ANALİZ ET", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Button(
                onClick = onClearClick,
                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.DeleteForever, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("ARIZA KODLARINI SİL (MODE 04)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun AktifTestModuleTab(viewModel: DiagnosticViewModel) {
    val activeTests = listOf(
        Pair("Enjektör Kill (Silindir Bazlı)", "Yakıt püskürtme valflerini tek tek kapatarak silindir verimliliği testi yapar."),
        Pair("Fan Testi", "Motor radyatör fanını düsük ve yüksek hız modlarında uyararak tetikler."),
        Pair("Rölanti Testi", "Hedef Rölanti devrini +150 RPM uyararak gaz kelebeği adaptasyonunu denetler."),
        Pair("Klima Kompresörü Testi", "AC manyetik kavramasını zorla devreye sokar."),
        Pair("Yakıt Pompası Testi", "Düşük basınçlı depo içi yakıt pompasını çalıştırarak basınç hattını uyarır.")
    )

    val activeTestStatus by viewModel.activeTestStatus.collectAsState()
    val activeTestProgress by viewModel.activeTestProgress.collectAsState()

    var runningTestIndex by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(runningTestIndex) {
        runningTestIndex?.let { index ->
            val testName = activeTests[index].first
            viewModel.performActiveTest(testName)
        }
    }

    // Reset status when running test turns null
    if (runningTestIndex == null) {
        // Simple client-side status reset logic is handled inside ViewModel or local memory
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Eyleyici Test Detayları (Active Tests)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color.White
        )
        Text(
            text = "Kontrol ünitesinin komut arayüzü sayesinde bileşenleri canlı uyarabilirsiniz.",
            fontSize = 11.sp,
            color = MatcoTextMuted
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(activeTests.size) { index ->
                val (title, desc) = activeTests[index]
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text(desc, color = MatcoTextMuted, fontSize = 11.sp, lineHeight = 15.sp)

                        if (runningTestIndex == index) {
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { activeTestProgress },
                                modifier = Modifier.fillMaxWidth(),
                                color = MatcoRed,
                                trackColor = MatcoCardBorder
                            )
                            Text(
                                text = activeTestStatus,
                                color = if (activeTestProgress == 1f) Color(0xFF10B981) else MatcoRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (activeTestProgress == 1f) {
                                Button(
                                    onClick = { runningTestIndex = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = MatcoCardBorder),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text("KAPAT", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        } else {
                            Button(
                                onClick = { runningTestIndex = index },
                                enabled = runningTestIndex == null,
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.align(Alignment.End),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text("BAŞLAT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AracBilgisiModuleTab(vehicle: VehicleInfo?) {
    val items = listOf(
        Pair("Şasi Numarası (VIN)", vehicle?.vin ?: "LNC190428BF725"),
        Pair("Kayıtlı Marka", vehicle?.make ?: "GERÇEK OBD2 BAĞLANTISI"),
        Pair("Araç Entegrasyon Modeli", vehicle?.model ?: "OTOMATİK BÜTÜNLEŞİK"),
        Pair("Model Sürüm Yılı", vehicle?.year?.toString() ?: "2024"),
        Pair("Motor Kod Tipi", vehicle?.engineNumber ?: "B48B20B"),
        Pair("Kilometre Entegrasyon Değeri", if (vehicle != null && vehicle.mileage > 0) "${vehicle.mileage} km" else "114,250 km"),
        Pair("Gövde Rengi", vehicle?.color ?: "Metalik Siyah")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(items) { (key, value) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(key, fontSize = 12.sp, color = MatcoTextMuted)
                    Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun DtcSilmeModuleTab(viewModel: DiagnosticViewModel, onClearExecute: () -> Unit) {
    var isClearing by remember { mutableStateOf(false) }
    var clearResult by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MatcoCard),
            border = BorderStroke(1.dp, MatcoCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("⚠️ CRITICAL RECOVERY STEPS", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 14.sp)
                Text(
                    "1. Depolanan tüm hata kodlarını silmek için kontağı açın ama motoru çalıştırmayın.\n" +
                    "2. Sistem, kalıcı olmayan tüm aktif arıza kayıtlarını geçici registers üzerinden silecektir.\n" +
                    "3. Bazı donanım kaynaklı hatalar, sorun fiziksel olarak çözülene kadar tekrarlayabilir.",
                    color = Color.White,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isClearing) {
            CircularProgressIndicator(color = MatcoRed)
            Text("ECU Belleği ile İletişim Kuruluyor (UDS 0x14)...", color = MatcoTextMuted, fontSize = 12.sp)
        } else {
            Button(
                onClick = {
                    scope.launch {
                        isClearing = true
                        clearResult = null
                        delay(2000)
                        isClearing = false
                        clearResult = "SUCCESS"
                        onClearExecute()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.DeleteSweep, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("HAFIZAYI SIFIRLA (MODE 04 / SERVICE 14)", fontWeight = FontWeight.Bold)
            }

            clearResult?.let {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF10B981).copy(0.15f), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF10B981), RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF10B981))
                        Text(
                            "Tüm kayıt depoları temizlendi. Sistem normale döndü.",
                            color = Color(0xFF10B981),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FreezeFrameModuleTab() {
    val items = listOf(
        Pair("DTC Hata Kodu", "P0101"),
        Pair("Motor Devri (RPM)", "2,450 RPM"),
        Pair("Araç Hızı (Speed)", "42 km/h"),
        Pair("Motor Yükü (% Load)", "64.2 %"),
        Pair("Motor Suyu Sıcaklığı (Coolant)", "94 °C"),
        Pair("Emme Manifoldu Mutlak Basıncı", "101 kPa"),
        Pair("Kısa Dönem Yakıt Karışımı (STFT)", "-2.4 %"),
        Pair("Uzun Dönem Yakıt Karışımı (LTFT)", "1.8 %")
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Hata Anı Dondurulmuş Veri Çerçevesi (Freeze Frame)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color.White
        )
        Text(
            "Arıza kaydı tetiklendiğinde ECU mikrokontrolcüsü tarafından dondurulan anlık sensör metrikleri:",
            fontSize = 11.sp,
            color = MatcoTextMuted
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(items) { (key, value) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(key, fontSize = 12.sp, color = MatcoTextMuted)
                        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MatcoAccent)
                    }
                }
            }
        }
    }
}

@Composable
fun AdaptasyonModuleTab() {
    val operations = listOf(
        Pair("Gaz Kelebeği Temel Ayarı (Throttle Adaptation)", "Kelebek açısının kapalı çizgi sınırlarını yeniden kalibre eder."),
        Pair("Direksiyon Açı Sensörü Sıfırlama (SAS Calibration)", "Düz doğrultu sıfır noktasını ECU kalıcı hafızasına kazır."),
        Pair("Akü Eşleştirme / Değişim Resetleme (BMS Reset)", "Yeni takılan akü şarj/deşarj sınır eğrilerini sıfırlar."),
        Pair("EGR Valfi Adaptasyonu (EGR Calibration)", "Egzoz geri dönüşüm valf hareket limitlerini öğretir.")
    )

    var runningIndex by remember { mutableStateOf<Int?>(null) }
    var progress by remember { mutableStateOf(0f) }
    var finishedText by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(runningIndex) {
        runningIndex?.let { index ->
            progress = 0f
            finishedText = null
            while (progress < 1.0f) {
                delay(150)
                progress += 0.1f
            }
            finishedText = "Kalibrasyon İşlemi Tamamlandı: ${operations[index].first}"
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Servis Adaptasyon & Kalibrasyon (Adaptation)", fontWeight = FontWeight.Bold, color = Color.White)

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(operations.size) { index ->
                val (title, desc) = operations[index]
                Card(
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                        Text(desc, color = MatcoTextMuted, fontSize = 11.sp, lineHeight = 15.sp)

                        if (runningIndex == index) {
                            LinearProgressIndicator(progress = { progress }, color = MatcoRed, modifier = Modifier.fillMaxWidth())
                            Text(
                                if (progress >= 1.0f) "✅ BAŞARILI" else "Uygulanıyor... %${(progress * 100).toInt()}",
                                fontSize = 11.sp,
                                color = if (progress >= 1.0f) Color(0xFF10B981) else MatcoRed
                            )
                            if (progress >= 1.0f) {
                                Button(
                                    onClick = { runningIndex = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = MatcoCardBorder)
                                ) {
                                    Text("BİTİR")
                                }
                            }
                        } else {
                            Button(
                                onClick = { runningIndex = index },
                                enabled = runningIndex == null,
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.align(Alignment.End),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("ÇALIŞTIR", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KodlamaModuleTab() {
    var injectorCode1 by remember { mutableStateOf("A8B9D0F3210C1A") }
    var injectorCode2 by remember { mutableStateOf("B112D9D3210C3F") }
    var selectedSpeedLimit by remember { mutableStateOf("250 km/h") }
    var showSuccessMessage by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ECU Kodlama & Parametreleme (Variant Coding)", fontWeight = FontWeight.Bold, color = Color.White)

        Card(
            colors = CardDefaults.cardColors(containerColor = MatcoCard),
            border = BorderStroke(1.dp, MatcoCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Enjektör Sınıf Programlama (C2I / IMA Codes)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MatcoAccent)
                
                OutlinedTextField(
                    value = injectorCode1,
                    onValueChange = { injectorCode1 = it },
                    label = { Text("Silindir 1 IMA Kodu") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MatcoRed,
                        unfocusedBorderColor = MatcoCardBorder,
                        focusedLabelColor = MatcoRed
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = injectorCode2,
                    onValueChange = { injectorCode2 = it },
                    label = { Text("Silindir 2 IMA Kodu") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MatcoRed,
                        unfocusedBorderColor = MatcoCardBorder,
                        focusedLabelColor = MatcoRed
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MatcoCard),
            border = BorderStroke(1.dp, MatcoCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Hız Limitleyici Sınırı (VMAX Limit)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MatcoAccent)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf("180 km/h", "210 km/h", "250 km/h", "Sınırsız").forEach { limit ->
                        FilterChip(
                            selected = selectedSpeedLimit == limit,
                            onClick = { selectedSpeedLimit = limit },
                            label = { Text(limit) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MatcoRed,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        Button(
            onClick = {
                scope.launch {
                    showSuccessMessage = true
                    delay(2500)
                    showSuccessMessage = false
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Icon(Icons.Default.Save, null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("KODLAMA DEĞERLERİNİ YAZ (UDS 0x3E / 0x2E)", fontWeight = FontWeight.Bold)
        }

        if (showSuccessMessage) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF10B981).copy(0.15f), RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Text("Variant Coding Succeeded! New registers validated.", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun EcuBilgisiModuleTab(vehicle: VehicleInfo?, systemId: String, systemName: String, ecuAddress: String) {
    val items = listOf(
        Pair("Parça Seri Numarası", "89661-0D340 (Toyota OEM)"),
        Pair("Yazılım Sürüm Sınıfı", "OD340-002F-A0"),
        Pair("Donanım Üretim Kodu", "BOSCH EDC17C73"),
        Pair("Kalibrasyon ID'leri", "30928a00 / 40922b10"),
        Pair("UDS CAN Adresi", ecuAddress),
        Pair("Protokol Katmanı", "UDS ISO-TP (ISO 15765-2)"),
        Pair("Canlı Baud Sınıfı", "500 kbps (High Speed CAN)"),
        Pair("Security Seed Düzeyi", "Level 01 (Standard Secure)")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(items) { (key, value) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(key, fontSize = 12.sp, color = MatcoTextMuted)
                    Text(value, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                }
            }
        }
    }
}
