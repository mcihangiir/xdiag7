package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ==================== MATCO PROFESSIONAL RED-BLACK THEME ====================
val MatcoRed = Color(0xFFEF4444)
val MatcoDarkRed = Color(0xFFB91C1C)
val MatcoBlack = Color(0xFF020203)
val MatcoDark = Color(0xFF0A0B0F)
val MatcoCard = Color(0xFF111216)
val MatcoCardBorder = Color(0xFFEF4444).copy(alpha = 0.45f)
val MatcoAccent = Color(0xFFF87171)
val MatcoTextPrimary = Color(0xFFF1F5F9)
val MatcoTextMuted = Color(0xFF94A3B8)
val MatcoGlow = Color(0xFFEF4444).copy(alpha = 0.55f)