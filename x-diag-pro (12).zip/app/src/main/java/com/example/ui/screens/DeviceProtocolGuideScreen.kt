package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.MatcoBlack
import com.example.ui.theme.MatcoRed
import com.example.ui.theme.MatcoAccent
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceProtocolGuideScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sharedPrefs = context.getSharedPreferences("ble_proprietary_config", Context.MODE_PRIVATE)

    var writeHandle by remember { mutableStateOf(sharedPrefs.getString("write_uuid", "") ?: "") }
    var notifyHandle by remember { mutableStateOf(sharedPrefs.getString("notify_uuid", "") ?: "") }
    var firstCommandHex by remember { mutableStateOf(sharedPrefs.getString("first_cmd", "") ?: "") }

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("📋 Klavuz & BLE", "🔐 UDS & Security", "📦 ISO-TP Packetizer", "⚡ KWP & DoIP", "🏎️ CAN FD Monitor")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profesyonel Otomotiv Protokol Laboratuvarı", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MatcoRed
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                        selectedContentColor = MatcoRed,
                        unselectedContentColor = Color.Gray
                    )
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> GuideAndBleConfigTab(
                        context = context,
                        sharedPrefs = sharedPrefs,
                        writeHandle = writeHandle,
                        onWriteHandleChange = { writeHandle = it },
                        notifyHandle = notifyHandle,
                        onNotifyHandleChange = { notifyHandle = it },
                        firstCommandHex = firstCommandHex,
                        onFirstCommandHexChange = { firstCommandHex = it }
                    )
                    1 -> UdsAndSecurityTab(context = context)
                    2 -> IsoTpPacketizerTab()
                    3 -> KwpAndDoipTab()
                    4 -> CanFdMonitorTab()
                }
            }
        }
    }
}

@Composable
fun GuideAndBleConfigTab(
    context: Context,
    sharedPrefs: android.content.SharedPreferences,
    writeHandle: String,
    onWriteHandleChange: (String) -> Unit,
    notifyHandle: String,
    onNotifyHandleChange: (String) -> Unit,
    firstCommandHex: String,
    onFirstCommandHexChange: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Launch XJLDS401 / DB Tersine Mühendislik Kılavuzu", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 15.sp)
        }
        item {
            GuideCard(
                step = "1️⃣",
                title = "Geliştirici Seçeneklerini Aç",
                description = "Ayarlar > Telefon Hakkında > Yapım Numarasına 7 kez dokun."
            )
        }
        item {
            GuideCard(
                step = "2️⃣",
                title = "Bluetooth HCI Snoop Log'u Etkinleştir",
                description = "Ayarlar > Geliştirici Seçenekleri > Bluetooth HCI snoop log > AÇIK konumuna getir."
            )
        }
        item {
            GuideCard(
                step = "3️⃣",
                title = "Orijinal Yazılımla Bağlan",
                description = "Telefonunda orijinal X-DIAG/Diagzone uygulamasını aç, DS401'e bağlan, bir arıza listesi / canlı veri akışını açıp kaydedin."
            )
        }
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("4️⃣ Log Dosyasını Çıkar", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(8.dp))
                    Text("Telefonu kapat/aç (log dosyası tamponu diske boşalır). Sonra bilgisayarı bağlayıp komutu çalıştırın:", fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("adb bugreport rapor.zip", fontWeight = FontWeight.Bold, color = MatcoAccent)
                    Spacer(Modifier.height(4.dp))
                    Text("İçinden FS/data/misc/bluetooth/logs/btsnoop_hci.log dosyasını alın.", fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("ADB Command", "adb bugreport rapor.zip"))
                            Toast.makeText(context, "Kopyalandı", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                    ) {
                        Icon(Icons.Default.ContentCopy, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("ADB KOMUTUNU KOPYALA")
                    }
                }
            }
        }
        item {
            GuideCard(
                step = "5️⃣",
                title = "Wireshark'ta Aç",
                description = "btsnoop_hci.log dosyasını Wireshark programı ile açıp filtre kutusuna yazın: btatt || btspp\nBu, BLE ATT attributes (UUID) ve Bluetooth Classic SPP rfcomm haberleşmelerini ayrıntısıyla listeler."
            )
        }
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(4.dp),
                border = BorderStroke(1.dp, Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("BLE / SPP Özel Karakteristik Kayıtları", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MatcoRed)
                    OutlinedTextField(
                        value = writeHandle,
                        onValueChange = onWriteHandleChange,
                        label = { Text("Tespit Edilen Write Handle UUID") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notifyHandle,
                        onValueChange = onNotifyHandleChange,
                        label = { Text("Tespit Edilen Notify Handle UUID") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = firstCommandHex,
                        onValueChange = onFirstCommandHexChange,
                        label = { Text("İlk Başlatma Komutu (Hex, örn: 7E0521)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            sharedPrefs.edit()
                                .putString("write_uuid", writeHandle.trim())
                                .putString("notify_uuid", notifyHandle.trim())
                                .putString("first_cmd", firstCommandHex.trim())
                                .apply()
                            Toast.makeText(context, "Kilit BLE UUID Parametreleri Kaydedildi!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                    ) {
                        Text("YAZILIM ENJEKTÖRÜNE YAZ")
                    }
                }
            }
        }
    }
}

@Composable
fun UdsAndSecurityTab(context: Context) {
    var commandInput by remember { mutableStateOf("10 03") }
    var seedInput by remember { mutableStateOf("0A 24 5D 9B") }
    var targetSecurityLevel by remember { mutableStateOf(5) }
    var algorithmOutputLog by remember { mutableStateOf(listOf<String>()) }
    var udsTerminalLog by remember { mutableStateOf(listOf<String>("UDS Terminal hazır. Komut gönderin.")) }

    val levels = listOf(1, 3, 5)

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("ISO-14229 UDS Request/Response Simulator", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 15.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("UDS Ad-hoc Komut Gönderimi", fontWeight = FontWeight.Bold)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = commandInput,
                            onValueChange = { commandInput = it },
                            label = { Text("UDS Message Bytes (Hex)") },
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val cleanCmd = commandInput.trim().replace(" ", "")
                                val rawResult = UdsProtocolEngine.handleUdsRequest(cleanCmd)
                                val responseFormatted = if (rawResult.isEmpty()) "NO DATA (Response Suppressed Unit)" else rawResult
                                
                                val timestamp = System.currentTimeMillis() % 100000
                                udsTerminalLog = udsTerminalLog + listOf(
                                    "[$timestamp] TX ⬇️: $commandInput",
                                    "[$timestamp] RX ⬆️: $responseFormatted"
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                        ) {
                            Text("TX/RX")
                        }
                    }

                    // Predefined buttons
                    Text("Hızlı Servis Çağrıları:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = { commandInput = "10 03" },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Text("10 03 (Ext Session)", fontSize = 10.sp, color = Color.Black)
                        }
                        Button(
                            onClick = { commandInput = "27 05" },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Text("27 05 (Request Seed)", fontSize = 10.sp, color = Color.Black)
                        }
                        Button(
                            onClick = { commandInput = "22 F1 90" },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Text("22 F190 (Read VIN)", fontSize = 10.sp, color = Color.Black)
                        }
                    }

                    // Log Panel
                    Text("UDS Otobüs İzleme Konsolu:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        LazyColumn(
                            contentPadding = PaddingValues(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            reverseLayout = true
                        ) {
                            items(udsTerminalLog.reversed()) { logLine ->
                                Text(
                                    text = logLine,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = if (logLine.contains("TX")) Color.Yellow else if (logLine.contains("RX")) Color.Cyan else Color.Green
                                )
                            }
                        }
                    }
                    Button(onClick = { udsTerminalLog = listOf("Terminal temizlendi.") }, colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)) {
                        Text("Terminali Temizle", fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            Text("UDS Security Access 0x27 Seed-Key Algoritması", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 15.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Toyota Özel Key Çözümleyici Geliştirici Aracı", fontWeight = FontWeight.SemiBold)
                    
                    OutlinedTextField(
                        value = seedInput,
                        onValueChange = { seedInput = it },
                        label = { Text("ECU Seed Bytes (Hex, 4 Bytes)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Güvenlik Erişimi Derecesi:", fontSize = 14.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            levels.forEach { lvl ->
                                FilterChip(
                                    selected = targetSecurityLevel == lvl,
                                    onClick = { targetSecurityLevel = lvl },
                                    label = { Text("Level $lvl") }
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            val cleanSeed = seedInput.trim().replace(" ", "").uppercase()
                            if (cleanSeed.length != 8) {
                                algorithmOutputLog = listOf("HATA: Seed tam olarak 4 byte (8 karakter) olmalıdır.")
                                return@Button
                            }

                            val seedBytes = try {
                                cleanSeed.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
                            } catch (e: Exception) {
                                algorithmOutputLog = listOf("HATA: Geçersiz hex karakter.")
                                return@Button
                            }

                            // Calculate Toyota mathematically derived key
                            val expectedKey = ToyotaSecurityAccess.calculateToyotaKey(seedBytes, targetSecurityLevel)
                            val keyStrFormatted = expectedKey.joinToString(" ") { String.format("%02X", it) }
                            
                            val explanation = when (targetSecurityLevel) {
                                1 -> "Level 1 (ECU Teşhis): RorRight(7) + XOR Mask 0x5D8A31F4"
                                3 -> "Level 3 (Immobilizer/Key): RolLeft(11) + XOR Mask 0x2F4D16C9"
                                5 -> "Level 5 (Fren/ABS Reset): RolRight(13) + XOR Mask 0xCE39F71B"
                                else -> "Standart XOR Maskeleme"
                            }

                            algorithmOutputLog = listOf(
                                "--- TOYOTA DIAGNOSTIC LOG ---",
                                "Sistem Seviyesi: $explanation",
                                "Giriş TOYOTA Seed: ${seedBytes.joinToString(" ") { String.format("%02X", it) }}",
                                "Hesaplanan TOYOTA Key: $keyStrFormatted",
                                "Gönderilecek Komut: 27 ${String.format("%02X", targetSecurityLevel + 1)} ${keyStrFormatted.replace(" ", "")}"
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                    ) {
                        Text("TOYOTA ANAHTARI HESAPLA")
                    }

                    if (algorithmOutputLog.isNotEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                algorithmOutputLog.forEach { line ->
                                    Text(line, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IsoTpPacketizerTab() {
    val context = LocalContext.current
    var rawTextPayload by remember { mutableStateOf("PRO_DIAG_TOYOTA_V49.50_AUTOMOTIVE_HANDSHAKE_COMPLETED_SUCCESSFULLY_95318") }
    var targetAddressTx by remember { mutableStateOf("7E0") }
    var useCanFd by remember { mutableStateOf(true) }
    var splitterResults by remember { mutableStateOf(listOf<CanFrame>()) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("ISO-15765-2 ISO-TP Transport Protocol Parçalayıcı", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 15.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Düz Karakter Dizisi Paketleyicisi", fontWeight = FontWeight.Bold)
                    
                    OutlinedTextField(
                        value = rawTextPayload,
                        onValueChange = { rawTextPayload = it },
                        label = { Text("Trafik Buffer Gönderi Karakterleri (Payload)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = targetAddressTx,
                            onValueChange = { targetAddressTx = it },
                            label = { Text("Tx Address (Hex)") },
                            modifier = Modifier.width(100.dp)
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("CAN FD (64-byte Frame)", fontSize = 13.sp)
                            Checkbox(checked = useCanFd, onCheckedChange = { useCanFd = it })
                        }
                    }

                    Button(
                        onClick = {
                            val payloadBytes = rawTextPayload.toByteArray(Charsets.UTF_8)
                            val txInt = targetAddressTx.toIntOrNull(16) ?: 0x7E0
                            splitterResults = IsoTpProcessor.splitPayload(payloadBytes, txInt, useCanFd = useCanFd)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ISO-TP PAKETLERİNE AYIR")
                    }
                }
            }
        }

        if (splitterResults.isNotEmpty()) {
            item {
                Text("Üretilen ISO-TP Paket Katmanları (${splitterResults.size} Adet CAN Çerçevesi):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            items(splitterResults.mapIndexed { idx, item -> idx to item }) { (index, frame) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val frameTypeName = when ((frame.data[0].toInt() shr 4) and 0x0F) {
                                0 -> "SINGLE FRAME (SF)"
                                1 -> "FIRST FRAME (FF)"
                                2 -> "CONSECUTIVE FRAME (CF)"
                                3 -> "FLOW CONTROL (FC)"
                                else -> "BİLİNMEYEN"
                            }
                            Text("Çerçeve #$index - $frameTypeName", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 13.sp)
                            Text("Address: 0x${String.format("%03X", frame.id)}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        
                        val byteRepresentationFormatted = frame.data.joinToString(" ") { String.format("%02X", it) }
                        Text(
                            text = byteRepresentationFormatted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        val reassembled = IsoTpProcessor.reassembleFrames(splitterResults)
                        Toast.makeText(context, "Geri Birleştirilen Metin: " + String(reassembled, Charsets.UTF_8), Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("GERİ BİRLEŞTİR & DOĞRULA (REASSEMBLE)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun KwpAndDoipTab() {
    val scope = rememberCoroutineScope()
    var kwpInitLog by remember { mutableStateOf(listOf<String>("Kwp2000 Başlatıcı Bekliyor...")) }
    var doipSimLog by remember { mutableStateOf(listOf<String>("DoIP Socket server inaktif.")) }
    var isKwpRunning by remember { mutableStateOf(false) }
    var isDoipRunning by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("ISO-14230 KWP2000 Fast Init & 5-Baud Handshake", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 15.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("K-Line Fiziksel Sinyalleşme Test Cihazı", fontWeight = FontWeight.Bold)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (isKwpRunning) return@Button
                                isKwpRunning = true
                                scope.launch {
                                    kwpInitLog = listOf("Fast Init [ISO-14230] Başlatılıyor...")
                                    delay(400)
                                    kwpInitLog = kwpInitLog + listOf("FİZİKSEL SİNYAL: K-Line LOW çekildi (25ms).")
                                    delay(200)
                                    kwpInitLog = kwpInitLog + listOf("FİZİKSEL SİNYAL: K-Line HIGH çekildi (25ms).")
                                    delay(300)
                                    kwpInitLog = kwpInitLog + listOf("TX: 81 11 F1 81 (Start Diagnostic Session)")
                                    delay(250)
                                    kwpInitLog = kwpInitLog + listOf("RX: C1 11 8F (ECU Handshake KB1=EA, KB2=8F başarılı!)")
                                    isKwpRunning = false
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                        ) {
                            Text("FAST INIT", fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                if (isKwpRunning) return@Button
                                isKwpRunning = true
                                scope.launch {
                                    kwpInitLog = listOf("5-Baud Init [ISO-14230] Başlatılıyor...")
                                    delay(400)
                                    kwpInitLog = kwpInitLog + listOf("SİNYAL JENERATÖRÜ: 0x11 adresi 5 Baud hızında basılıyor (1600ms sürecek).")
                                    delay(1600)
                                    kwpInitLog = kwpInitLog + listOf("SİNYAL DETEKTÖRÜ: ECU 0x55 senkronizasyon paternini dönderdi.")
                                    delay(300)
                                    kwpInitLog = kwpInitLog + listOf("RX: ECU Key Bytes ACK'lendi.")
                                    isKwpRunning = false
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                        ) {
                            Text("5-BAUD INIT", fontSize = 11.sp)
                        }
                    }

                    // KWP Logs
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    ) {
                        LazyColumn(
                            contentPadding = PaddingValues(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(kwpInitLog) { line ->
                                Text(
                                    line,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = if (line.contains("FİZİKSEL") || line.contains("SİNYAL")) Color.Magenta else Color.Green
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text("ISO-13400 DoIP (Diagnostics over IP) Simülatör", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 15.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Gateway Ethernet Teşhis Arabirimi", fontWeight = FontWeight.Bold)
                    Text(
                        "DoIP, modern yeni nesil araçlarda araç içi Ethernet (100Base-T1) üzerinden doğrudan DoIP Gateway entegrasyonu sağlayarak saniyede megabaytlarca flash yazılım güncellemelerine kapı açar.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )

                    Button(
                        onClick = {
                            if (isDoipRunning) {
                                isDoipRunning = false
                                doipSimLog = listOf("DoIP Socket sunucuları kapatıldı.")
                                return@Button
                            }
                            isDoipRunning = true
                            scope.launch {
                                var progressText = listOf("Ethernet Linki kuruluyor, DHCP IP aranıyor...")
                                doipSimLog = progressText
                                delay(600)
                                progressText = progressText + listOf("TCP DoIP Port 13400 bind edildi. [IP: 192.168.1.100]")
                                doipSimLog = progressText
                                delay(600)
                                progressText = progressText + listOf("DoIP Vehicle Identification Request alındı.")
                                doipSimLog = progressText
                                delay(500)
                                progressText = progressText + listOf("TX DoIP Message: payloadType=0x0004 (Vehicle Announcement)")
                                progressText = progressText + listOf("VIN: TOYOTA_HILUX_ETH_9832")
                                progressText = progressText + listOf("Logical Address: 0x0E00")
                                doipSimLog = progressText
                                delay(600)
                                progressText = progressText + listOf("Teşhis Oturumu aktif. Saniye başı 10MB veri hızına ulaşıldı.")
                                doipSimLog = progressText
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isDoipRunning) Color.Gray else MatcoRed)
                    ) {
                        Text(if (isDoipRunning) "DoIP BAĞLANTISINI KES" else "DoIP SUNUCUSUNU BAŞLAT", fontSize = 11.sp)
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    ) {
                        LazyColumn(
                            contentPadding = PaddingValues(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(doipSimLog) { line ->
                                Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CanFdMonitorTab() {
    var isMonitoringActive by remember { mutableStateOf(true) }
    var activeEcuSelection by remember { mutableStateOf(0x1000) }
    val simulatedFrames = remember { mutableStateListOf<CanFdAnalyzer.NetworkFrameMetrics>() }

    val scope = rememberCoroutineScope()

    LaunchedEffect(isMonitoringActive, activeEcuSelection) {
        if (!isMonitoringActive) return@LaunchedEffect
        while (true) {
            val element = CanFdAnalyzer.buildRealtimeBusTraffic(activeEcuSelection)
            simulatedFrames.add(0, element)
            if (simulatedFrames.size > 25) {
                simulatedFrames.removeLast()
            }
            delay(800)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("CAN Bus & CAN FD (Flexible Data-rate) İzleme", fontWeight = FontWeight.Bold, color = MatcoRed, fontSize = 15.sp)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Aktif Otobüs Seçimi ve İzleyici", fontWeight = FontWeight.Bold)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Aktif Veri Kaynağı Modülü:", fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = activeEcuSelection == 0x1000,
                                onClick = { activeEcuSelection = 0x1000 },
                                label = { Text("Engine / FD") }
                            )
                            FilterChip(
                                selected = activeEcuSelection == 0x2000,
                                onClick = { activeEcuSelection = 0x2000 },
                                label = { Text("ABS / STD") }
                            )
                            FilterChip(
                                selected = activeEcuSelection == 0x8000,
                                onClick = { activeEcuSelection = 0x8000 },
                                label = { Text("ADAS Range / FD") }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Veri Akışı:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Switch(checked = isMonitoringActive, onCheckedChange = { isMonitoringActive = it })
                    }
                }
            }
        }

        item {
            Text("CAN Osiloskop Paket Trafiği:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        if (simulatedFrames.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("Veri akışı bekleniyor...", color = Color.Gray)
                    }
                }
            }
        } else {
            items(simulatedFrames) { frame ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (frame.isCanFd) MatcoRed.copy(alpha = 0.05f) else Color.DarkGray.copy(alpha = 0.1f)),
                    border = BorderStroke(1.dp, if (frame.isCanFd) MatcoRed else Color.Gray)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (frame.isCanFd) "🔵 CAN FD (64B payload, BRS Active)" else "⚪ Classic CAN (8B payload)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (frame.isCanFd) MatcoRed else Color.Black
                            )
                            Text(
                                "Hız: ${String.format("%.2f", frame.bitRateMbs)} Mbps",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Adres: 0x${String.format("%X", frame.frameId)}  |  Kaynak: ${frame.systemSource}", fontSize = 11.sp, color = Color.Gray)
                        Spacer(Modifier.height(4.dp))
                        
                        // Fake visual hex data dump matching standard telemetry size
                        val randomBytesCount = if (frame.isCanFd) 32 else 8
                        val simulatedRandomBytes = List<Int>(randomBytesCount) { kotlin.random.Random.nextInt(0, 256) }
                        val hexDumpText = simulatedRandomBytes.chunked(8).joinToString("\n") { row ->
                            row.joinToString(" ") { String.format("%02X", it) }
                        }
                        Text(
                            text = hexDumpText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = if (frame.isCanFd) MatcoRed else Color.Black
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GuideCard(step: String, title: String, description: String) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("$step $title", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(description, fontSize = 14.sp)
        }
    }
}
