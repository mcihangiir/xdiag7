package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LivePid
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel

import com.example.ui.navigation.Screen
import androidx.compose.foundation.lazy.grid.GridItemSpan

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocalDiagnoseScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onViewFaults: () -> Unit,
    onNavigate: (String) -> Unit
) {
    var selectedBrand by remember { mutableStateOf<String?>(null) }
    val activeVehicle by viewModel.activeVehicle.collectAsState()
    val isConnected by viewModel.isConnected.collectAsState()
    var activeTab by remember { mutableStateOf(0) }
    var selectedBrandTab by remember { mutableStateOf(0) }

    val brandTabs = listOf("🇪🇺 Avrupa", "🌏 Asya", "🇺🇸 Amerika", "🇨🇳 Çin")
    val brandLists = listOf(
        listOf("Renault", "Volkswagen", "Opel", "Dacia", "Fiat", "Ford (Avrupa)", "Skoda", "SEAT", "Peugeot", "Citroen", "BMW", "Mercedes-Benz", "Audi", "Porsche", "Volvo", "Land Rover", "Jaguar", "Alfa Romeo"),
        listOf("Hyundai", "Toyota", "Nissan", "Honda", "Mazda", "Mitsubishi", "Subaru", "Suzuki", "Lexus", "Infiniti", "Kia", "SsangYong"),
        listOf("Ford", "Chevrolet", "Dodge", "Jeep", "Chrysler", "Cadillac", "Tesla"),
        listOf("Geely", "BYD", "Chery", "MG", "Haval")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("YEREL TEŞHİS", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
        ) {
            if (!isConnected) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, MatcoCardBorder),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.BluetoothDisabled,
                                contentDescription = null,
                                tint = MatcoRed,
                                modifier = Modifier.size(64.dp)
                            )
                            Text(
                                text = "BAĞLANTI KESİK",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MatcoRed
                            )
                            Text(
                                text = "Yerel teşhis işlemleri gerçekleştirmek için aktif bir OBD2 / VCI bluetooth cihaz bağlantısına sahip olmanız gerekmektedir. Lütfen ana sayfaya dönüp cihazı bağlayın.",
                                fontSize = 13.sp,
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = onBack,
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("ANA SAYFAYA DÖN VE BAĞLAN", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else if (activeVehicle == null) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("MARKA SEÇİN", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MatcoAccent, modifier = Modifier.padding(bottom = 8.dp))

                    ScrollableTabRow(
                        selectedTabIndex = selectedBrandTab,
                        edgePadding = 0.dp,
                        containerColor = Color.Transparent,
                        contentColor = MatcoAccent,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedBrandTab]),
                                color = MatcoRed
                            )
                        },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    ) {
                        brandTabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedBrandTab == index,
                                onClick = { selectedBrandTab = index },
                                text = {
                                    Text(
                                        text = title,
                                        fontWeight = if (selectedBrandTab == index) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp,
                                        color = if (selectedBrandTab == index) Color.White else MatcoTextMuted
                                    )
                                }
                            )
                        }
                    }

                    val currentBrands = brandLists[selectedBrandTab]
                    val downloadedBrands by viewModel.downloadedBrandNames.collectAsState()
                    var showDownloadDialogForBrand by remember { mutableStateOf<String?>(null) }

                    if (showDownloadDialogForBrand != null) {
                        val targetBrand = showDownloadDialogForBrand!!
                        AlertDialog(
                            onDismissRequest = { showDownloadDialogForBrand = null },
                            title = { Text("Yazılım Paketi Yüklü Değil", fontWeight = FontWeight.Bold, color = MatcoRed) },
                            text = { Text("$targetBrand teşhis yazılım paketi (veri tabanı) yerel cihazınızda yüklü değil. Bu marka üzerinde aktif teşhis yapabilmek ve ECU sistemlerini sorgulayabilmek için paketi indirmelisiniz.\n\nŞimdi indirmek için Güncelleme Merkezi'ne gitmek ister misiniz?") },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        showDownloadDialogForBrand = null
                                        onNavigate(Screen.SoftwareUpdate.route)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                               ) {
                                    Text("GÜNCELLEME MERKEZİ")
                               }
                            },
                            dismissButton = {
                                TextButton(onClick = { showDownloadDialogForBrand = null }) {
                                    Text("DAHA SONRA", color = Color.White)
                                }
                            },
                            containerColor = MatcoCard
                        )
                    }

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(currentBrands) { brand ->
                            val isDownloaded = remember(brand, downloadedBrands) {
                                val bLower = brand.lowercase()
                                val normalised = when (bLower) {
                                    "volkswagen" -> "vw"
                                    "mercedes-benz" -> "mercedes-benz"
                                    "bmw" -> "bmw"
                                    "audi" -> "audi"
                                    "mini" -> "mini"
                                    "toyota" -> "toyota"
                                    "lexus" -> "lexus"
                                    "skoda" -> "skoda"
                                    "seat" -> "seat"
                                    else -> bLower
                                }
                                val coreBrands = listOf("vw", "audi", "bmw", "mini", "mercedes-benz", "toyota", "lexus", "skoda", "seat")
                                if (normalised in coreBrands) {
                                    normalised in downloadedBrands
                                } else {
                                    // For minor/generic helper brands, allow direct simulation as fallback
                                    true
                                }
                            }

                            BrandCard(brand, isDownloaded) {
                                if (isDownloaded) {
                                    selectedBrand = brand
                                    viewModel.selectLocalBrand(brand)
                                } else {
                                    showDownloadDialogForBrand = brand
                                }
                            }
                        }
                    }
                }
            } else {
                TabRow(selectedTabIndex = activeTab) {
                    Tab(selected = activeTab == 0, onClick = { activeTab = 0 }) { Text("SİSTEMLER") }
                    Tab(selected = activeTab == 1, onClick = { activeTab = 1 }) { Text("CANLI VERİ") }
                }

                when (activeTab) {
                    0 -> SystemsListTab(viewModel, onViewFaults, onNavigate)
                    1 -> FullLiveDataTab(viewModel, onNavigate)
                }
            }
        }
    }
}

@Composable
fun BrandCard(brand: String, isDownloaded: Boolean, onClick: () -> Unit) {
    val abbreviation = remember(brand) {
        when (brand.lowercase()) {
            "volkswagen" -> "VW"
            "mercedes-benz" -> "ME"
            "bmw" -> "BM"
            else -> if (brand.length >= 2) brand.substring(0, 2).uppercase() else brand.uppercase()
        }
    }
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, if (isDownloaded) MatcoCardBorder else Color.Gray.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth().height(100.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
            ) {
                if (isDownloaded) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Yüklü",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(12.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.CloudDownload,
                        contentDescription = "İndir",
                        tint = Color.LightGray.copy(alpha = 0.5f),
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.fillMaxSize().padding(8.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = abbreviation,
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp,
                    color = if (isDownloaded) MatcoRed else Color.Gray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = brand,
                    fontWeight = FontWeight.Normal,
                    fontSize = 12.sp,
                    color = if (isDownloaded) Color.White else Color.Gray,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun SystemsListTab(
    viewModel: DiagnosticViewModel,
    onViewFaults: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val vehicle by viewModel.activeVehicle.collectAsState()
    val totalDtcCount = remember(vehicle) {
        vehicle?.systems?.sumOf { it.troubleCodes.size } ?: 0
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            val scanFailureReason by viewModel.scanFailureReason.collectAsState()
            if (scanFailureReason != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                    border = BorderStroke(1.dp, MatcoRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Error, tint = Color.White, contentDescription = null, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("TARAMA GÜVENİLİR DEĞİL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(scanFailureReason!!, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                            Text("Bu sonuç KAYDEDİLMEDİ.", color = Color.White, fontSize = 11.sp, 
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            } else {
                Card(
                    onClick = onViewFaults,
                    colors = CardDefaults.cardColors(containerColor = if (totalDtcCount > 0) Color.Red.copy(0.15f) else Color(0xFF10B981).copy(0.15f)),
                    border = BorderStroke(1.dp, if (totalDtcCount > 0) Color.Red else Color(0xFF10B981)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(
                                imageVector = if (totalDtcCount > 0) Icons.Default.Error else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (totalDtcCount > 0) Color.Red else Color(0xFF10B981),
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = if (totalDtcCount > 0) "DTC Hata Kodları ($totalDtcCount)" else "Arıza Kodu Bulunmadı",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Hata detaylarını görüntülemek ve silmek için dokunun",
                                    fontSize = 11.sp,
                                    color = MatcoTextMuted
                                )
                            }
                        }
                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }
        
        items(vehicle?.systems ?: emptyList()) { sys ->
            Card(
                onClick = { onNavigate(Screen.ModuleInspect.createRoute(sys.id)) },
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(sys.name, fontWeight = FontWeight.Bold)
                        Text(sys.abbreviation, fontSize = 12.sp, color = MatcoTextMuted)
                    }
                    Text("${sys.errorCount} Hata", color = if (sys.errorCount > 0) Color.Red else Color(0xFF10B981), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun FullLiveDataTab(
    viewModel: DiagnosticViewModel,
    onNavigate: (String) -> Unit
) {
    val pids by viewModel.livePids.collectAsState()
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Quick Action Buttons
        item(span = { GridItemSpan(2) }) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onNavigate(Screen.LiveChart.route) },
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).height(40.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        Icon(Icons.Default.BarChart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ZAMAN GRAFİĞİ", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onNavigate(Screen.PidSelection.route) },
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoCard),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, MatcoCardBorder),
                        modifier = Modifier.weight(1f).height(40.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PID SEÇİMİ", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                Button(
                    onClick = { onNavigate(Screen.FreezeFrame.route) },
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoCard),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MatcoCardBorder),
                    modifier = Modifier.fillMaxWidth().height(40.dp)
                ) {
                    Icon(Icons.Default.AcUnit, contentDescription = null, modifier = Modifier.size(16.dp), tint = MatcoRed)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("FREEZE FRAME VERİLERİ (MODE 02)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                Divider(color = MatcoCardBorder, modifier = Modifier.padding(vertical = 8.dp))
            }
        }

        items(pids) { pid ->
            LivePidCard(pid)
        }
    }
}

@Composable
fun LivePidCard(pid: LivePid) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoDark),
        border = BorderStroke(1.dp, MatcoCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(pid.name, fontSize = 11.sp, color = MatcoTextMuted, textAlign = TextAlign.Center)
            Text(pid.value, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = MatcoRed)
            Text(pid.unit, fontSize = 12.sp, color = Color.Gray)
        }
    }
}