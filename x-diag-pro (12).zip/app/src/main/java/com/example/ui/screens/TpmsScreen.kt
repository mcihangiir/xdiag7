package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TireData
import com.example.data.TirePosition
import com.example.data.TireStatus
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.SpecialFunctionResult

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TpmsScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val tpmsSensorData by viewModel.tpmsSensorData.collectAsState()
    val tpmsResetResult by viewModel.tpmsResetResult.collectAsState()

    val scrollState = rememberScrollState()

    // Query state on entry
    LaunchedEffect(Unit) {
        viewModel.readTpmsSensors()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TPMS Lastik Basıncı", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Info & Special Reset Trigger
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("TPMS Kontrol Paneli", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Text("Gerçek zamanlı 433MHz sensör okumaları", fontSize = 11.sp, color = MatcoTextMuted)
                        }

                        Button(
                            onClick = { viewModel.resetTpms() },
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Loop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("SENSÖR ÖĞREN / SIFIRLA", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Reset action status
                    tpmsResetResult?.let { result ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.surface.copy(0.4f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MatcoCardBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                when (result) {
                                    is SpecialFunctionResult.InProgress -> {
                                        Text(result.step, color = MatcoRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        LinearProgressIndicator(
                                            progress = { result.progress },
                                            modifier = Modifier.fillMaxWidth(),
                                            color = MatcoRed,
                                            trackColor = MatcoCardBorder
                                        )
                                    }
                                    is SpecialFunctionResult.Success -> {
                                        Text(result.message, color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Button(
                                            onClick = { viewModel.resetTpmsState() },
                                            colors = ButtonDefaults.buttonColors(containerColor = MatcoCardBorder),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.align(Alignment.End),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("KAPAT", fontSize = 10.sp)
                                        }
                                    }
                                    is SpecialFunctionResult.Failed -> {
                                        Text(result.reason, color = Color.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Interactive vehicle footprint visualization with corner cards
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp),
                contentAlignment = Alignment.Center
            ) {
                // Background Car schematic Canvas
                VehicleChassisDrawing()

                // Corner tire indicators mapping
                val frontLeft = tpmsSensorData.firstOrNull { it.position == TirePosition.FRONT_LEFT }
                val frontRight = tpmsSensorData.firstOrNull { it.position == TirePosition.FRONT_RIGHT }
                val rearLeft = tpmsSensorData.firstOrNull { it.position == TirePosition.REAR_LEFT }
                val rearRight = tpmsSensorData.firstOrNull { it.position == TirePosition.REAR_RIGHT }

                // FRONT LEFT CARD (Top Left Placement)
                Box(modifier = Modifier.align(Alignment.TopStart)) {
                    TireIndicatorCard(frontLeft ?: TireData(TirePosition.FRONT_LEFT, 220f, 32f, 24, "A4C912", true, TireStatus.NORMAL))
                }

                // FRONT RIGHT CARD (Top Right Placement)
                Box(modifier = Modifier.align(Alignment.TopEnd)) {
                    TireIndicatorCard(frontRight ?: TireData(TirePosition.FRONT_RIGHT, 220f, 32f, 25, "A4C913", true, TireStatus.NORMAL))
                }

                // REAR LEFT CARD (Bottom Left Placement)
                Box(modifier = Modifier.align(Alignment.BottomStart)) {
                    TireIndicatorCard(rearLeft ?: TireData(TirePosition.REAR_LEFT, 190f, 27.5f, 23, "B4D821", true, TireStatus.LOW))
                }

                // REAR RIGHT CARD (Bottom Right Placement)
                Box(modifier = Modifier.align(Alignment.BottomEnd)) {
                    TireIndicatorCard(rearRight ?: TireData(TirePosition.REAR_RIGHT, 225f, 32.6f, 26, "B4D822", true, TireStatus.NORMAL))
                }
            }
        }
    }
}

@Composable
fun VehicleChassisDrawing() {
    Canvas(
        modifier = Modifier
            .width(100.dp)
            .height(200.dp)
    ) {
        val strokeColor = Color.White.copy(alpha = 0.2f)

        // Draw chassis main body
        drawRoundRect(
            color = strokeColor,
            topLeft = Offset(size.width * 0.25f, size.height * 0.15f),
            size = Size(size.width * 0.5f, size.height * 0.7f),
            cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx()),
            style = Stroke(width = 2.dp.toPx())
        )

        // Center spine line
        drawLine(
            color = strokeColor,
            start = Offset(size.width * 0.5f, size.height * 0.15f),
            end = Offset(size.width * 0.5f, size.height * 0.85f),
            strokeWidth = 2.dp.toPx()
        )

        // Front axle line
        drawLine(
            color = strokeColor,
            start = Offset(size.width * 0.15f, size.height * 0.28f),
            end = Offset(size.width * 0.85f, size.height * 0.28f),
            strokeWidth = 3.dp.toPx()
        )

        // Rear axle line
        drawLine(
            color = strokeColor,
            start = Offset(size.width * 0.15f, size.height * 0.72f),
            end = Offset(size.width * 0.85f, size.height * 0.72f),
            strokeWidth = 3.dp.toPx()
        )

        // Simple windshield line
        drawArc(
            color = strokeColor,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(size.width * 0.3f, size.height * 0.35f),
            size = Size(size.width * 0.4f, size.height * 0.15f),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

@Composable
fun TireIndicatorCard(tire: TireData) {
    // Flashing infinite animation if pressure is low
    val isLow = tire.status == TireStatus.LOW || tire.pressurePsi < 30f
    
    val infiniteTransition = rememberInfiniteTransition(label = "flash")
    val colorFactor by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "colorFactor"
    )

    val borderColor = if (isLow) {
        // Blends smoothly from Red to MatcoRed/Darker Card red
        Color.Red.copy(alpha = colorFactor)
    } else {
        MatcoCardBorder
    }

    val glowAlpha = if (isLow) {
        0.25f * (1f - colorFactor)
    } else {
        0f
    }

    Card(
        modifier = Modifier
            .width(135.dp)
            .border(
                BorderStroke(if (isLow) 2.dp else 1.dp, borderColor),
                shape = RoundedCornerShape(12.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (isLow) Color.Red.copy(alpha = glowAlpha) else MatcoCard
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Position Label
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when (tire.position) {
                        TirePosition.FRONT_LEFT -> "Ön Sol"
                        TirePosition.FRONT_RIGHT -> "Ön Sağ"
                        TirePosition.REAR_LEFT -> "Arka Sol"
                        TirePosition.REAR_RIGHT -> "Arka Sağ"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.White
                )

                // Battery Badge
                Box(
                    modifier = Modifier
                        .background(
                            if (tire.batteryOk) Color(0xFF10B981).copy(0.15f) else Color.Red.copy(0.15f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (tire.batteryOk) "B Pil" else "D Pil",
                        color = if (tire.batteryOk) Color(0xFF10B981) else Color.Red,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Divider(color = MatcoCardBorder, thickness = 0.5.dp)

            // Pressure & Status
            Column {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = String.format("%.1f", tire.pressurePsi),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = if (isLow) Color.Red else Color.White
                    )
                    Text(
                        text = "PSI",
                        fontSize = 10.sp,
                        color = MatcoTextMuted,
                        modifier = Modifier.padding(bottom = 3.dp)
                    )
                }
                Text(
                    text = "${tire.pressureKpa.toInt()} kPa",
                    fontSize = 10.sp,
                    color = MatcoTextMuted
                )
            }

            // Temp & Sensor ID
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${tire.tempCelsius}°C",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFF59E0B) // amber for temp
                )

                Text(
                    text = "ID: ${tire.sensorId}",
                    fontSize = 9.sp,
                    color = MatcoTextMuted
                )
            }

            if (isLow) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red, modifier = Modifier.size(11.dp))
                    Text("Düşük Basınç", color = Color.Red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
