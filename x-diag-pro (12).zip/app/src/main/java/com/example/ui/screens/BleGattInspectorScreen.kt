package com.example.ui.screens

import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.Screen
import com.example.viewmodel.DiagnosticViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BleGattInspectorScreen(viewModel: DiagnosticViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val gatt: BluetoothGatt? = viewModel.bleCore.bluetoothGatt


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("BLE GATT Denetleyicisi", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val textToCopy = formatGattForClipboard(gatt)
                        if (textToCopy.isNotBlank()) {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("GATT Info", textToCopy)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Kopyalandı", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Kopyala")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (gatt == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Cihaza bağlı değil. Lütfen önce BLE sekmesinden bağlanın.", color = Color.Gray)
                }
            } else {
                val services = gatt.services
                if (services.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Servis bulunamadı veya henüz keşfedilmedi.", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(services) { service ->
                            var expanded by remember { mutableStateOf(false) }

                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { expanded = !expanded }
                                            .padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text("Service UUID:", fontSize = 12.sp, color = Color.Gray)
                                            Text(
                                                service.uuid.toString(),
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                        Icon(
                                            if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null
                                        )
                                    }

                                    AnimatedVisibility(visible = expanded) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.Black.copy(alpha = 0.05f))
                                                .padding(16.dp),
                                            verticalArrangement = Arrangement.spacedBy(16.dp)
                                        ) {
                                            if (service.characteristics.isEmpty()) {
                                                Text("Karakteristik yok", fontSize = 12.sp, color = Color.Gray)
                                            } else {
                                                service.characteristics.forEach { char ->
                                                    Column {
                                                        Text("Characteristic UUID:", fontSize = 10.sp, color = Color.Gray)
                                                        Text(
                                                            char.uuid.toString(),
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            fontFamily = FontFamily.Monospace,
                                                            color = MaterialTheme.colorScheme.primary
                                                        )
                                                        Row(
                                                            modifier = Modifier.padding(top = 4.dp),
                                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                        ) {
                                                            val props = char.properties
                                                            if ((props and BluetoothGattCharacteristic.PROPERTY_READ) != 0) PropBadge("READ")
                                                            if ((props and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) PropBadge("WRITE")
                                                            if ((props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) PropBadge("WRITE_NO_RESP")
                                                            if ((props and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) PropBadge("NOTIFY")
                                                            if ((props and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) PropBadge("INDICATE")
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PropBadge(label: String) {
    Box(
        modifier = Modifier
            .background(Color(0xFFE2E8F0), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(label, fontSize = 9.sp, color = Color(0xFF475569), fontWeight = FontWeight.Bold)
    }
}

fun formatGattForClipboard(gatt: android.bluetooth.BluetoothGatt?): String {
    if (gatt == null) return ""
    val sb = java.lang.StringBuilder()
    sb.append("Device: ").append(gatt.device.address).append("\n\n")
    gatt.services.forEach { s ->
        sb.append("Service UUID: ").append(s.uuid.toString()).append("\n")
        s.characteristics.forEach { c ->
            sb.append("  Characteristic: ").append(c.uuid.toString()).append("\n")
            val p = c.properties
            val props = mutableListOf<String>()
            if ((p and BluetoothGattCharacteristic.PROPERTY_READ) != 0) props.add("READ")
            if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) props.add("WRITE")
            if ((p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) props.add("WRITE_NO_RESP")
            if ((p and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) props.add("NOTIFY")
            sb.append("  Properties: ").append(props.joinToString(", ")).append("\n\n")
        }
    }
    return sb.toString()
}
