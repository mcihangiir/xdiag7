package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DashboardKpis
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.TechnicianStats

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TechDashboardScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val kpis by viewModel.kpis.collectAsState()
    val loading by viewModel.kpiLoading.collectAsState()
    val kpiPeriod by viewModel.kpiPeriod.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.loadKpis()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SERVİS PANELİ", fontWeight = FontWeight.Black, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MatcoBlack,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Dönem Seçici
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PeriodChip("Bugün", kpiPeriod == "today") { viewModel.setKpiPeriod("today") }
                PeriodChip("Bu Hafta", kpiPeriod == "week") { viewModel.setKpiPeriod("week") }
                PeriodChip("Bu Ay", kpiPeriod == "month") { viewModel.setKpiPeriod("month") }
            }

            if (loading && kpis == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MatcoAccent)
                }
            } else if (kpis != null) {
                val data = kpis!!
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(bottom = 32.dp)
                ) {
                    // KPI KARTLARI
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            KpiCard(
                                title = "Toplam Tarama",
                                value = when(kpiPeriod) { "today" -> data.todayScans; "week" -> data.weekScans; "month" -> data.monthScans; else -> 0 }.toString(),
                                modifier = Modifier.weight(1f)
                            )
                            KpiCard(
                                title = "Kritik Vakalar",
                                value = data.criticalCasesToday.toString(),
                                valueColor = MatcoRed,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            val healthColor = if(data.averageHealthToday > 80f) Color(0xFF10B981) else if(data.averageHealthToday > 50f) Color(0xFFF59E0B) else MatcoRed
                            KpiCard(
                                title = "Ort. Sağlık (Bugün)",
                                value = "%${data.averageHealthToday.toInt()}",
                                valueColor = healthColor,
                                modifier = Modifier.weight(1f)
                            )
                            KpiCard(
                                title = "Sık Görülen DTC",
                                value = data.topDtcThisMonth,
                                valueColor = MatcoRed,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // SAATLİK DAĞILIM (BAR CHART)
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MatcoCard), border = BorderStroke(1.dp, MatcoCardBorder), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("BUGÜNKÜ TARAMA DAĞILIMI", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(16.dp))
                                HourlyBarChart(data.hourlyDistribution)
                            }
                        }
                    }

                    // MARKA DAĞILIMI
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MatcoCard), border = BorderStroke(1.dp, MatcoCardBorder), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("MARKA DAĞILIMI", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(16.dp))
                                BrandDistributionList(data.brandDistribution)
                            }
                        }
                    }

                    // TEKNİSYEN LİDERLİK TABLOSU
                    if (data.technicianStats.isNotEmpty()) {
                        item {
                            Text(
                                "TEKNİSYEN LİDERLİK TABLOSU",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                        items(data.technicianStats.size) { index ->
                            TechnicianItem(index, data.technicianStats[index])
                        }
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Veri bulunamadı.", color = MatcoTextMuted)
                }
            }
        }
    }
}

@Composable
fun PeriodChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            containerColor = Color.Transparent,
            selectedContainerColor = MatcoRed,
            labelColor = MatcoTextMuted,
            selectedLabelColor = Color.White
        ),
        border = FilterChipDefaults.filterChipBorder(
            borderColor = MatcoCardBorder,
            selectedBorderColor = MatcoRed,
            enabled = true,
            selected = selected
        )
    )
}

@Composable
fun KpiCard(title: String, value: String, valueColor: Color = Color.White, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = MatcoTextMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, color = valueColor, fontSize = 24.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun HourlyBarChart(hourlyDistribution: List<Int>) {
    val maxVal = (hourlyDistribution.maxOrNull() ?: 0).coerceAtLeast(1)
    
    Box(modifier = Modifier.fillMaxWidth().height(120.dp)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val barWidth = size.width / 24f
            val spacing = 2.dp.toPx()
            
            for (i in 0 until 24) {
                val value = hourlyDistribution[i]
                val barHeight = (value.toFloat() / maxVal) * size.height
                val x = i * barWidth
                val y = size.height - barHeight
                
                // Highlight peak hours
                val color = if (value > maxVal * 0.7f) MatcoRed else MatcoRed.copy(alpha = 0.5f)
                
                drawRoundRect(
                    color = color,
                    topLeft = Offset(x + spacing/2, y),
                    size = Size(barWidth - spacing, barHeight),
                    cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
fun BrandDistributionList(brandDistribution: Map<String, Int>) {
    val maxVal = (brandDistribution.values.maxOrNull() ?: 0).coerceAtLeast(1)
    val colors = listOf(Color(0xFF3B82F6), Color(0xFF10B981), Color(0xFFF59E0B), Color(0xFF8B5CF6), Color(0xFFEC4899))
    
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        brandDistribution.entries.sortedByDescending { it.value }.take(5).forEachIndexed { index, entry ->
            val color = colors[index % colors.size]
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(entry.key, color = Color.White, fontSize = 13.sp)
                    Text("${entry.value} Tarama", color = MatcoTextMuted, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Canvas(modifier = Modifier.fillMaxWidth().height(8.dp)) {
                    val progressWidth = (entry.value.toFloat() / maxVal) * size.width
                    drawRoundRect(
                        color = MatcoCardBorder,
                        size = Size(size.width, size.height),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                    drawRoundRect(
                        color = color,
                        size = Size(progressWidth, size.height),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                }
            }
        }
    }
}

@Composable
fun TechnicianItem(index: Int, stats: TechnicianStats) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(Color(0xFF2E2E38), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (index == 0) Icon(Icons.Default.Star, null, tint = Color(0xFFF59E0B), modifier = Modifier.size(20.dp))
                else Text("${index+1}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(stats.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("En sık hata: ${stats.mostCommonDtc}", color = MatcoTextMuted, fontSize = 12.sp, overflow = TextOverflow.Ellipsis, maxLines = 1)
            }
            
            Column(horizontalAlignment = Alignment.End) {
                Text("${stats.totalScans} İşlem", color = MatcoAccent, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                val healthColor = if(stats.averageHealthScore > 80f) Color(0xFF10B981) else if(stats.averageHealthScore > 50f) Color(0xFFF59E0B) else MatcoRed
                Text("Ort. Sağlık: %${stats.averageHealthScore.toInt()}", color = healthColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
