package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import com.example.viewmodel.BatteryType
import com.example.viewmodel.SpecialFunctionResult

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BmsResetScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val bmsState by viewModel.bmsResetResult.collectAsState()
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()

    var selectedCapacity by remember { mutableStateOf(70) }
    var selectedType by remember { mutableStateOf(BatteryType.AGM) }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.resetBmsResetState()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AKÜ / BMS KAYDI", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.BatteryChargingFull,
                contentDescription = null,
                tint = MatcoRed,
                modifier = Modifier.size(64.dp)
            )

            Text(
                "YENİ AKÜ VE BMS SİSTEM KAYDI",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color.White
            )

            Text(
                "Araç üzerindeki akü değiştirildiğinde alternatif şarj profilini güncellemek, şarj döngü sayaçlarını sıfırlamak ve akü yıpranma katsayısını kalibre etmek için bu ekranı kullanın.",
                color = MatcoTextMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 16.sp
            )

            if (bmsState == null) {
                // Capacity Selector
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("AKÜ KAPASİTESİ (Ah)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MatcoRed)
                        Text(
                            "$selectedCapacity Ah",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                        Slider(
                            value = selectedCapacity.toFloat(),
                            onValueChange = { selectedCapacity = it.toInt() },
                            valueRange = 40f..120f,
                            steps = 15,
                            colors = SliderDefaults.colors(
                                activeTrackColor = MatcoRed,
                                inactiveTrackColor = MatcoCardBorder,
                                thumbColor = MatcoRed
                            )
                        )
                    }
                }

                // Battery Type Selector
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MatcoCard),
                    border = BorderStroke(1.dp, MatcoCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("AKÜ TEKNOLOJİSİ / TİPİ", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MatcoRed)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                BatteryType.AGM to "AGM Elyaf",
                                BatteryType.EFB to "EFB Start",
                                BatteryType.LEAD_ACID to "Kurşun Asit"
                            ).forEach { (type, label) ->
                                val isSelected = selectedType == type
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (isSelected) MatcoRed else MatcoCardBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { selectedType = type }
                                        .padding(vertical = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        label,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (isSelected) Color.White else MatcoTextMuted
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { viewModel.performBmsReset(selectedCapacity, selectedType) },
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("BMS SİSTEMİNE YENİ AKÜYÜ KAYDET", fontWeight = FontWeight.Bold)
                }
            } else {
                when (val result = bmsState) {
                    is SpecialFunctionResult.InProgress -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LinearProgressIndicator(
                                progress = { result.progress },
                                color = MatcoRed,
                                modifier = Modifier.fillMaxWidth().height(8.dp).background(MatcoCard, RoundedCornerShape(8.dp))
                            )
                            Text(
                                result.step,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    is SpecialFunctionResult.Success -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, Color(0xFF10B981)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(48.dp))
                                Text("AKÜ KAYDI BAŞARILI!", fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                Text(result.message, fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                                Button(
                                    onClick = onBack,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    Text("KAPAT")
                                }
                            }
                        }
                    }
                    is SpecialFunctionResult.Failed -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MatcoCard),
                            border = BorderStroke(1.dp, Color.Red),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = Color.Red, modifier = Modifier.size(48.dp))
                                Text("AKÜ REGİSTRASYONU BAŞARISIZ OLDU", fontWeight = FontWeight.Bold, color = Color.Red)
                                Text(result.reason, fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                                Button(
                                    onClick = { viewModel.resetBmsResetState() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                                ) {
                                    Text("GERİ DÖN")
                                }
                            }
                        }
                    }
                    null -> {}
                }
            }
        }
    }
}
