package com.example.ui.screens

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ListAlt
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DiagnosticViewModel,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val isConnected by viewModel.isConnected.collectAsState()
    val connectorSn by viewModel.connectorSn.collectAsState()
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()
    val btStatus by viewModel.bluetoothOBDManager.connectionStatus.collectAsState()
    val tpmsSensorData by viewModel.tpmsSensorData.collectAsState()
    val hasTpmsWarning = remember(tpmsSensorData, isConnected) {
        isConnected && tpmsSensorData.any { it.status == TireStatus.LOW || it.pressurePsi < 30f }
    }

    var showBluetoothDialog by remember { mutableStateOf(false) }
    var showBleDialog by remember { mutableStateOf(false) }
    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    val bleScannedDevices by viewModel.bleScannedDevices.collectAsState()
    val bleConnectionState by viewModel.bleConnectionState.collectAsState()

    val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN
        )
    } else {
        emptyArray()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            try {
                pairedDevices = viewModel.bluetoothOBDManager.getPairedDevices()
                showBluetoothDialog = true
            } catch (e: SecurityException) {
                Toast.makeText(context, "Bluetooth izni alınamadı: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(context, "Gerçek araca bağlanabilmek için Bluetooth bağlantı izni vermelisiniz.", Toast.LENGTH_LONG).show()
        }
    }

    val blePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.entries.all { it.value }
        if (allGranted) {
            viewModel.scanForBleDevices()
            showBleDialog = true
        } else {
            Toast.makeText(context, "BLE taraması için izin vermelisiniz.", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            Surface(shadowElevation = 12.dp, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .background(brush = Brush.verticalGradient(listOf(Color(0xFF330000), MatcoBlack)))
                        .padding(top = 8.dp, bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            IconButton(onClick = { onNavigate(Screen.UserInfo.route) }) {
                                Icon(Icons.Default.Person, contentDescription = "User Info", tint = Color.White, modifier = Modifier.size(28.dp))
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("X-DIAG V7", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = Color.White, letterSpacing = (-1).sp)
                                    Box(modifier = Modifier.background(MatcoRed.copy(0.9f), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 2.dp)) {
                                        Text("MASTER", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Black)
                                    }
                                }
                                Text("MATCO PROFESSIONAL", fontSize = 9.sp, color = MatcoAccent, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                            }
                        }

                        val connectionType by viewModel.connectionType.collectAsState()
                        val isRealReading = remember(isConnected, connectionType) {
                            isConnected && connectionType != com.example.data.ConnectionType.NONE
                        }

                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = if (batteryVoltage < 11.8f) Color.Red else Color(0xFF4CAF50), modifier = Modifier.size(16.dp))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${String.format("%.1f", batteryVoltage)}V", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (batteryVoltage < 11.8f) Color.Red else Color.White)
                                    Text(
                                        text = if (isRealReading) "OBD2 ATRV (Gerçek)" else "Simüle Değer",
                                        fontSize = 8.sp,
                                        color = if (isRealReading) Color(0xFF4CAF50) else Color.LightGray.copy(alpha = 0.6f),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .background(if (isConnected) Color(0xFF10B981).copy(0.2f) else Color(0xFFEF4444).copy(0.2f), RoundedCornerShape(20.dp))
                                    .border(1.dp, if (isConnected) Color(0xFF10B981) else Color(0xFFEF4444), RoundedCornerShape(20.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(3.dp)).background(if (isConnected) Color(0xFF10B981) else Color(0xFFEF4444)))
                                    Text(if (isConnected) "BAĞLI" else "KESİK", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isConnected) Color(0xFF10B981) else Color(0xFFEF4444))
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("VCI BAĞLANTI DURUMU", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MatcoAccent)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(if (isConnected) "Akıllı Konnektör VCI" else "Bağlantı Bekleniyor", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("SN: $connectorSn", fontSize = 11.sp, color = MatcoTextMuted, fontWeight = FontWeight.Medium)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Button(
                            onClick = {
                                if (isConnected) {
                                    viewModel.switchConnectionType(com.example.data.ConnectionType.NONE)
                                } else {
                                    onNavigate(com.example.ui.navigation.Screen.SmartConnect.route)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isConnected) Color(0xFFEF4444) else MatcoRed),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(if (isConnected) Icons.Default.BluetoothDisabled else Icons.Default.BluetoothConnected, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isConnected) "BAĞLANTIYI KES" else "CİHAZA BAĞLAN", fontSize = 12.sp)
                        }
                    }
                }
            }

            if (hasTpmsWarning) {
                Card(
                    onClick = { onNavigate(Screen.Tpms.route) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.Red.copy(0.15f)),
                    border = BorderStroke(1.dp, Color.Red),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red, modifier = Modifier.size(24.dp))
                        Column {
                            Text("TPMS UYARISI DETAYI (DÜŞÜK BASINÇ)", fontWeight = FontWeight.Bold, color = Color.Red, fontSize = 13.sp)
                            Text("Aracınızın lastiklerinde hava kaybı tespit edildi! Görmek için dokunun.", color = MatcoTextMuted, fontSize = 11.sp)
                        }
                    }
                }
            }

            Text("TEŞHİS İŞLEMLERİ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MatcoTextMuted)

            val menuItems = listOf(
                GridItem("AKILLI TEŞHİS", "Otomatik VIN + ECU Tarama", Icons.Default.DocumentScanner, MatcoRed, Screen.IntelligentScan.route),
                GridItem("YEREL TEŞHİS", "Marka Bazlı Manuel Tarama", Icons.AutoMirrored.Filled.ListAlt, Color(0xFF10B981), Screen.LocalDiagnose.route),
                GridItem("EMİSYON TESTİ", "IM Hazırlık Monitörleri", Icons.Default.CheckCircle, Color(0xFF22C55E), Screen.ImReadiness.route),
                GridItem("MODE 06 TESTİ", "Bileşen İzleme Testleri", Icons.Default.QueryStats, Color(0xFFA855F7), Screen.Mode06.route),
                GridItem("SİFIRLAMA", "Özel Servis Fonksiyonları", Icons.Default.BuildCircle, Color(0xFFF59E0B), Screen.SpecialFunctions.route),
                GridItem("TPMS LASTİK", if (hasTpmsWarning) "Lastik Arızası Var!" else "Hava Basınç Kontrolü", Icons.Default.NetworkCheck, if (hasTpmsWarning) Color.Red else Color(0xFFFF5722), Screen.Tpms.route),
                GridItem("RAPORLAR", "Geçmiş Teşhis Kayıtları", Icons.Default.History, MatcoAccent, Screen.History.route),
                GridItem("GÜNCELLEME", "Veri Tabanı & Yazılım", Icons.Default.CloudDownload, Color(0xFF14B8A6), Screen.SoftwareUpdate.route),
                GridItem("SÜRÜŞ KAYIT", "Canlı Veri Kaydet ve Oynat", Icons.Default.VideoCall, Color(0xFF8B5CF6), Screen.DataRecording.route),
                GridItem("VOLTAJ ANALİZİ", "Akü & Şarj Testi", Icons.Default.BatteryChargingFull, Color(0xFFF59E0B), Screen.VoltageAnalysis.route),
                GridItem("ÇOKLU GRAFİK", "4-6 PID Eş Zamanlı", Icons.Default.GridView, Color(0xFF06B6D4), Screen.MultiChart.route),
                GridItem("GÖSTERGE PANELİ", "Analog Göstergeler", Icons.Default.Speed, Color(0xFFEC4899), Screen.GaugeDashboard.route),
                GridItem("AI ANALİZ", "Gemini Akıllı Arıza Analizi", Icons.Default.Psychology, Color(0xFF6366F1), Screen.AiDiagnose.route),
                GridItem("VIN TARAYICI", "Kamera ile VIN Oku", Icons.Default.CameraAlt, Color(0xFF0EA5E9), Screen.VinScanner.route),
                GridItem("İSTATİSTİKLER", "Arıza Kod Trendleri", Icons.Default.Analytics, Color(0xFF14B8A6), Screen.Statistics.route),
                GridItem("ONARIM KILAVUZU", "Kılavuzlar ve Talimatlar", Icons.Default.MenuBook, Color(0xFFFF5722), Screen.RepairInfo.route),
                GridItem("SERVİS PANELİ", "Teknisyen Paneli", Icons.Default.Dashboard, Color(0xFFF97316), Screen.TechDashboard.route)
            )

            LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
                items(menuItems) { item ->
                    MenuCard(item) { onNavigate(item.route) }
                }
            }
        }
    }
}

data class GridItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color,
    val route: String
)

@Composable
fun MenuCard(item: GridItem, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(item.color.copy(0.15f)), contentAlignment = Alignment.Center) {
                Icon(item.icon, null, tint = item.color, modifier = Modifier.size(28.dp))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Column {
                Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(item.subtitle, fontSize = 11.sp, color = MatcoTextMuted, lineHeight = 14.sp)
            }
        }
    }
}