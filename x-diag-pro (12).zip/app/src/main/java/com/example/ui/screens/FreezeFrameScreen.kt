package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FreezeFrameScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val freezeFrameData by viewModel.freezeFrameData.collectAsState()
    val isLoading by viewModel.freezeFrameLoading.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.readFreezeFrame(0)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dondurulmuş Veri Çerçevesi (Mode 02)", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.readFreezeFrame(0) }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Yenile", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "HATA TETİKLEME SNAPSHOT DETAYLARI",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MatcoAccent
            )

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = MatcoRed)
                        Text("Araçtan veri okunuyor...", color = MatcoTextMuted, fontSize = 13.sp)
                    }
                }
            } else {
                val data = freezeFrameData
                if (data == null) {
                    Box(modifier = Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text("Freeze frame kaydı bulunamadı.", color = MatcoTextMuted)
                            Button(
                                onClick = { viewModel.readFreezeFrame(0) },
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("FREEZE FRAME OKU")
                            }
                        }
                    }
                } else {
                    // Triggering fault code card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MatcoCard),
                        border = BorderStroke(1.dp, MatcoCardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("TETİKLEYİCİ DTC KODU", color = MatcoTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(data.triggerDtc, fontSize = 24.sp, fontWeight = FontWeight.Black, color = MatcoRed)
                            }
                            Box(
                                modifier = Modifier
                                    .background(MatcoRed.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                             ) {
                                Text("Frame #0", color = MatcoRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    // Grid of captured OBD sensor states
                    val items = listOf(
                        GridInfoItem("Motor Devri", "${data.rpm} RPM", Icons.Default.Timer, MatcoRed),
                        GridInfoItem("Araç Hızı", "${data.speed} km/h", Icons.Default.Speed, Color(0xFF3B82F6)),
                        GridInfoItem("Soğutma Sıvısı", "${data.coolantTemp} °C", Icons.Default.Thermostat, Color(0xFFF59E0B)),
                        GridInfoItem("Motor Yükü", "${String.format("%.1f", data.engineLoad)} %", Icons.Default.DirectionsCar, Color(0xFF10B981)),
                        GridInfoItem("Kısa Dönem Yakıt Trim", "${String.format("%.2f", data.fuelTrim)} %", Icons.Default.Refresh, Color(0xFF8B5CF6)),
                        GridInfoItem("Emme Havası Sıcaklığı", "${data.intakeTemp} °C", Icons.Default.AcUnit, Color(0xFF06B6D4)),
                        GridInfoItem("Gaz Kelebeği Açısı", "${String.format("%.1f", data.throttlePos)} %", Icons.Default.Info, Color(0xFFEC4899)),
                        GridInfoItem("Emme Basıncı (MAP)", "${data.mapPressure} kPa", Icons.Default.QueryBuilder, Color(0xFF14B8A6)),
                        GridInfoItem("MAF Hava Akışı", "${String.format("%.2f", data.mafFlow)} g/s", Icons.Default.Refresh, Color(0xFFF97316)),
                        GridInfoItem("Oksijen Sensör Voltajı", "${String.format("%.3f", data.o2Voltage)} V", Icons.Default.Info, Color(0xFFA855F7))
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(items) { item ->
                            FreezeFrameCard(item)
                        }
                    }

                    // Timestamp indicator
                    val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
                    val scanDate = dateFormat.format(Date(data.timestamp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Kayıt Tarihi:\n$scanDate",
                            color = MatcoTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Outlined TEMİZLE button
                            OutlinedButton(
                                onClick = { viewModel.clearFreezeFrame() },
                                border = BorderStroke(1.dp, MatcoRed),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MatcoRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("TEMİZLE", fontSize = 11.sp)
                            }
                            // Filled FREEZE FRAME OKU button
                            Button(
                                onClick = { viewModel.readFreezeFrame(0) },
                                colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("FREEZE FRAME OKU", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

data class GridInfoItem(
    val title: String,
    val value: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val tintColor: Color
)

@Composable
fun FreezeFrameCard(item: GridInfoItem) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(item.icon, contentDescription = null, tint = item.tintColor, modifier = Modifier.size(24.dp))
            Column {
                Text(item.title, fontSize = 11.sp, color = MatcoTextMuted)
                Text(item.value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
