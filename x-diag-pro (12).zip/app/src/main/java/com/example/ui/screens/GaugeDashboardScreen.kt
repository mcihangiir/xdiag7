package com.example.ui.screens

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.viewmodel.DiagnosticViewModel
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GaugeDashboardScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit,
    onNavigateToLiveChart: () -> Unit
) {
    val Rpm by viewModel.liveRpm.collectAsState()
    val Speed by viewModel.liveSpeed.collectAsState()
    val CoolantTemp by viewModel.liveCoolantTemp.collectAsState()
    val BatteryVolt by viewModel.batteryVoltage.collectAsState()
    val O2Volt by viewModel.liveO2Voltage.collectAsState()
    val livePids by viewModel.livePids.collectAsState()

    // Smooth bouncy spring animations for the needles and active arcs
    val animatedRpm by animateFloatAsState(
        targetValue = Rpm.toFloat(),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    val animatedSpeed by animateFloatAsState(
        targetValue = Speed.toFloat(),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    val animatedCoolant by animateFloatAsState(
        targetValue = CoolantTemp.toFloat(),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    val animatedVolt by animateFloatAsState(
        targetValue = BatteryVolt,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )
    val animatedO2 by animateFloatAsState(
        targetValue = O2Volt,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        "PROFESYONEL GÖSTERGE PANELİ", 
                        fontWeight = FontWeight.Bold, 
                        color = MatcoRed,
                        fontSize = 18.sp
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    // Screen selection layout
                    TextButton(onClick = onNavigateToLiveChart) {
                        Text(
                            text = "📊 GRAFİK LİSTESİ", 
                            color = MatcoRed, 
                            fontWeight = FontWeight.Black, 
                            fontSize = 12.sp,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            
            // BÖLÜM 1 — ANA GÖSTERGELER (2 büyük daire yan yana)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // TAKOMETRE (Sol)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(210.dp)
                        .background(MatcoCard, RoundedCornerShape(16.dp))
                        .border(1.dp, MatcoCardBorder, RoundedCornerShape(16.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    TachometerGauge(rpm = animatedRpm, rawRpm = Rpm)
                }

                // HIZ GÖSTERGESİ (Sağ)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(210.dp)
                        .background(MatcoCard, RoundedCornerShape(16.dp))
                        .border(1.dp, MatcoCardBorder, RoundedCornerShape(16.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SpeedometerGauge(speed = animatedSpeed, rawSpeed = Speed)
                }
            }

            // BÖLÜM 2 — KÜÇÜK GÖSTERGELER (3'lü Row)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Temperature Gauge (Soğutma Suyu)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(145.dp)
                        .background(MatcoCard, RoundedCornerShape(12.dp))
                        .border(1.dp, MatcoCardBorder.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SmallSemiCircleGauge(
                        value = animatedCoolant,
                        rawValue = CoolantTemp.toFloat(),
                        minVal = -40f,
                        maxVal = 120f,
                        label = "SOĞUTMA",
                        unit = "°C",
                        colorSelector = { v ->
                            when {
                                v < 50f -> Color(0xFF3B82F6)   // Blue
                                v <= 95f -> Color(0xFF22C55E)  // Green
                                else -> Color(0xFFEF4444)      // Red
                            }
                        }
                    )
                }

                // Voltage Gauge (Voltaj)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(145.dp)
                        .background(MatcoCard, RoundedCornerShape(12.dp))
                        .border(1.dp, MatcoCardBorder.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SmallSemiCircleGauge(
                        value = animatedVolt,
                        rawValue = BatteryVolt,
                        minVal = 10f,
                        maxVal = 16f,
                        label = "VOLTAJ",
                        unit = "V",
                        colorSelector = { v ->
                            when {
                                v < 12.0f -> Color(0xFFEF4444)   // Red
                                v <= 14.8f -> Color(0xFF22C55E)  // Green
                                else -> Color(0xFFEF4444)        // Red
                            }
                        }
                    )
                }

                // O2 Gauge (O2 Sensörü)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(145.dp)
                        .background(MatcoCard, RoundedCornerShape(12.dp))
                        .border(1.dp, MatcoCardBorder.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SmallSemiCircleGauge(
                        value = animatedO2,
                        rawValue = O2Volt,
                        minVal = 0f,
                        maxVal = 1.2f,
                        label = "O2 SENSÖRÜ",
                        unit = "V",
                        colorSelector = { v ->
                            if (v in 0.4f..0.6f) Color(0xFF22C55E) else Color(0xFFEAB308)
                        },
                        isPrecision = true
                    )
                }
            }

            // BÖLÜM 3 — BAR GÖSTERGELERİ
            Card(
                colors = CardDefaults.cardColors(containerColor = MatcoCard),
                border = BorderStroke(1.dp, MatcoCardBorder.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "EK DETAYLI MOTOR PARAMETRELERİ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MatcoTextMuted,
                        letterSpacing = 1.sp
                    )

                    // 1. Motor Yükü
                    val loadVal = livePids.firstOrNull { it.name.contains("Yük") || it.name.contains("Load") }?.value?.toFloatOrNull()
                        ?: (15f + (Rpm / 8000f) * 65f + (cos((animatedRpm / 300f)) * 3f))
                    BarGauge(
                        name = "Motor Yükü",
                        value = loadVal,
                        unit = "%",
                        min = 0f,
                        max = 100f,
                        color = Color(0xFF8B5CF6)
                    )

                    // 2. Gaz Kelebeği Açıklığı
                    val throttleVal = livePids.firstOrNull { it.name.contains("Gaz") || it.name.contains("Kelebek") || it.name.contains("Throttle") }?.value?.toFloatOrNull()
                        ?: (10f + (Rpm / 8000f) * 75f)
                    BarGauge(
                        name = "Gaz Kelebeği Açıklığı",
                        value = throttleVal,
                        unit = "%",
                        min = 0f,
                        max = 100f,
                        color = Color(0xFF10B981)
                    )

                    // 3. Yakıt Trim B1
                    val trimVal = livePids.firstOrNull { it.name.contains("Trim") || it.name.contains("FT") }?.value?.toFloatOrNull()
                        ?: (-1.5f + (sin((animatedRpm / 200f)) * 1.8f))
                    BarGauge(
                        name = "Yakıt Trim Bank 1",
                        value = trimVal,
                        unit = "%",
                        min = -20f,
                        max = 20f,
                        color = Color(0xFFF59E0B)
                    )

                    // 4. MAF Hava Akış Hızı
                    val mafVal = livePids.firstOrNull { it.name.contains("MAF") || it.name.contains("Hava") || it.name.contains("Air Flow") }?.value?.toFloatOrNull()
                        ?: (4.5f + (Rpm / 8000f) * 115f)
                    BarGauge(
                        name = "MAF Hava Akışı",
                        value = mafVal,
                        unit = "g/s",
                        min = 0f,
                        max = 150f,
                        color = Color(0xFF06B6D4)
                    )

                    // 5. Emme Manifoldu Mutlak Basıncı (MAP)
                    val mapVal = livePids.firstOrNull { it.name.contains("Emme") || it.name.contains("Basınç") || it.name.contains("MAP") || it.name.contains("Pressure") }?.value?.toFloatOrNull()
                        ?: (28f + (Rpm / 8000f) * 62f)
                    BarGauge(
                        name = "Emme Basıncı (MAP)",
                        value = mapVal,
                        unit = "kPa",
                        min = 20f,
                        max = 120f,
                        color = Color(0xFFEC4899)
                    )
                }
            }
        }
    }
}

@Composable
fun TachometerGauge(rpm: Float, rawRpm: Int) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2, h / 2)
            val radius = w.coerceAtMost(h) / 2

            // Dış ince sınır halkası
            drawCircle(
                color = MutedRedBorder,
                radius = radius,
                style = Stroke(width = 2.dp.toPx())
            )

            val arcRadius = radius - 12.dp.toPx()
            val arcSize = arcRadius * 2f
            val rect = Size(arcSize, arcSize)
            val topLeftOffset = Offset(center.x - arcRadius, center.y - arcRadius)

            // 1. Arka boş gri yay (135°'den başlayan 270°'lik yay)
            drawArc(
                color = Color.White.copy(alpha = 0.08f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )

            // 2. Renkli yaylar (Güvenlik / Limit bölgelerini boyuyoruz)
            // Yeşil bölge (0-3000 RPM) -> 135° to 236.25°
            drawArc(
                color = Color(0xFF22C55E).copy(alpha = 0.12f),
                startAngle = 135f,
                sweepAngle = 101.25f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )
            // Sarı bölge (3000-6000 RPM) -> 236.25° to 337.5°
            drawArc(
                color = Color(0xFFEAB308).copy(alpha = 0.12f),
                startAngle = 236.25f,
                sweepAngle = 101.25f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )
            // Kırmızı bölge (6000-8000 RPM) -> 337.5° to 405°
            drawArc(
                color = Color(0xFFEF4444).copy(alpha = 0.22f),
                startAngle = 337.5f,
                sweepAngle = 67.5f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )

            // 3. Aktif yay (anlık devir miktarı)
            val activeSweep = (rpm / 8000f) * 270f
            val activeColor = when {
                rpm < 3000f -> Color(0xFF22C55E)
                rpm < 6000f -> Color(0xFFEAB308)
                else -> Color(0xFFEF4444)
            }
            drawArc(
                color = activeColor,
                startAngle = 135f,
                sweepAngle = activeSweep.coerceIn(0f, 270f),
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )

            // 4. Bölme Çizgileri ve Sayısal Etiketler
            drawIntoCanvas { canvas ->
                val paint = Paint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = 8.dp.toPx()
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }

                // Çizgiler için boya
                val tickPaint = Paint().apply {
                    color = android.graphics.Color.GRAY
                    strokeWidth = 1.5.dp.toPx()
                }

                for (i in 0..8) {
                    val angleDeg = 135f + (i / 8f) * 270f
                    val angleRad = Math.toRadians(angleDeg.toDouble())
                    
                    // İşaret çizgisi
                    val startX = center.x + (arcRadius - 4.dp.toPx()) * cos(angleRad).toFloat()
                    val startY = center.y + (arcRadius - 4.dp.toPx()) * sin(angleRad).toFloat()
                    val endX = center.x + (arcRadius + 4.dp.toPx()) * cos(angleRad).toFloat()
                    val endY = center.y + (arcRadius + 4.dp.toPx()) * sin(angleRad).toFloat()
                    
                    canvas.nativeCanvas.drawLine(startX, startY, endX, endY, tickPaint)

                    // Sayılar
                    val labelX = center.x + (arcRadius - 18.dp.toPx()) * cos(angleRad).toFloat()
                    val labelY = center.y + (arcRadius - 18.dp.toPx()) * sin(angleRad).toFloat() + paint.textSize / 3f
                    canvas.nativeCanvas.drawText(i.toString(), labelX, labelY, paint)
                }
            }

            // 5. İbre (Line) draw
            val needleAngleRad = Math.toRadians((135f + (rpm / 8000f) * 270f).toDouble())
            val needleLength = arcRadius * 0.82f
            val needleEnd = Offset(
                center.x + needleLength * cos(needleAngleRad).toFloat(),
                center.y + needleLength * sin(needleAngleRad).toFloat()
            )
            
            // Kırmızı gövde ibre çizgisi
            drawLine(
                color = Color(0xFFEF4444),
                start = center,
                end = needleEnd,
                strokeWidth = 3.dp.toPx()
            )

            // 6. Merkez kapak dairesi
            drawCircle(
                color = Color(0xFF991B1B),
                radius = 8.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 3.dp.toPx(),
                center = center
            )
        }

        // Merkezde sayısal ekran ve alt etiket
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = rawRpm.toString(),
                fontWeight = FontWeight.Black,
                fontSize = 22.sp,
                color = Color.White
            )
            Text(
                text = "x1000 RPM",
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                color = MatcoTextMuted
            )
        }
    }
}

@Composable
fun SpeedometerGauge(speed: Float, rawSpeed: Int) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2, h / 2)
            val radius = w.coerceAtMost(h) / 2

            // Dış ince sınır halkası
            drawCircle(
                color = MutedRedBorder,
                radius = radius,
                style = Stroke(width = 2.dp.toPx())
            )

            val arcRadius = radius - 12.dp.toPx()
            val arcSize = arcRadius * 2f
            val rect = Size(arcSize, arcSize)
            val topLeftOffset = Offset(center.x - arcRadius, center.y - arcRadius)

            // 1. Arka boş yay (135° - 270°)
            drawArc(
                color = Color.White.copy(alpha = 0.08f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )

            // 2. Renkli yaylar (Güvenlik Bölgesi)
            // 0 - 120 km/h (Yeşil) -> sweepAngle = (120/250)*270 = 129.6°
            drawArc(
                color = Color(0xFF22C55E).copy(alpha = 0.12f),
                startAngle = 135f,
                sweepAngle = 129.6f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )
            // 120 - 180 km/h (Sarı) -> sweepAngle = (60/250)*270 = 64.8°
            drawArc(
                color = Color(0xFFEAB308).copy(alpha = 0.12f),
                startAngle = 264.6f,
                sweepAngle = 64.8f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )
            // 180 - 250 km/h (Kırmızı) -> sweepAngle = (70/250)*270 = 75.6°
            drawArc(
                color = Color(0xFFEF4444).copy(alpha = 0.22f),
                startAngle = 329.4f,
                sweepAngle = 75.6f,
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )

            // 3. Aktif yay (anlık veri)
            val activeSweep = (speed / 250f) * 270f
            val activeColor = when {
                speed < 120f -> Color(0xFF22C55E)
                speed < 180f -> Color(0xFFEAB308)
                else -> Color(0xFFEF4444)
            }
            drawArc(
                color = activeColor,
                startAngle = 135f,
                sweepAngle = activeSweep.coerceIn(0f, 270f),
                useCenter = false,
                topLeft = topLeftOffset,
                size = rect,
                style = Stroke(width = 8.dp.toPx())
            )

            // 4. Bölmeler ve Sayılar (0, 50, 100, 150, 200, 250)
            drawIntoCanvas { canvas ->
                val paint = Paint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = 8.dp.toPx()
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }

                val tickPaint = Paint().apply {
                    color = android.graphics.Color.GRAY
                    strokeWidth = 1.5.dp.toPx()
                }

                val speeds = listOf(0, 50, 100, 150, 200, 250)
                speeds.forEachIndexed { index, s ->
                    val angleDeg = 135f + (s / 250f) * 270f
                    val angleRad = Math.toRadians(angleDeg.toDouble())

                    val startX = center.x + (arcRadius - 4.dp.toPx()) * cos(angleRad).toFloat()
                    val startY = center.y + (arcRadius - 4.dp.toPx()) * sin(angleRad).toFloat()
                    val endX = center.x + (arcRadius + 4.dp.toPx()) * cos(angleRad).toFloat()
                    val endY = center.y + (arcRadius + 4.dp.toPx()) * sin(angleRad).toFloat()

                    canvas.nativeCanvas.drawLine(startX, startY, endX, endY, tickPaint)

                    val labelX = center.x + (arcRadius - 18.dp.toPx()) * cos(angleRad).toFloat()
                    val labelY = center.y + (arcRadius - 18.dp.toPx()) * sin(angleRad).toFloat() + paint.textSize / 3f
                    canvas.nativeCanvas.drawText(s.toString(), labelX, labelY, paint)
                }
            }

            // 5. İbre çizimi
            val needleAngleRad = Math.toRadians((135f + (speed / 250f) * 270f).toDouble())
            val needleLength = arcRadius * 0.82f
            val needleEnd = Offset(
                center.x + needleLength * cos(needleAngleRad).toFloat(),
                center.y + needleLength * sin(needleAngleRad).toFloat()
            )

            drawLine(
                color = Color(0xFFEF4444),
                start = center,
                end = needleEnd,
                strokeWidth = 3.dp.toPx()
            )

            // 6. Merkez kapak
            drawCircle(
                color = Color(0xFF991B1B),
                radius = 8.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 3.dp.toPx(),
                center = center
            )
        }

        // Merkez içi veri gösterimi
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = rawSpeed.toString(),
                fontWeight = FontWeight.Black,
                fontSize = 24.sp,
                color = Color.White
            )
            Text(
                text = "km/h",
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                color = MatcoTextMuted
            )
        }
    }
}

@Composable
fun SmallSemiCircleGauge(
    value: Float,
    rawValue: Float,
    minVal: Float,
    maxVal: Float,
    label: String,
    unit: String,
    colorSelector: (Float) -> Color,
    isPrecision: Boolean = false
) {
    val activeColor = colorSelector(rawValue)

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MatcoTextMuted,
            textAlign = TextAlign.Center
        )

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 2.dp)) {
                val w = size.width
                val h = size.height
                // Semicircle centers slightly lower to utilize area
                val center = Offset(w / 2, h - 8.dp.toPx())
                val arcRadius = (w / 2) - 8.dp.toPx()
                val rect = Size(arcRadius * 2, arcRadius * 2)
                val topLeftOffset = Offset(center.x - arcRadius, center.y - arcRadius)

                // 1. Arka boş gri yay (180° sweep starting at 180°)
                drawArc(
                    color = Color.White.copy(alpha = 0.08f),
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = topLeftOffset,
                    size = rect,
                    style = Stroke(width = 5.dp.toPx())
                )

                // 2. Aktif dolgulu yay
                val rangePercent = ((value - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
                val activeSweep = rangePercent * 180f
                drawArc(
                    color = activeColor,
                    startAngle = 180f,
                    sweepAngle = activeSweep,
                    useCenter = false,
                    topLeft = topLeftOffset,
                    size = rect,
                    style = Stroke(width = 5.dp.toPx())
                )

                // 3. Küçük çizgiler
                drawIntoCanvas { canvas ->
                    val paint = Paint().apply {
                        color = android.graphics.Color.GRAY
                        strokeWidth = 1f
                    }
                    val steps = 5
                    for (i in 0..steps) {
                        val angleDeg = 180f + (i / steps.toFloat()) * 180f
                        val angleRad = Math.toRadians(angleDeg.toDouble())

                        val startX = center.x + (arcRadius - 2.dp.toPx()) * cos(angleRad).toFloat()
                        val startY = center.y + (arcRadius - 2.dp.toPx()) * sin(angleRad).toFloat()
                        val endX = center.x + (arcRadius + 4.dp.toPx()) * cos(angleRad).toFloat()
                        val endY = center.y + (arcRadius + 4.dp.toPx()) * sin(angleRad).toFloat()

                        canvas.nativeCanvas.drawLine(startX, startY, endX, endY, paint)
                    }
                }

                // 4. İbre (Needle line)
                val needleAngleRad = Math.toRadians((180f + rangePercent * 180f).toDouble())
                val needleLength = arcRadius * 0.85f
                val needleEnd = Offset(
                    center.x + needleLength * cos(needleAngleRad).toFloat(),
                    center.y + needleLength * sin(needleAngleRad).toFloat()
                )

                drawLine(
                    color = Color(0xFFEF4444),
                    start = center,
                    end = needleEnd,
                    strokeWidth = 2.dp.toPx()
                )

                // 5. Merkez küçük kapak dairesi
                drawCircle(
                    color = Color(0xFF1E293B),
                    radius = 4.dp.toPx(),
                    center = center
                )
            }
        }

        // Değer ve birim metni
        val formattedStr = if (isPrecision) {
            String.format("%.2f", rawValue)
        } else {
            String.format("%.0f", rawValue)
        }

        Row(
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(1.dp),
            modifier = Modifier.padding(bottom = 2.dp)
        ) {
            Text(
                text = formattedStr,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = activeColor
            )
            Text(
                text = " $unit",
                fontSize = 8.sp,
                color = MatcoTextMuted
            )
        }
    }
}

@Composable
fun BarGauge(
    name: String,
    value: Float,
    unit: String,
    min: Float,
    max: Float,
    color: Color
) {
    val progressFraction = ((value - min) / (max - min)).coerceIn(0f, 1f)
    val animatedFraction by animateFloatAsState(
        targetValue = progressFraction,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
    )

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = name,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )

            val displayValStr = when (unit) {
                "%" -> String.format("%.0f", value)
                "g/s" -> String.format("%.1f", value)
                else -> String.format("%.0f", value)
            }

            Text(
                text = "$displayValStr $unit",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }

        // Horizontal visual bar container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(5.dp))
                .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(5.dp))
        ) {
            // Fill
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = animatedFraction)
                    .background(color, RoundedCornerShape(5.dp))
            )
        }
    }
}

// Internal Color definitions to avoid style conflicts
private val MutedRedBorder = Color(0xFFEF4444).copy(alpha = 0.15f)
