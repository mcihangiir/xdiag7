package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Plumbing
import androidx.compose.material.icons.filled.ToggleOff
import androidx.compose.material.icons.filled.ToggleOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import com.example.data.ConnectionType
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: DiagnosticViewModel,
    onNavigateToBleInspector: () -> Unit,
    onNavigateToProtocolGuide: () -> Unit,
    onBack: () -> Unit
) {
    val connectorSn by viewModel.connectorSn.collectAsState()
    val isSyncingVehicles by viewModel.isSyncingVehicles.collectAsState()
    val syncMessage by viewModel.syncMessage.collectAsState()

    var activeMetricMode by remember { mutableStateOf(true) } // Metric vs Imperial
    var diagnosticTestRunning by remember { mutableStateOf(false) }
    var diagnosticTestStep by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Uygulama ve Konnektör Ayarları", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_btn")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Wi-Fi / TCP OBD2 BAĞLANTI AYARLARI
            Text(
                "BAĞLANTI TİPİ VE OBD2 YAPILANDIRMASI",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            val activeConnectionType by viewModel.connectionType.collectAsState()
            val wifiHost by viewModel.wifiHost.collectAsState()
            val wifiPort by viewModel.wifiPort.collectAsState()
            val isConnected by viewModel.isConnected.collectAsState()

            var hostText by remember(wifiHost) { mutableStateOf(wifiHost) }
            var portText by remember(wifiPort) { mutableStateOf(wifiPort.toString()) }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "OBD2 Bağlantı Arayüzü",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.switchConnectionType(ConnectionType.BLUETOOTH) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeConnectionType == ConnectionType.BLUETOOTH) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (activeConnectionType == ConnectionType.BLUETOOTH) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Bluetooth")
                        }

                        Button(
                            onClick = { viewModel.switchConnectionType(ConnectionType.WIFI) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeConnectionType == ConnectionType.WIFI) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (activeConnectionType == ConnectionType.WIFI) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Wi-Fi")
                        }
                    }

                    if (activeConnectionType == ConnectionType.WIFI) {
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        OutlinedTextField(
                            value = hostText,
                            onValueChange = { hostText = it },
                            label = { Text("IP Adresi (WiFi OBD)") },
                            placeholder = { Text("Örn: 192.168.0.10") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Next),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = portText,
                            onValueChange = { portText = it },
                            label = { Text("Port Numarası") },
                            placeholder = { Text("Örn: 35000") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Button(
                            onClick = {
                                val portVal = portText.toIntOrNull() ?: 35000
                                viewModel.connectViaWifi(hostText, portVal)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isConnected) Color(0xFF10B981) else MaterialTheme.colorScheme.primary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isConnected) "WIFI İLE BAĞLI" else "WIFI BAĞLANTISINI ÇALIŞTIR")
                        }
                    }

                    // Status display
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Aktif Bağlantı Sürücüsü:", fontSize = 11.sp, color = Color.Gray)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (isConnected) Color(0xFF10B981) else Color.Red, RoundedCornerShape(4.dp))
                            )
                            Text(
                                text = if (isConnected) {
                                    if (activeConnectionType == ConnectionType.WIFI) "Wi-Fi Aktif" else "Bluetooth Aktif"
                                } else "Bağlantı Yok",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isConnected) Color(0xFF10B981) else Color.Red
                            )
                        }
                    }
                }
            }

            // General Category: Hardware self diagnosis
            Text(
                "DONANIM BÜTÜNLÜĞÜ SETİ",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "OBD2 Konnektör Tanılama Aracı",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Smart Konnektör Seri No: $connectorSn üzerinde doğrudan CAN verici-alıcı sinyal doğrulaması ile entegre geri döngü ping testleri çalıştırın.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!diagnosticTestRunning && diagnosticTestStep == 0) {
                        Button(
                            onClick = {
                                scope.launch {
                                    diagnosticTestRunning = true
                                    diagnosticTestStep = 1
                                    delay(800)
                                    diagnosticTestStep = 2
                                    delay(1000)
                                    diagnosticTestStep = 3
                                    delay(900)
                                    diagnosticTestStep = 4 // Completed successfully
                                    diagnosticTestRunning = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("run_integrity_check")
                        ) {
                            Icon(imageVector = Icons.Default.NetworkCheck, contentDescription = "Kontrol")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("KONNEKTÖR BÜTÜNLÜK KONTROLÜNÜ ÇALIŞTIR")
                        }
                    } else {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.background)
                                .padding(12.dp)
                        ) {
                            HardwareDiagLine(title = "Seri Senkronizasyon Pingi", isPassing = diagnosticTestStep >= 1, isChecking = diagnosticTestStep == 0)
                            HardwareDiagLine(title = "Kristal Saat Sapma Kontrolü", isPassing = diagnosticTestStep >= 2, isChecking = diagnosticTestStep == 1)
                            HardwareDiagLine(title = "CAN Mikrodenetleyici Geri Döngü Senkronizasyonu", isPassing = diagnosticTestStep >= 3, isChecking = diagnosticTestStep == 2)
                            HardwareDiagLine(title = "Güvenlik El Sıkışma Anahtarı Kayıt Doğrulaması", isPassing = diagnosticTestStep >= 4, isChecking = diagnosticTestStep == 3)

                            if (diagnosticTestStep == 4) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Geçti", tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                    Text("TÜM ADAPTÖR SİSTEMLERİ GEÇTİ. YAZILIM GÜVENLİ.", fontSize = 10.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = { diagnosticTestStep = 0 },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.outline),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("KONTROLÜ SIFIRLA")
                                }
                            }
                        }
                    }
                }
            }

            // BULUT VERİTABANI SENKRONİZASYONU
            Text(
                "BULUT ENTEGRASYONU",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "☁️ X-DIAG Pro Bulut Veritabanı Güncelleme",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Google Drive havuz bağlantısındaki araç detaylı dosyalarını, gelişmiş PID tanımlarını ve özel servis modüllerini tek tıklamayla sisteme kurun.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (syncMessage != null) {
                        Surface(
                            color = if (syncMessage!!.contains("Hata")) MaterialTheme.colorScheme.errorContainer else Color(0xFF1B3B2B),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (syncMessage!!.contains("Hata")) Icons.Default.BugReport else Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (syncMessage!!.contains("Hata")) MaterialTheme.colorScheme.error else Color(0xFF10B981)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = syncMessage!!,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (syncMessage!!.contains("Hata")) MaterialTheme.colorScheme.onErrorContainer else Color.White
                                    )
                                }
                                IconButton(onClick = { viewModel.clearSyncMessage() }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Kapat", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    if (isSyncingVehicles) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                        ) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Text("Araçlar yükleniyor, lütfen bekleyin...", fontSize = 10.sp, color = Color.Gray)
                        }
                    } else {
                        Button(
                            onClick = { viewModel.syncVehiclesFromCloud() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("BULUT VERİTABANINDAN TÜM ARAÇLARI ÇEK")
                        }
                    }
                }
            }

            // DEVELOPER TOOLS
            Text(
                "GELİŞTİRİCİ ARAÇLARI",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                onClick = onNavigateToBleInspector,
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("🔧 BLE Cihaz Analiz Et", fontWeight = FontWeight.Bold)
                        Text("DS401 GATT Characteristics denetleyicisi.", fontSize = 11.sp, color = Color.Gray)
                    }
                    Text("AÇ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
            
            Card(
                onClick = onNavigateToProtocolGuide,
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("🔬 Cihaz Protokolü Analiz Rehberi", fontWeight = FontWeight.Bold)
                        Text("Bilinmeyen BLE OBD protokolünü bul.", fontSize = 11.sp, color = Color.Gray)
                    }
                    Text("AÇ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }

            // General Category: General System configurations
            Text(
                "ÖLÇÜM SİSTEMLERİ VE DİL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    // Config 1: Measurement Unit
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Standart Ölçüm Birimleri", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = if (activeMetricMode) "Metrik Değerler (°C, km/h, Bar)" else "İmparatorluk Değerleri (°F, mph, PSI)", fontSize = 10.sp, color = Color.Gray)
                        }
                        Row {
                            TextButton(
                                onClick = { activeMetricMode = true },
                                colors = ButtonDefaults.textButtonColors(
                                    contentColor = if (activeMetricMode) MaterialTheme.colorScheme.primary else Color.Gray
                                )
                            ) {
                                Text("METRİK", fontWeight = if (activeMetricMode) FontWeight.Bold else FontWeight.Normal)
                            }
                            TextButton(
                                onClick = { activeMetricMode = false },
                                colors = ButtonDefaults.textButtonColors(
                                    contentColor = if (!activeMetricMode) MaterialTheme.colorScheme.primary else Color.Gray
                                )
                            ) {
                                Text("İMPARATORLUK", fontWeight = if (!activeMetricMode) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    // Config 2: Language Profiles selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Language, contentDescription = "Dil", tint = MaterialTheme.colorScheme.primary)
                            Column {
                                Text(text = "Arayüz Dil Profili", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = "Seçilen profil: Türkçe (Türkiye)", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                        Text(text = "DEĞİŞTİR", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // General Category: Information footer
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Info, contentDescription = "Log Kaydı", tint = MaterialTheme.colorScheme.primary)
                    Column {
                        Text(text = "UYGULAMA REVİZYON PROFİLİ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = "İstemci Motor Sürümü: V7.00.014-release", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "Çekirdek ISO Modül Kitaplıkları: V15.82", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "Veri Tabanı Katalog Kod İmzaları: 2026.06.12", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "Telif Hakkı © X-DIAG Pro Global Otomotiv Diagnostik Yazılımları Ltd. Şti.", fontSize = 9.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun HardwareDiagLine(title: String, isPassing: Boolean, isChecking: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, fontSize = 11.sp)
        if (isPassing) {
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Geçti", tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                Text(text = "GEÇTİ", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
            }
        } else if (isChecking) {
            CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp)
        } else {
            Text(text = "BEKLEMEDE", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        }
    }
}
