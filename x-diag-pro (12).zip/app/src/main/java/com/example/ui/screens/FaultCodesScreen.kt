package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.style.TextAlign
import com.example.data.TroubleCode
import com.example.viewmodel.ClearResult
import com.example.ui.theme.MatcoCard
import com.example.ui.theme.MatcoCardBorder
import com.example.ui.theme.MatcoRed
import com.example.ui.theme.MatcoTextMuted
import com.example.viewmodel.DiagnosticViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaultCodesScreen(
    viewModel: DiagnosticViewModel,
    onBack: () -> Unit
) {
    val vehicle by viewModel.activeVehicle.collectAsState()
    val troubleCodes = remember(vehicle) {
        vehicle?.systems?.flatMap { it.troubleCodes } ?: emptyList()
    }
    
    val clearResult by viewModel.clearResult.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showClearDialog by remember { mutableStateOf(false) }

    // Collect clearResult for snackbar notifications
    LaunchedEffect(clearResult) {
        clearResult?.let { result ->
            when (result) {
                is ClearResult.Success -> {
                    if (result.remainingCount == 0) {
                        scope.launch {
                            snackbarHostState.showSnackbar("Muvaffakiyetle ${result.clearedCount} hata kodu sistemden silindi.")
                        }
                        showClearDialog = false
                        viewModel.resetClearResult()
                    } else {
                        scope.launch {
                            snackbarHostState.showSnackbar("${result.clearedCount} adet geçici hata kodu silindi, kalıcı hatalar kaldı.")
                        }
                    }
                }
                is ClearResult.Failed -> {
                    scope.launch {
                        snackbarHostState.showSnackbar("Hata: ${result.reason}")
                    }
                    viewModel.resetClearResult()
                }
                is ClearResult.VoltageError -> {
                    scope.launch {
                        snackbarHostState.showSnackbar("Hata: Akü gerilimi yetersiz! Min 12.1V gerekli.")
                    }
                    viewModel.resetClearResult()
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("DTC HATA KODLARI", fontWeight = FontWeight.Bold, color = MatcoRed) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    if (troubleCodes.isNotEmpty()) {
                        IconButton(onClick = { showClearDialog = true }) {
                            Icon(Icons.Default.DeleteForever, contentDescription = "Tümünü Sil", tint = MatcoRed)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (troubleCodes.isEmpty()) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(80.dp))
                        Text("Temiz Sistem Sağlığı!", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Araçta kayıtlı hiçbir aktif hata kodu (DTC) bulunamadı.", color = MatcoTextMuted)
                        Button(
                            onClick = onBack,
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                        ) {
                            Text("GERİ DÖN")
                        }
                    }
                }
            } else {
                Text(
                    text = "Araçta ${troubleCodes.size} Adet Teşhis Hata Kodu Tespit Edildi",
                    fontSize = 14.sp,
                    color = MatcoTextMuted,
                    fontWeight = FontWeight.SemiBold
                )

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(troubleCodes) { dtc ->
                        TroubleCodeCard(dtc, viewModel)
                    }
                }

                Button(
                    onClick = { showClearDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("HATALARI SİL (MODE 04)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showClearDialog) {
        DtcClearDialog(
            viewModel = viewModel,
            onDismiss = {
                showClearDialog = false
                viewModel.resetClearResult()
            }
        )
    }
}

@Composable
fun TroubleCodeCard(
    dtc: TroubleCode,
    viewModel: DiagnosticViewModel,
    onNavigate: ((String) -> Unit)? = null
) {
    val statusInfo = remember(dtc.status) { 
        com.example.data.DtcStatusDictionary.classify(dtc.status) 
    }
    val statusColor = try {
        Color(android.graphics.Color.parseColor(statusInfo.colorHex))
    } catch (e: Exception) {
        Color.Red
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MatcoCard),
        border = BorderStroke(1.dp, MatcoCardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val iconTint = when (dtc.severity.lowercase()) {
                        "critical", "kritik" -> Color.Red
                        "warning", "uyarı" -> Color(0xFFF59E0B)
                        else -> Color(0xFF3B82F6)
                    }
                    Icon(Icons.Default.Error, contentDescription = null, tint = iconTint)
                    Text(
                        text = dtc.code,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = MatcoRed
                    )
                }
                
                Box(
                    modifier = Modifier
                        .background(Color(android.graphics.Color.parseColor(statusInfo.colorHex)).copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = statusInfo.labelTr,
                        color = Color(android.graphics.Color.parseColor(statusInfo.colorHex)),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = dtc.description,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.White
            )

            // Teknisyen durum açıklaması
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(statusColor.copy(0.08f), RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Text(
                        text = "Hata Türü: ${statusInfo.labelTr}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(0.9f)
                    )
                    Text(
                        text = "💡 ${statusInfo.technicianNote}",
                        fontSize = 11.sp,
                        color = MatcoTextMuted,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = MatcoCardBorder.copy(0.5f))

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(12.dp), tint = MatcoTextMuted)
                Text(
                    text = "ECU Modülü: ${dtc.moduleName}",
                    fontSize = 12.sp,
                    color = MatcoTextMuted
                )
            }

            if (onNavigate != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = {
                        val matchedGuide = com.example.data.RepairGuideMatcher.findGuideForDtc(dtc.code, com.example.ui.screens.ALL_REPAIR_GUIDES)
                        if (matchedGuide != null) {
                            viewModel.selectedDtcCodeForRepair.value = dtc.code
                            onNavigate("repair_info")
                        } else {
                            viewModel.selectedDtcCodeForRepair.value = dtc.code
                            onNavigate("ai_diagnose")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "📖 ONARIM REHBERİNİ GÖR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            if (dtc.helpText.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White.copy(0.05f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                "Teknisyen Tavsiyesi:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF59E0B)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = dtc.helpText,
                                fontSize = 11.sp,
                                color = Color.White.copy(0.85f),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            val isPermanent = (dtc.status.lowercase().contains("aktif") || dtc.status.lowercase().contains("kalıcı") || dtc.status.lowercase().contains("active")) && !dtc.status.lowercase().contains("giderildi")
            
            if (isPermanent) {
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = { viewModel.repairTroubleCode(dtc.code) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = Color.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "FİZİKSEL PARÇAYI ONAR / SİMÜLE ET",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
                Text(
                    text = "Açıklama: Bu parçayı onarmadan/değiştirmeden beyin hafızası silinse bile, hata kodu anında geri gelecektir.",
                    fontSize = 10.sp,
                    color = MatcoTextMuted,
                    lineHeight = 13.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            } else if (dtc.status.lowercase().contains("giderildi")) {
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = Color(0xFF10B981).copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Color(0xFF10B981)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(16.dp)
                        )
                        Column {
                            Text(
                                text = "Fiziksel Parça Onarıldı / Değiştirildi",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                            Text(
                                text = "Arıza giderildi, hata geçici duruma alındı. Artık 'HATALARI SİL' yapabilirsiniz.",
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.8f),
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DtcClearDialog(
    viewModel: DiagnosticViewModel,
    onDismiss: () -> Unit
) {
    val clearResult by viewModel.clearResult.collectAsState()
    val batteryVoltage by viewModel.batteryVoltage.collectAsState()
    var isClearing by remember { mutableStateOf(false) }
    var technicianName by remember { mutableStateOf("Teknisyen Ali") }

    Dialog(onDismissRequest = { if (!isClearing) onDismiss() }) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MatcoCard),
            border = BorderStroke(1.dp, MatcoCardBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (clearResult == null && !isClearing) {
                    Icon(
                        Icons.Default.Warning,
                        contentDescription = null,
                        tint = MatcoRed,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        "Arıza Kodları Silinecek",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                    Text(
                        "Kontak açık, motor kapalı olmalıdır. Akü geriliminin en az 12.1V olması önerilir (Mevcut: ${String.format("%.2f", batteryVoltage)}V). Emin misiniz?",
                        color = MatcoTextMuted,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )

                    OutlinedTextField(
                        value = technicianName,
                        onValueChange = { technicianName = it },
                        label = { Text("Teknisyen Adı", color = MatcoRed) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MatcoRed,
                            unfocusedBorderColor = MatcoCardBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("İPTAL")
                        }
                        Button(
                            onClick = {
                                isClearing = true
                                viewModel.clearFaultCodes(technicianName)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MatcoRed)
                        ) {
                            Text("EVET, SİL")
                        }
                    }
                } else if (isClearing && clearResult == null) {
                    CircularProgressIndicator(
                        color = MatcoRed,
                        modifier = Modifier.size(50.dp)
                    )
                    Text(
                        "Kodlar Siliniyor...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        "ELM327 adaptörü üzerinden Mode 04 komutu gönderiliyor, lütfen bekleyiniz...",
                        color = MatcoTextMuted,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                } else {
                    // Result state
                    val result = clearResult
                    if (result != null) {
                        when (result) {
                            is ClearResult.Success -> {
                                if (result.remainingCount > 0) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = Color(0xFFF59E0B),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Text(
                                        "Kısmi Temizleme Yapıldı",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = Color(0xFFF59E0B),
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        "Mode 4 komutuyla ${result.clearedCount} adet geçici hata silindi.\n\n" +
                                        "⚠️ ANCAK, fiziksel onarımı yapılmayan ${result.remainingCount} adet KALICI/AKTİF hata kodu (Örn: ${result.remainingCodes.joinToString(", ")}) silinemedi/tekrar beynine yazıldı!",
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp,
                                        textAlign = TextAlign.Center
                                    )
                                } else {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Text(
                                        "İşlem Başarılı",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        color = Color(0xFF10B981)
                                    )
                                    Text(
                                        "Muvaffakiyetle ${result.clearedCount} adet hata kodu araç hafızasından silindi.",
                                        color = MatcoTextMuted,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                            is ClearResult.VoltageError -> {
                                Icon(
                                    Icons.Default.Error,
                                    contentDescription = null,
                                    tint = Color.Red,
                                    modifier = Modifier.size(56.dp)
                                )
                                Text(
                                    "Akü Voltajı Düşük",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.Red
                                )
                                Text(
                                    "Akü gerilimi yetersiz! Akü adaptasyonu ve kalıcı silme için en az 12.1V gerilim gereklidir. Ölçülen: ${String.format("%.2f", batteryVoltage)}V",
                                    color = MatcoTextMuted,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                            }
                            is ClearResult.Failed -> {
                                Icon(
                                    Icons.Default.Error,
                                    contentDescription = null,
                                    tint = Color.Red,
                                    modifier = Modifier.size(56.dp)
                                )
                                Text(
                                    "Silme Başarısız",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.Red
                                )
                                Text(
                                    "Hata Nedeni: ${result.reason}",
                                    color = MatcoTextMuted,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            isClearing = false
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MatcoRed),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("TAMAM")
                    }
                }
            }
        }
    }
}
