package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MatcoColorScheme = darkColorScheme(
    primary = MatcoRed,
    secondary = MatcoAccent,
    background = MatcoDark,
    surface = MatcoCard,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = MatcoTextPrimary,
    onSurface = MatcoTextPrimary,
    surfaceVariant = MatcoCard,
    outline = MatcoCardBorder,
    outlineVariant = MatcoCardBorder.copy(alpha = 0.6f),
    primaryContainer = MatcoRed.copy(alpha = 0.15f),
    error = Color(0xFFEF4444)
)

@Composable
fun MyApplicationTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MatcoColorScheme,
        typography = Typography,
        content = content
    )
}