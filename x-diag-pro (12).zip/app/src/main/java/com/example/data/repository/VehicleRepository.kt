package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.AppDatabase
import com.example.data.api.RetrofitClient
import com.example.data.api.VehicleApiService
import com.example.data.db.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class SyncProgress(
    val isRunning: Boolean = false,
    val currentStep: String = "",
    val progressPercent: Int = 0,
    val errorMessage: String? = null
)

class VehicleRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val api: VehicleApiService = RetrofitClient.getClient(context)
    private val prefs: SharedPreferences = context.getSharedPreferences("obd_sync_prefs", Context.MODE_PRIVATE)

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val listType = Types.newParameterizedType(List::class.java, String::class.java)
    private val stringListAdapter = moshi.adapter<List<String>>(listType)

    // DAOs
    val brandDao = db.vehicleBrandDao()
    val modelDao = db.vehicleModelDao()
    val ecuDao = db.ecuSystemDao()
    val dtcDao = db.troubleCodeDao()
    val pidDao = db.livePidDefinitionDao()
    val specialDao = db.specialFunctionDao()

    private val _syncProgress = MutableStateFlow(SyncProgress())
    val syncProgress: StateFlow<SyncProgress> = _syncProgress.asStateFlow()

    suspend fun getLocalDbVersion(): Int = withContext(Dispatchers.IO) {
        prefs.getInt("local_db_version", 1)
    }

    suspend fun setLocalDbVersion(version: Int) = withContext(Dispatchers.IO) {
        prefs.edit().putInt("local_db_version", version).apply()
    }

    suspend fun checkForUpdates(): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = api.getDbVersion()
            if (response.isSuccessful) {
                val remoteVersionInfo = response.body()
                if (remoteVersionInfo != null) {
                    val localVersion = getLocalDbVersion()
                    if (remoteVersionInfo.version > localVersion) {
                        Log.d("VehicleRepository", "Yeni veritabanı sürümü mevcut (Sürüm ${remoteVersionInfo.version}). Eşitleme başlatılıyor.")
                        syncAll()
                        setLocalDbVersion(remoteVersionInfo.version)
                        return@withContext true
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("VehicleRepository", "Sürüm denetlenirken hata oluştu: ", e)
        }
        return@withContext false
    }

    suspend fun syncAll() = withContext(Dispatchers.IO) {
        try {
            _syncProgress.value = SyncProgress(isRunning = true, currentStep = "Eşitleme başlatılıyor...", progressPercent = 0)
            
            syncBrands()
            _syncProgress.value = _syncProgress.value.copy(currentStep = "Markalar eşitlendi", progressPercent = 20)

            syncModels()
            _syncProgress.value = _syncProgress.value.copy(currentStep = "Modeller eşitlendi", progressPercent = 40)

            syncDtcCodes()
            _syncProgress.value = _syncProgress.value.copy(currentStep = "Arıza Kodları eşitlendi", progressPercent = 60)

            syncPids()
            _syncProgress.value = _syncProgress.value.copy(currentStep = "Parametre (PID) listeleri eşitlendi", progressPercent = 80)

            syncSpecialFunctions()
            _syncProgress.value = _syncProgress.value.copy(isRunning = false, currentStep = "Eşitleme başarıyla tamamlandı", progressPercent = 100)
        } catch (e: Exception) {
            _syncProgress.value = SyncProgress(isRunning = false, currentStep = "Eşitleme başarısız oldu", progressPercent = 0, errorMessage = e.localizedMessage)
            Log.e("VehicleRepository", "Eşitleme hatası: ", e)
            throw e
        }
    }

    suspend fun syncBrands() = withContext(Dispatchers.IO) {
        try {
            val response = api.getBrands(region = null)
            if (response.isSuccessful) {
                val responseBody = response.body()
                if (responseBody?.success == true) {
                    val dbBrands = responseBody.data.map { br ->
                        VehicleBrand(
                            id = br.id,
                            name = br.name,
                            nameLocal = br.nameLocal,
                            region = br.region,
                            isPopular = br.isPopular,
                            sortOrder = br.sortOrder
                        )
                    }
                    brandDao.insertAll(dbBrands)
                }
            }
        } catch (e: Exception) {
            Log.e("VehicleRepository", "Marka eşitleme hatası, yerel veriler korunuyor.", e)
            throw e
        }
    }

    suspend fun syncModels() = withContext(Dispatchers.IO) {
        try {
            val response = api.getModels(brandId = null)
            if (response.isSuccessful) {
                val responseBody = response.body()
                if (responseBody?.success == true) {
                    val dbModels = responseBody.data.map { mo ->
                        VehicleModel(
                            id = mo.id,
                            brandId = mo.brandId,
                            name = mo.name,
                            nameLocal = mo.nameLocal,
                            yearStart = mo.yearStart,
                            yearEnd = mo.yearEnd,
                            engineCodes = stringListAdapter.toJson(mo.engineCodes),
                            bodyTypes = stringListAdapter.toJson(mo.bodyTypes)
                        )
                    }
                    modelDao.insertAll(dbModels)
                }
            }
        } catch (e: Exception) {
            Log.e("VehicleRepository", "Model eşitleme hatası, yerel veriler korunuyor.", e)
            throw e
        }
    }

    suspend fun syncDtcCodes() = withContext(Dispatchers.IO) {
        try {
            val response = api.getDtcCodes(brandId = 19, systemCode = null) // Auris brandId=19 (Toyota) as example
            if (response.isSuccessful) {
                val responseBody = response.body()
                if (responseBody?.success == true) {
                    val dbDtcs = responseBody.data.map { dt ->
                        val systemId = when(dt.systemCode) {
                            "ABS" -> 3
                            "SRS" -> 4
                            else -> 1 // Default to Engine Control Module
                        }
                        TroubleCode(
                            systemId = systemId,
                            code = dt.code,
                            codeType = "POWERTRAIN",
                            descriptionTr = dt.descriptionTr,
                            descriptionEn = dt.descriptionEn,
                            severity = dt.severity,
                            possibleCauses = stringListAdapter.toJson(dt.possibleCauses),
                            possibleFixes = stringListAdapter.toJson(dt.possibleFixes),
                            affectedComponents = stringListAdapter.toJson(dt.affectedComponents)
                        )
                    }
                    dtcDao.insertAll(dbDtcs)
                }
            }
        } catch (e: Exception) {
            Log.e("VehicleRepository", "DTC eşitleme hatası, yerel veriler korunuyor.", e)
            throw e
        }
    }

    suspend fun syncPids() = withContext(Dispatchers.IO) {
        try {
            val response = api.getPids(brandId = null)
            if (response.isSuccessful) {
                val responseBody = response.body()
                if (responseBody?.success == true) {
                    val dbPids = responseBody.data.map { p ->
                        LivePidDefinition(
                            pid = p.pid,
                            name = p.name,
                            nameEn = p.nameEn,
                            unit = p.unit,
                            formula = p.formula,
                            minValue = p.minValue,
                            maxValue = p.maxValue,
                            brandId = p.brandId,
                            isDefault = p.isDefault,
                            mode = p.mode
                        )
                    }
                    pidDao.insertAll(dbPids)
                }
            }
        } catch (e: Exception) {
            Log.e("VehicleRepository", "PID eşitleme hatası, yerel veriler korunuyor.", e)
            throw e
        }
    }

    suspend fun syncSpecialFunctions() = withContext(Dispatchers.IO) {
        try {
            val response = api.getSpecialFunctions(brandId = null)
            if (response.isSuccessful) {
                val responseBody = response.body()
                if (responseBody?.success == true) {
                    val dbFunctions = responseBody.data.map { f ->
                        SpecialFunction(
                            brandId = f.brandId,
                            modelId = f.modelId,
                            functionCode = f.functionCode,
                            functionName = f.functionName,
                            warningText = f.warningText,
                            commandSequence = stringListAdapter.toJson(f.commandSequence),
                            description = f.description,
                            requiresVehicleOff = f.requiresVehicleOff,
                            requiresEngineRunning = f.requiresEngineRunning,
                            minVoltage = f.minVoltage
                        )
                    }
                    specialDao.insertAll(dbFunctions)
                }
            }
        } catch (e: Exception) {
            Log.e("VehicleRepository", "Servis fonksiyonları eşitleme hatası, yerel veriler korunuyor.", e)
            throw e
        }
    }

    suspend fun findBrandByAnyName(query: String): VehicleBrand? = withContext(Dispatchers.IO) {
        val trimmedQuery = query.trim().lowercase()
        // 1. Önce tam name eşleşmesi dene
        val exactMatch = brandDao.getByName(query.trim())
        if (exactMatch != null) return@withContext exactMatch

        // 2. Tüm markaları çekip nameLocal veya aliasNames JSON içinde ara (case-insensitive)
        val allBrands = brandDao.getAllBrandsList()
        for (brand in allBrands) {
            if (brand.name.lowercase() == trimmedQuery || brand.nameLocal.lowercase() == trimmedQuery) {
                return@withContext brand
            }
            val aliases = try {
                stringListAdapter.fromJson(brand.aliasNames) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
            if (aliases.any { it.trim().lowercase() == trimmedQuery }) {
                return@withContext brand
            }
        }
        null
    }
}
