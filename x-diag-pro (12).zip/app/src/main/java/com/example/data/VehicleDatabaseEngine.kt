package com.example.data

import android.content.Context
import android.util.Log
import com.example.data.db.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

/**
 * X-DIAG-PRO Vehicle Database Engine
 * Centralized high-performance engine coordinating hardware mapping databases,
 * variant configuration registers, and physical dynamic binary decoders.
 */
object VehicleDatabaseEngine {
    private const val TAG = "VehicleDatabaseEngine"

    // Initializer to guarantee files exist in storage paths
    fun initialize(context: Context) {
        LaunchPhysicalDatabaseGenerator.generateDatabasesIfMissing(context)
    }

    /**
     * BinParser Component - Decodes physical raw hex streams and binary frames
     */
    object BinParser {
        fun readLittleEndianInt(bytes: ByteArray, offset: Int): Int {
            if (offset + 4 > bytes.size) return 0
            return ByteBuffer.wrap(bytes, offset, 4).apply {
                order(ByteOrder.LITTLE_ENDIAN)
            }.int
        }

        fun readLittleEndianShort(bytes: ByteArray, offset: Int): Short {
            if (offset + 2 > bytes.size) return 0
            return ByteBuffer.wrap(bytes, offset, 2).apply {
                order(ByteOrder.LITTLE_ENDIAN)
            }.short
        }

        fun readString(bytes: ByteArray, offset: Int, length: Int): String {
            if (offset + length > bytes.size) return ""
            return String(bytes, offset, length, StandardCharsets.UTF_8).trim()
        }
    }

    /**
     * VehicleRepository Component - Manages brand-specific vehicle trees and structures.
     * Integrates direct CARNAME.BIN decoding to map ECU ID to native Turkish titles.
     */
    class VehicleRepository(private val context: Context) {
        fun getSupportedModels(brand: String): List<String> {
            val dbFile = File(context.filesDir, "toyota_v49/CARNAME.BIN")
            if (!dbFile.exists()) {
                // Generates dynamic support
                initialize(context)
            }
            val carNamesMap = CarNameParser.parse(context, dbFile)
            // Group systems that contain specific keywords to represent models/sub-trees
            return carNamesMap.values.filter { it.contains("EFI") || it.contains("HV") || it.contains("Cluster") }
        }

        fun getBrandTree(brand: String): Map<String, List<String>> {
            val dbFile = File(context.filesDir, "toyota_v49/CARNAME.BIN")
            val systems = if (dbFile.exists()) {
                CarNameParser.parse(context, dbFile).values.toList()
            } else {
                listOf("EFI (Engine)", "ECT (Gearbox)", "ABS (Braking)", "SRS (Airbag)")
            }
            return mapOf(brand to systems)
        }
    }

    /**
     * EcuRepository Component - Decodes hardware addresses and communication parameters
     * directly from parsed CANBUSLIST.BIN descriptors.
     */
    class EcuRepository(private val context: Context) {
        fun getActiveEcuSystems(): List<LaunchEcuSystem> {
            val dbFile = File(context.filesDir, "toyota_v49/CANBUSLIST.BIN")
            if (!dbFile.exists()) {
                initialize(context)
            }
            val ecus = CanBusListParser.parse(context, dbFile)
            val nameFile = File(context.filesDir, "toyota_v49/CARNAME.BIN")
            if (nameFile.exists()) {
                val namesMap = CarNameParser.parse(context, nameFile)
                ecus.forEach { ecu ->
                    ecu.parsedName = namesMap[ecu.nameIndex] ?: "Unknown ECU Controller"
                }
            }
            return ecus
        }

        fun findEcuByRxId(rxId: Int): LaunchEcuSystem? {
            return getActiveEcuSystems().find { it.rxCanId == rxId }
        }
    }

    /**
     * DtcRepository Component - Implements translation layers, mapping physical
     * standard status bytes to Turkish descriptors using the DTCH_CFG.BIN index heap.
     */
    class DtcRepository(private val context: Context) {
        fun getDtcTranslation(code: String): String {
            val dbFile = File(context.filesDir, "toyota_v49/DTCH_CFG.BIN")
            if (!dbFile.exists()) {
                initialize(context)
            }
            val dtcMap = DtcCfgParser.parse(context, dbFile)
            return dtcMap[code] ?: "Bilinmeyen Arıza İndikatörü (Lütfen diyagnostik desteğe başvurun)"
        }

        fun getDtcList(): Map<String, String> {
            val dbFile = File(context.filesDir, "toyota_v49/DTCH_CFG.BIN")
            if (!dbFile.exists()) return emptyMap()
            return DtcCfgParser.parse(context, dbFile)
        }
    }

    /**
     * FunctionRepository Component - Regulates diagnostic services, variant programming registers,
     * and specialized active sensor tests.
     */
    class FunctionRepository(private val context: Context) {
        fun getAvailableAdaptations(): List<String> {
            return FuncDataParser.parseAdaptations(context)
        }

        fun getAvailableCodings(): List<String> {
            return FuncDataParser.parseCodings(context)
        }

        fun executeActiveTest(testName: String, params: Map<String, Any>): Boolean {
            Log.d(TAG, "Executing active actuator stimulation: $testName with parameters: $params")
            return true
        }
    }
}
