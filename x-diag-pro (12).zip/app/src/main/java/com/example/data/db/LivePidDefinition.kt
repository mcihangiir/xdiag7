package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "live_pid_definitions")
data class LivePidDefinition(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val pid: String,
    val name: String,
    val nameEn: String,
    val unit: String,
    val formula: String,
    val minValue: Float,
    val maxValue: Float,
    val mode: String, // "01", "21", "22"
    val brandId: Int? = null,
    val isDefault: Boolean = false
) : Serializable
