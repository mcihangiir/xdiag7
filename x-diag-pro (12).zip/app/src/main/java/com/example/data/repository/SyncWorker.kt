package com.example.data.repository

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.flow.first

class SyncWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val repository = VehicleRepository(applicationContext)
        Log.d("SyncWorker", "Arka plan veritabanı eşitleme Worker görevi başladı.")

        return try {
            val lastBrandCount = repository.brandDao.getAll().first().size
            val lastModelCount = repository.modelDao.getAll().first().size

            repository.syncAll()

            val newBrandCount = repository.brandDao.getAll().first().size
            val newModelCount = repository.modelDao.getAll().first().size

            val addedBrands = newBrandCount - lastBrandCount
            val addedModels = newModelCount - lastModelCount

            showNotification(
                "XDiag Araç Veritabanı Güncellendi",
                "Arka planda $addedBrands yeni marka ve $addedModels yeni araç modeli tanımlandı."
            )

            Result.success()
        } catch (e: Exception) {
            Log.e("SyncWorker", "Eşitleme Worker arızalandı, yeniden denenecek.", e)
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure()
            }
        }
    }

    private fun showNotification(title: String, message: String) {
        val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "obd_sync_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Araç Veritabanı Eşitleme",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle(title)
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(742, notification)
    }
}
