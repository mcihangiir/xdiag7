package com.example.data

import android.content.Context
import android.util.Log
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

object EcuDataParser {
    private const val TAG = "EcuDataParser"

    /**
     * Parses an ECU binary file directly from the application's assets or falls back to standard emulation.
     */
    fun parseAssetBinary(context: Context, assetPath: String, fallbackEcuCode: Int): ToyotaEcuData {
        return try {
            val assetManager = context.assets
            val inputStream: InputStream = assetManager.open(assetPath)
            val bytes = inputStream.readBytes()
            inputStream.close()
            Log.d(TAG, "Successfully loaded real asset file: $assetPath (${bytes.size} bytes)")
            parse(fallbackEcuCode, bytes)
        } catch (e: Exception) {
            Log.w(TAG, "Asset '$assetPath' not found or failed to load. Using standard emulation.", e)
            parse(fallbackEcuCode, null)
        }
    }

    /**
     * Parses custom or simulated binary bytes into a ToyotaEcuData representation.
     */
    fun parse(ecuCode: Int, customBytes: ByteArray? = null): ToyotaEcuData {
        val bytes = customBytes ?: createSimulatedBinary(ecuCode)
        val buffer = ByteBuffer.wrap(bytes).apply {
            order(ByteOrder.LITTLE_ENDIAN)
        }

        try {
            // Read Header
            if (buffer.remaining() < 55) { // Minimum header length
                return createFallbackEcu(ecuCode)
            }
            val magicBytes = ByteArray(5)
            buffer.get(magicBytes)
            val magic = String(magicBytes, StandardCharsets.US_ASCII)

            val verBytes = ByteArray(6)
            buffer.get(verBytes)
            val version = String(verBytes, StandardCharsets.US_ASCII).trim()

            val readEcuCode = buffer.short.toInt() and 0xFFFF
            
            val nameBytes = ByteArray(32)
            buffer.get(nameBytes)
            val systemName = String(nameBytes, StandardCharsets.UTF_8).trim()

            val pidOffset = buffer.int
            val pidCount = buffer.int
            val dtcOffset = buffer.int
            val dtcCount = buffer.int
            val specOffset = buffer.int
            val specCount = buffer.int

            val header = EcuBinaryHeader(
                magic, version, readEcuCode, systemName,
                pidOffset, pidCount, dtcOffset, dtcCount, specOffset, specCount
            )

            // Extract PIDs
            val pids = mutableListOf<ToyotaPidDefinition>()
            if (pidOffset in 0..bytes.size) {
                buffer.position(pidOffset)
                for (i in 0 until pidCount) {
                    if (buffer.remaining() < 102) break
                    val pidId = buffer.short.toInt() and 0xFFFF
                    
                    val codeBytes = ByteArray(8)
                    buffer.get(codeBytes)
                    val hexCode = String(codeBytes, StandardCharsets.US_ASCII).trim()

                    val nameBytesField = ByteArray(24)
                    buffer.get(nameBytesField)
                    val name = String(nameBytesField, StandardCharsets.UTF_8).trim()

                    val dscBytes = ByteArray(48)
                    buffer.get(dscBytes)
                    val dscTr = String(dscBytes, StandardCharsets.UTF_8).trim()

                    val unitBytes = ByteArray(12)
                    buffer.get(unitBytes)
                    val unit = String(unitBytes, StandardCharsets.UTF_8).trim()

                    val minVal = buffer.float
                    val maxVal = buffer.float

                    pids.add(
                        ToyotaPidDefinition(
                            id = pidId,
                            hexCode = hexCode,
                            name = name,
                            dscTr = dscTr,
                            unit = unit,
                            minValue = minVal,
                            maxValue = maxVal
                        )
                    )
                }
            }

            // Extract DTCs
            val dtcs = mutableListOf<ToyotaDtcDefinition>()
            if (dtcOffset in 0..bytes.size) {
                buffer.position(dtcOffset)
                for (i in 0 until dtcCount) {
                    if (buffer.remaining() < 120) break
                    val codeBytes = ByteArray(8)
                    buffer.get(codeBytes)
                    val code = String(codeBytes, StandardCharsets.US_ASCII).trim()

                    val descBytes = ByteArray(64)
                    buffer.get(descBytes)
                    val dscTr = String(descBytes, StandardCharsets.UTF_8).trim()

                    val statusBytes = ByteArray(16)
                    buffer.get(statusBytes)
                    val statusTr = String(statusBytes, StandardCharsets.UTF_8).trim()

                    val subsysBytes = ByteArray(32)
                    buffer.get(subsysBytes)
                    val subsystem = String(subsysBytes, StandardCharsets.UTF_8).trim()

                    dtcs.add(
                        ToyotaDtcDefinition(
                            code = code,
                            dscTr = dscTr,
                            statusTr = statusTr,
                            subsystem = subsystem
                        )
                    )
                }
            }

            // Extract Special Functions
            val specials = mutableListOf<ToyotaSpecialFunction>()
            if (specOffset in 0..bytes.size) {
                buffer.position(specOffset)
                for (i in 0 until specCount) {
                    if (buffer.remaining() < 142) break
                    val specId = buffer.short.toInt() and 0xFFFF

                    val nameBytesField = ByteArray(48)
                    buffer.get(nameBytesField)
                    val nameTr = String(nameBytesField, StandardCharsets.UTF_8).trim()

                    val dscBytes = ByteArray(80)
                    buffer.get(dscBytes)
                    val dscTr = String(dscBytes, StandardCharsets.UTF_8).trim()

                    val uidBytes = ByteArray(12)
                    buffer.get(uidBytes)
                    val udsId = String(uidBytes, StandardCharsets.US_ASCII).trim()

                    specials.add(
                        ToyotaSpecialFunction(
                            id = specId,
                            nameTr = nameTr,
                            descriptionTr = dscTr,
                            udsServiceId = udsId
                        )
                    )
                }
            }

            return ToyotaEcuData(header, pids, dtcs, specials)

        } catch (e: Exception) {
            Log.e(TAG, "Error parsing simulated binary data", e)
            return createFallbackEcu(ecuCode)
        }
    }

    /**
     * Helper to create a binary payload structure on fly.
     */
    fun createSimulatedBinary(ecuCode: Int): ByteArray {
        val out = ByteBuffer.allocate(4096).apply {
            order(ByteOrder.LITTLE_ENDIAN)
        }

        // Header
        out.put("XDIAG".toByteArray(StandardCharsets.US_ASCII))
        out.put("V49.50".toByteArray(StandardCharsets.US_ASCII))
        out.putShort(ecuCode.toShort())

        val name = when (ecuCode) {
            0x1000 -> "Engine Control Module (ECM)"
            0x2000 -> "Transmission Control (TCM)"
            0x3000 -> "Anti-lock Braking (ABS)"
            0x4000 -> "Supplemental Restraint (SRS)"
            0x5000 -> "Body Control Module (BCM)"
            0x6000 -> "Steering Angle Sensor (SAS)"
            0x7000 -> "Tire Pressure Monitor (TPMS)"
            0x8000 -> "Advanced Driver Assist (ADAS)"
            else -> "Multiplex Gateway System (BCM)"
        }
        out.put(name.padToBytes(32))

        val pidOffset = 120
        val dtcOffset = 600
        val specOffset = 1200

        out.putInt(pidOffset)
        out.putInt(0) // PID count placeholder
        out.putInt(dtcOffset)
        out.putInt(0) // DTC count placeholder
        out.putInt(specOffset)
        out.putInt(0) // Special count placeholder

        // Fill PIDs
        out.position(pidOffset)
        val pidsList = getEcuSpecificPids(ecuCode)
        val pidCount = pidsList.size
        out.putInt(56, pidCount) // index in header

        for (pid in pidsList) {
            out.putShort(pid.id.toShort())
            out.put(pid.hexCode.padToBytes(8, StandardCharsets.US_ASCII))
            out.put(pid.name.padToBytes(24))
            out.put(pid.dscTr.padToBytes(48))
            out.put(pid.unit.padToBytes(12))
            out.putFloat(pid.minValue)
            out.putFloat(pid.maxValue)
        }

        // Fill DTCs
        out.position(dtcOffset)
        val dtcsList = getEcuSpecificDtcs(ecuCode)
        val dtcCount = dtcsList.size
        out.putInt(64, dtcCount) // index in header

        for (dtc in dtcsList) {
            out.put(dtc.code.padToBytes(8, StandardCharsets.US_ASCII))
            out.put(dtc.dscTr.padToBytes(64))
            out.put(dtc.statusTr.padToBytes(16))
            out.put(dtc.subsystem.padToBytes(32))
        }

        // Fill Specials
        out.position(specOffset)
        val specialsList = getEcuSpecificSpecials(ecuCode)
        val specCount = specialsList.size
        out.putInt(72, specCount) // index in header

        for (spec in specialsList) {
            out.putShort(spec.id.toShort())
            out.put(spec.nameTr.padToBytes(48))
            out.put(spec.descriptionTr.padToBytes(80))
            out.put(spec.udsServiceId.padToBytes(12, StandardCharsets.US_ASCII))
        }

        val totalSize = out.position()
        val finalBytes = ByteArray(totalSize)
        out.position(0)
        out.get(finalBytes)
        return finalBytes
    }

    private fun String.padToBytes(size: Int, charset: java.nio.charset.Charset = StandardCharsets.UTF_8): ByteArray {
        val raw = this.toByteArray(charset)
        val out = ByteArray(size)
        System.arraycopy(raw, 0, out, 0, minOf(raw.size, size))
        return out
    }

    private fun getEcuSpecificPids(ecuCode: Int): List<ToyotaPidDefinition> {
        return when (ecuCode) {
            0x1000 -> listOf(
                ToyotaPidDefinition(1, "010C", "Engine_RPM", "Motor Devri", "RPM", "TrendingUp", "A*4", 0f, 8000f),
                ToyotaPidDefinition(2, "010D", "Vehicle_Speed", "Araç Hızı", "km/h", "Speed", "A", 0f, 260f),
                ToyotaPidDefinition(3, "0105", "Coolant_Temp", "Motor Soğutma Suyu Sıcaklığı", "°C", "Thermostat", "A-40", -40f, 215f),
                ToyotaPidDefinition(4, "0110", "MAF_Flow", "Kütle Hava Akış Sensörü", "g/s", "Air", "((A*256)+B)/100", 0f, 650f),
                ToyotaPidDefinition(5, "2144", "VVT_Advance", "VVT-i Eksantrik Açısı", "°", "RotateLeft", "A/2-64", -64f, 63.5f),
                ToyotaPidDefinition(6, "2130", "Injection_Dur", "Enjeksiyon Süresi", "ms", "Bolt", "((A*256)+B)/100", 0f, 30f)
            )
            0x2000 -> listOf(
                ToyotaPidDefinition(11, "2182", "ATF_Temp", "Şanzıman Hidrolik Yağ Sıcaklığı", "°C", "Thermostat", "A-40", -40f, 150f),
                ToyotaPidDefinition(12, "2183", "LockUp_Solenoid", "Tork Konvertör Lock-Up Solenoidi", "%", "Settings", "A*100/255", 0f, 100f),
                ToyotaPidDefinition(13, "2184", "Gear_Position", "Aktif Şanzıman Vites Oranı", "Vites", "FilterAlt", "A", 1f, 8f)
            )
            0x3000 -> listOf(
                ToyotaPidDefinition(21, "2231", "FL_Wheel_Speed", "Ön Sol Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(22, "2232", "FR_Wheel_Speed", "Ön Sağ Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(23, "2233", "RL_Wheel_Speed", "Arka Sol Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(24, "2234", "RR_Wheel_Speed", "Arka Sağ Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(25, "2235", "YAW_Rate", "ABS Cayro Yalpalama Oranı (Yaw)", "°/s", "Compare", "((A*256)+B)/10-100", -100f, 100f)
            )
            0x7000 -> listOf(
                ToyotaPidDefinition(31, "2241", "FL_TPMS_Press", "Ön Sol Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f),
                ToyotaPidDefinition(32, "2242", "FR_TPMS_Press", "Ön Sağ Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f),
                ToyotaPidDefinition(33, "2243", "RL_TPMS_Press", "Arka Sol Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f),
                ToyotaPidDefinition(34, "2244", "RR_TPMS_Press", "Arka Sağ Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f)
            )
            else -> listOf(
                ToyotaPidDefinition(41, "2101", "Control_Module_V", "ECU Kontrol Modülü Voltajı", "V", "Bolt", "A/10", 0f, 18f),
                ToyotaPidDefinition(42, "2102", "Ground_Resistance", "Şasi Toprak Direnci", "Ohm", "SettingsEthernet", "A/100", 0f, 5f)
            )
        }
    }

    private fun getEcuSpecificDtcs(ecuCode: Int): List<ToyotaDtcDefinition> {
        return when (ecuCode) {
            0x1000 -> listOf(
                ToyotaDtcDefinition("P0101", "Düşük Akış - Kütle veya Hacim Hava Akış Devresi Arızası", "Kayıtlı", "Güç Grubu (Powertrain)"),
                ToyotaDtcDefinition("P0300", "Rastgele/Çoklu Silindir Ateşleme Atlaması Saptandı", "Geçici", "Güç Grubu (Powertrain)")
            )
            0x2000 -> listOf(
                ToyotaDtcDefinition("P0741", "Tork Konvertörü Kavraması Solenoid Devresi Performans/Kapalı Kalma", "Kayıtlı", "Transmisyon Kontrol")
            )
            0x3000 -> listOf(
                ToyotaDtcDefinition("C1201", "Motor Kontrol Sistemi Arızası (Hata Sinyali Alındı)", "Aktif", "Fren Kontrol (ABS)")
            )
            0x8000 -> listOf(
                ToyotaDtcDefinition("C1A14", "Ön Radar Sensör Kirli veya Görüşü Engellenmiş", "Aktif", "Kamera/Radar ADAS")
            )
            else -> emptyList()
        }
    }

    private fun getEcuSpecificSpecials(ecuCode: Int): List<ToyotaSpecialFunction> {
        return when (ecuCode) {
            0x1000 -> listOf(
                ToyotaSpecialFunction(101, "Enjektör Kodlama (Compensation Code)", "Yeni enjektörlerin 30 haneli kalibrasyon kodlarını silindir kafasına göre ECU'ya tanımlama.", "31010F"),
                ToyotaSpecialFunction(102, "DPF Rejenerasyonu (DPF Manual Regen)", "Dizel Partikül Filtresinde biriken kurumları yakmak için manuel egzoz ısıtmalı rejen aktivasyonu.", "31011A"),
                ToyotaSpecialFunction(103, "Gaz Kelebeği Öğrenme Sıfırlama (ETCS Reset)", "Gaz kelebeği gövdesi temizlendikten sonra adaptasyon değerlerinin sıfırlanması.", "2F01CA")
            )
            0x2000 -> listOf(
                ToyotaSpecialFunction(104, "CVT Yağ Değişim Ömrü Sıfırlama", "Şanzıman sıvı bozulma katsayısının yeni ATF yağına göre sıfırlanması.", "3101FA"),
                ToyotaSpecialFunction(105, "Vaka Kalibrasyonu (Solenoid Learn)", "Değiştirilen kontrol valfi solenoidleri için debriyaj basma noktalarının öğretilmesi.", "3101FE")
            )
            0x3000 -> listOf(
                ToyotaSpecialFunction(106, "Direksiyon Açı Sensörü Sıfırlama (SAS Reset)", "Direksiyon simidi tam düz konumdayken açısal sıfır noktasının kalibre edilmesi.", "3102A0"),
                ToyotaSpecialFunction(107, "Yalpalama ve G-Sensör Kalibrasyonu", "ABS / ESP beyni içindeki jiroskop yerçekimi sensörlerinin düz zeminde sıfırlanması.", "3102A2")
            )
            else -> listOf(
                ToyotaSpecialFunction(108, "Akıllı Anahtar Tanımlama (IMMO Key Match)", "Kaybolan veya yeni eklenen transponder anahtarın immobilizer modülüyle eşleştirilmesi.", "3103CC")
            )
        }
    }

    private fun createFallbackEcu(ecuCode: Int): ToyotaEcuData {
        val magic = "XDIAG"
        val version = "V49.50"
        val systemName = "General Multiplex System"
        val header = EcuBinaryHeader(magic, version, ecuCode, systemName, 120, 2, 600, 0, 1200, 1)

        return ToyotaEcuData(
            header = header,
            pids = listOf(ToyotaPidDefinition(1, "2101", "Module_V", "Kontrol Voltajı", "V", "Bolt", "A/10", 0f, 16f)),
            dtcs = emptyList(),
            specialFunctions = listOf(ToyotaSpecialFunction(1, "Sistem Sıfırlama", "Modül yazılımsal sıfırlama işlemi", "1101"))
        )
    }
}
