package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import kotlin.coroutines.resume

class BleElm327Manager(private val bleCore: BleConnectionCore) : IOBDConnection {

    override val protocolType = ProtocolType.BLE_ELM327
    override val connectionState = bleCore.connectionState
    
    private val _isConnected = MutableStateFlow(false)
    override val isConnected: StateFlow<Boolean> = _isConnected

    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private val responseBuffer = java.lang.StringBuilder()
    private var pendingCallback: ((String) -> Unit)? = null

    // Bilinen UUID setleri — sırayla dene
    private val knownUuidSets = listOf(
        UuidSet("0000fff0-0000-1000-8000-00805f9b34fb", "0000fff2-0000-1000-8000-00805f9b34fb", "0000fff1-0000-1000-8000-00805f9b34fb"),
        UuidSet("0000ffe0-0000-1000-8000-00805f9b34fb", "0000ffe1-0000-1000-8000-00805f9b34fb", "0000ffe1-0000-1000-8000-00805f9b34fb"),
        UuidSet("6e400001-b5a3-f393-e0a9-e50e24dcca9e", "6e400002-b5a3-f393-e0a9-e50e24dcca9e", "6e400003-b5a3-f393-e0a9-e50e24dcca9e")
    )
    data class UuidSet(val service: String, val write: String, val notify: String)

    override suspend fun connect(): Boolean {
        bleCore.onDataReceived = { uuid, data ->
            if (notifyChar != null && uuid == notifyChar?.uuid.toString()) {
                val chunk = String(data, Charsets.US_ASCII)
                responseBuffer.append(chunk)
                if (chunk.contains(">")) {
                    val full = responseBuffer.toString().replace(">", "").trim()
                    responseBuffer.clear()
                    pendingCallback?.invoke(full)
                    pendingCallback = null
                }
            }
        }

        val services = bleCore.discoveredServices.value
        for (uuidSet in knownUuidSets) {
            val service = services.find { it.uuid.toString() == uuidSet.service }
            if (service != null) {
                writeChar = service.getCharacteristic(UUID.fromString(uuidSet.write))
                notifyChar = service.getCharacteristic(UUID.fromString(uuidSet.notify))
                if (writeChar != null && notifyChar != null) {
                    enableNotify(notifyChar!!)
                    _isConnected.value = true
                    return initElm327Handshake()
                }
            }
        }
        
        // Hiçbiri eşleşmezse: ilk bulunan write+notify çiftini dene
        for (service in services) {
            val w = service.characteristics.find { 
                it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
                it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0
            }
            val n = service.characteristics.find {
                it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0
            }
            if (w != null && n != null) {
                writeChar = w; notifyChar = n
                enableNotify(n)
                _isConnected.value = true
                return initElm327Handshake()
            }
        }
        return false
    }

    @SuppressLint("MissingPermission")
    private fun enableNotify(char: BluetoothGattCharacteristic) {
        bleCore.bluetoothGatt?.setCharacteristicNotification(char, true)
        val descriptor = char.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
        descriptor?.let {
            it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            bleCore.bluetoothGatt?.writeDescriptor(it)
        }
    }

    private suspend fun initElm327Handshake(): Boolean {
        val results = listOf(
            sendRawCommand("ATZ"), sendRawCommand("ATE0"),
            sendRawCommand("ATL0"), sendRawCommand("ATH1"), sendRawCommand("ATSP0")
        )
        return results.none { it == "TIMEOUT" || it.contains("ERROR") }
    }

    override suspend fun sendRawCommand(cmd: String): String = withTimeoutOrNull(5000L) {
        suspendCancellableCoroutine { cont ->
            pendingCallback = { resp -> if (cont.isActive) cont.resume(resp) }
            val char = writeChar ?: run { 
                if (cont.isActive) cont.resume("ERROR: yazma kanalı yok"); return@suspendCancellableCoroutine 
            }
            bleCore.writeChunked(char, "${cmd}\r".toByteArray(Charsets.US_ASCII))
        }
    } ?: "TIMEOUT"

    override fun disconnect() {
        bleCore.disconnect()
        _isConnected.value = false
    }
}
