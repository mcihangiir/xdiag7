package com.example.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class BleTrafficRecorder(private val bleCore: BleConnectionCore) {

    data class TrafficEvent(
        val direction: String,      // "GÖNDERILEN" / "ALINAN"
        val characteristicUuid: String,
        val hexData: String,
        val asciiAttempt: String,
        val timestampMs: Long
    )

    private val _recordedTraffic = MutableStateFlow<List<TrafficEvent>>(emptyList())
    val recordedTraffic: StateFlow<List<TrafficEvent>> = _recordedTraffic
    
    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording

    fun startRecording() {
        _recordedTraffic.value = emptyList()
        _isRecording.value = true
        bleCore.onDataReceived = { uuid, data ->
            if (_isRecording.value) {
                logEvent("ALINAN", uuid, data)
            }
        }
    }

    fun logSentCommand(uuid: String, data: ByteArray) {
        if (_isRecording.value) logEvent("GÖNDERİLEN", uuid, data)
    }

    fun logReceivedResponse(uuid: String, data: ByteArray) {
        if (_isRecording.value) logEvent("ALINAN", uuid, data)
    }

    private fun logEvent(direction: String, uuid: String, data: ByteArray) {
        val hex = data.joinToString(" ") { "%02X".format(it) }
        val ascii = try { 
            String(data, Charsets.US_ASCII).map { if (it in ' '..'~') it else '.' }.joinToString("")
        } catch (e: Exception) { "" }
        
        _recordedTraffic.value = _recordedTraffic.value + TrafficEvent(
            direction, uuid, hex, ascii, System.currentTimeMillis()
        )
    }

    fun stopRecording() { 
        _isRecording.value = false 
    }

    fun exportAsText(): String {
        return _recordedTraffic.value.joinToString("\n") { event ->
            "[${event.timestampMs}] ${event.direction} (${event.characteristicUuid.take(8)}): " +
            "HEX[${event.hexData}] ASCII[${event.asciiAttempt}]"
        }
    }
}
