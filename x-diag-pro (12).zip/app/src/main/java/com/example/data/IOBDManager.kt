package com.example.data

import kotlinx.coroutines.flow.StateFlow

interface IOBDManager {
    val isConnected: StateFlow<Boolean>
    suspend fun sendRawCommand(cmd: String): String
    fun disconnect()
}
