package com.example.data

import android.content.Context
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

object CarNameParser {
    private const val TAG = "CarNameParser"

    fun parse(context: Context, fileSource: File): Map<Int, String> {
        val namesMap = mutableMapOf<Int, String>()
        try {
            if (!fileSource.exists()) return emptyMap()
            val bytes = fileSource.readBytes()
            val buffer = ByteBuffer.wrap(bytes).apply {
                order(ByteOrder.LITTLE_ENDIAN)
            }

            // Header (14 bytes)
            if (buffer.remaining() < 14) return emptyMap()
            val magic = ByteArray(5)
            buffer.get(magic)
            val ver = ByteArray(5)
            buffer.get(ver)
            val recordCount = buffer.int

            Log.d(TAG, "CARNAME.BIN Parser Header - Magic: ${String(magic)}, Records: $recordCount")

            // Read Indices
            val indexList = mutableListOf<Triple<Int, Int, Int>>() // ID, Offset, Length
            for (i in 0 until recordCount) {
                if (buffer.remaining() < 12) break
                val nameId = buffer.int
                val offset = buffer.int
                val length = buffer.int
                indexList.add(Triple(nameId, offset, length))
            }

            // Resolve strings
            for (index in indexList) {
                val (nameId, offset, length) = index
                if (offset + length <= bytes.size) {
                    val stringBytes = ByteArray(length)
                    buffer.position(offset)
                    buffer.get(stringBytes)
                    val value = String(stringBytes, StandardCharsets.UTF_8).trim()
                    namesMap[nameId] = value
                }
            }
            Log.d(TAG, "Successfully parsed ${namesMap.size} system titles from CARNAME.BIN string table")
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing CARNAME.BIN", e)
        }
        return namesMap
    }
}
