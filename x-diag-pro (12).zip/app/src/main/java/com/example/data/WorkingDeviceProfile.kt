package com.example.data

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

data class WorkingDeviceProfile(
    val deviceAddress: String,
    val layer: String,           // "CLASSIC" veya "BLE"
    val workingMethod: String,   // "Standart SPP", "Kanal 7", "BLE fff0/fff2" vb.
    val firstByteResponseHex: String,  // İlk alınan yanıtın ham hex'i
    val timestamp: Long,
    val protocol: String = "UDS_ISO15765",
    val canId: String = "0x7E0",
    val baudRate: Int = 500000,
    val mtu: Int = 8,
    val securityMode: String = "None",
    val transportLayer: String = "ISO-TP"
) {
    companion object {
        private const val PREFS_NAME = "working_device_profiles"
        
        private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        private val adapter = moshi.adapter(WorkingDeviceProfile::class.java)

        fun saveProfile(context: Context, profile: WorkingDeviceProfile) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = adapter.toJson(profile)
            prefs.edit().putString(profile.deviceAddress, json).apply()
            prefs.edit().putString("last_working_address", profile.deviceAddress).apply()
        }

        fun loadProfile(context: Context, address: String): WorkingDeviceProfile? {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val json = prefs.getString(address, null) ?: return null
            return try {
                adapter.fromJson(json)
            } catch (e: Exception) {
                null
            }
        }

        fun loadLastProfile(context: Context): WorkingDeviceProfile? {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val lastAddress = prefs.getString("last_working_address", null) ?: return null
            return loadProfile(context, lastAddress)
        }
    }
}
