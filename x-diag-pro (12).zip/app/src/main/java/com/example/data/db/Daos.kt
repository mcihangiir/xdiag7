package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VehicleBrandDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(brand: VehicleBrand): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(brands: List<VehicleBrand>)

    @Query("SELECT * FROM vehicle_brands ORDER BY sortOrder ASC, name ASC")
    fun getAll(): Flow<List<VehicleBrand>>

    @Query("SELECT * FROM vehicle_brands")
    suspend fun getAllBrandsList(): List<VehicleBrand>

    @Query("SELECT * FROM vehicle_brands WHERE id = :id")
    suspend fun getById(id: Int): VehicleBrand?

    @Query("SELECT * FROM vehicle_brands WHERE region = :region ORDER BY sortOrder ASC, name ASC")
    fun getByRegion(region: String): Flow<List<VehicleBrand>>

    @Query("SELECT * FROM vehicle_brands WHERE name LIKE :query OR nameLocal LIKE :query")
    fun search(query: String): Flow<List<VehicleBrand>>

    @Query("SELECT * FROM vehicle_brands WHERE name = :name LIMIT 1")
    suspend fun getByName(name: String): VehicleBrand?

    @Query("UPDATE vehicle_brands SET isDownloaded = :isDownloaded WHERE name = :name")
    suspend fun updateDownloadStatusByName(name: String, isDownloaded: Boolean)

    @Query("UPDATE vehicle_brands SET isDownloaded = :isDownloaded WHERE name IN (:names)")
    suspend fun updateDownloadStatusByNames(names: List<String>, isDownloaded: Boolean)
}

@Dao
interface VehicleModelDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(model: VehicleModel): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(models: List<VehicleModel>)

    @Query("SELECT * FROM vehicle_models ORDER BY name ASC")
    fun getAll(): Flow<List<VehicleModel>>

    @Query("SELECT * FROM vehicle_models WHERE id = :id")
    suspend fun getById(id: Int): VehicleModel?

    @Query("SELECT * FROM vehicle_models WHERE brandId = :brandId")
    fun getByBrandId(brandId: Int): Flow<List<VehicleModel>>

    @Query("SELECT * FROM vehicle_models WHERE brandId = :brandId")
    suspend fun getModelsByBrandId(brandId: Int): List<VehicleModel>

    @Query("SELECT * FROM vehicle_models WHERE name LIKE :query OR nameLocal LIKE :query")
    fun search(query: String): Flow<List<VehicleModel>>

    @Query("SELECT * FROM vehicle_models WHERE vin = :vin LIMIT 1")
    suspend fun getByVin(vin: String): VehicleModel?
}

@Dao
interface EcuSystemDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(system: EcuSystem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(systems: List<EcuSystem>)

    @Query("SELECT * FROM ecu_systems")
    fun getAll(): Flow<List<EcuSystem>>

    @Query("SELECT * FROM ecu_systems WHERE id = :id")
    suspend fun getById(id: Int): EcuSystem?

    @Query("SELECT * FROM ecu_systems WHERE modelId = :modelId")
    fun getByModelId(modelId: Int): Flow<List<EcuSystem>>

    @Query("SELECT * FROM ecu_systems WHERE systemCode LIKE :query OR systemName LIKE :query")
    fun search(query: String): Flow<List<EcuSystem>>
}

@Dao
interface TroubleCodeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(code: TroubleCode): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(codes: List<TroubleCode>)

    @Query("SELECT * FROM trouble_codes")
    fun getAll(): Flow<List<TroubleCode>>

    @Query("SELECT * FROM trouble_codes WHERE id = :id")
    suspend fun getById(id: Int): TroubleCode?

    @Query("SELECT * FROM trouble_codes WHERE systemId = :systemId")
    fun getBySystemId(systemId: Int): Flow<List<TroubleCode>>

    @Query("SELECT * FROM trouble_codes WHERE code = :code LIMIT 1")
    suspend fun getByCode(code: String): TroubleCode?

    @Query("SELECT * FROM trouble_codes WHERE code LIKE :query OR descriptionTr LIKE :query OR descriptionEn LIKE :query")
    fun search(query: String): Flow<List<TroubleCode>>
}

@Dao
interface LivePidDefinitionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(pid: LivePidDefinition): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(pids: List<LivePidDefinition>)

    @Query("SELECT * FROM live_pid_definitions")
    fun getAll(): Flow<List<LivePidDefinition>>

    @Query("SELECT * FROM live_pid_definitions WHERE id = :id")
    suspend fun getById(id: Int): LivePidDefinition?

    @Query("SELECT * FROM live_pid_definitions WHERE brandId = :brandId OR brandId IS NULL")
    fun getByBrandId(brandId: Int): Flow<List<LivePidDefinition>>

    @Query("SELECT * FROM live_pid_definitions WHERE isDefault = 1")
    fun getDefaultPids(): Flow<List<LivePidDefinition>>

    @Query("SELECT * FROM live_pid_definitions WHERE name LIKE :query OR nameEn LIKE :query OR pid LIKE :query")
    fun search(query: String): Flow<List<LivePidDefinition>>
}

@Dao
interface SpecialFunctionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(function: SpecialFunction): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(functions: List<SpecialFunction>)

    @Query("SELECT * FROM special_functions")
    fun getAll(): Flow<List<SpecialFunction>>

    @Query("SELECT * FROM special_functions WHERE id = :id")
    suspend fun getById(id: Int): SpecialFunction?

    @Query("SELECT * FROM special_functions WHERE brandId = :brandId OR brandId IS NULL")
    fun getByBrandId(brandId: Int): Flow<List<SpecialFunction>>

    @Query("SELECT * FROM special_functions WHERE functionName LIKE :query OR functionCode LIKE :query")
    fun search(query: String): Flow<List<SpecialFunction>>
}
