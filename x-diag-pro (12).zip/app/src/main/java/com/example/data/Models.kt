package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

// Diagnostic Trouble Code Representation
data class TroubleCode(
    val code: String,
    val description: String,
    val moduleName: String,
    val status: String, // e.g., "Active", "Pending", "History"
    val severity: String, // e.g., "Critical", "Warning", "Information"
    val helpText: String // Mechanic advice / troubleshooting suggestion
) : Serializable

// Electronic Control Unit Systems scanned (e.g. ECM, TCM, airbag etc.)
data class VehicleSystem(
    val id: String,
    val name: String,
    val abbreviation: String,
    val state: SystemScanState = SystemScanState.PENDING,
    val errorCount: Int = 0,
    val troubleCodes: List<TroubleCode> = emptyList()
) : Serializable

enum class SystemScanState {
    PENDING,
    SCANNING,
    COMPLETED,
    FAILED
}

// Vehicle Meta Info
data class VehicleInfo(
    val vin: String,
    val make: String,
    val model: String,
    val year: Int,
    val mileage: Int,
    val systems: List<VehicleSystem> = emptyList(),
    val commercialName: String? = null,
    val type: String? = null,
    val registrationDate: String? = null,
    val color: String? = null,
    val engineNumber: String? = null,
    val registrationSequenceNo: String? = null
) : Serializable

data class LivePid(
    val name: String,
    val value: String,
    val unit: String
)

data class ObdPidDefinition(
    val pid: String,
    val name: String,
    val unit: String,
    val icon: String,
    val parseFormula: String,
    val isSelected: Boolean = false,
    val minValue: Float = 0f,
    val maxValue: Float = 8000f
) : java.io.Serializable

data class FreezeFrameData(
    val frameNumber: Int,
    val triggerDtc: String,
    val rpm: Int,
    val speed: Int,
    val coolantTemp: Int,
    val engineLoad: Float,
    val fuelTrim: Float,
    val intakeTemp: Int,
    val throttlePos: Float,
    val mapPressure: Int = 101,
    val mafFlow: Float = 12.5f,
    val o2Voltage: Float = 0.45f,
    val timestamp: Long
) : java.io.Serializable

// TPMS Models
data class TireData(
    val position: TirePosition,
    val pressureKpa: Float,
    val pressurePsi: Float,
    val tempCelsius: Int,
    val sensorId: String,
    val batteryOk: Boolean,
    val status: TireStatus
) : java.io.Serializable

enum class TirePosition { FRONT_LEFT, FRONT_RIGHT, REAR_LEFT, REAR_RIGHT }
enum class TireStatus { NORMAL, LOW, HIGH, FLAT, NO_SIGNAL, SENSOR_FAULT }

// Room database entity for local persistence of professional diagnostic reports
@Entity(tableName = "diagnostic_reports")
data class DiagnosticReport(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val clientName: String = "Self-Service",
    val vehicleVin: String,
    val vehicleName: String,
    val vehicleYear: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val okCount: Int,
    val errorCount: Int,
    val healthPercentage: Int,
    val troubleCodesJson: String, // Moshi/JSON-serialized list of all DTCs detected
    val systemsJson: String, // Moshi/JSON-serialized summary of systems scanned
    val technicianNotes: String = "",
    val signatureBase64: String = "",
    val isSigned: Boolean = false,
    val technicianName: String = "",
    val scanType: String = "QUICK",
    val diagSoftVersion: String = "1.0",
    val vehicleSoftVersion: String = ""
) : Serializable

data class ImMonitor(
  val id: String,
  val name: String,
  val nameTr: String,
  val status: ImMonitorStatus,
  val isSupported: Boolean
) : Serializable

enum class ImMonitorStatus {
  COMPLETE,       // ✅ Hazır - yeşil
  INCOMPLETE,     // ⏳ Tamamlanmadı - sarı
  NOT_SUPPORTED   // ➖ Desteklenmiyor - gri
}

data class ImReadinessResult(
  val monitors: List<ImMonitor>,
  val readyCount: Int,
  val incompleteCount: Int,
  val unsupportedCount: Int,
  val mil: Boolean,         // MIL (Motor Arıza Lambası) açık mı?
  val dtcCount: Int,        // Aktif DTC sayısı
  val timestamp: Long
) : Serializable

data class OBDMonitorTest(
  val testId: String,          // "06 01", "06 02" gibi
  val componentId: String,     // "TID/CID hex"
  val description: String,     // Türkçe
  val actualValue: Float,
  val minLimit: Float,
  val maxLimit: Float,
  val unit: String,
  val result: TestResult,
  val module: String           // "Katalitik", "O2 Sensörü" vb.
) : Serializable

enum class TestResult { PASSED, FAILED, NO_RESULT }

data class Mode06Snapshot(
  val tests: List<OBDMonitorTest>,
  val timestamp: Long,
  val label: String            // "Tarama 1", "Tarama 2"
) : Serializable

data class PidSnapshot(
  val timestampMs: Long,
  val values: Map<String, Float>  // PID adı → değer
) : Serializable

@Entity(tableName = "data_recordings")
data class DataRecording(
  @PrimaryKey(autoGenerate = true) val id: Int = 0,
  val label: String,              // "Kayıt 1 — 18 Haz 2025"
  val vehicleName: String,
  val durationSeconds: Int,
  val sampleCount: Int,
  val snapshotsJson: String,      // Moshi ile serialize
  val pidNamesJson: String,       // Hangi PID'ler kaydedildi
  val timestamp: Long
) : Serializable

data class VoltageTestResult(
  val restingVoltage: Float,       // Dinlenim voltajı
  val crankingVoltage: Float,      // Marş voltajı (en düşük)
  val chargingVoltage: Float,      // Şarj voltajı (motor çalışırken)
  val voltageHistory: List<Float>, // Son 60 saniye
  val batteryHealth: BatteryHealth,
  val alternatorStatus: AlternatorStatus,
  val timestamp: Long
) : Serializable

enum class BatteryHealth {
  EXCELLENT,  // > 12.6V → "Mükemmel"
  GOOD,       // 12.4-12.6V → "İyi"
  FAIR,       // 12.2-12.4V → "Orta"
  WEAK,       // 12.0-12.2V → "Zayıf"
  CRITICAL    // < 12.0V → "Kritik - Değiştirin"
}

enum class AlternatorStatus {
  GOOD,       // 13.8-14.8V → "Normal Şarj"
  OVERCHARGE, // > 14.8V → "Aşırı Şarj - Kontrol Et"
  UNDERCHARGE,// 12.8-13.8V → "Yetersiz Şarj"
  FAILED      // < 12.8V → "Alternatör Arıza"
}


