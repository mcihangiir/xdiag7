package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "vehicle_brands")
data class VehicleBrand(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val nameLocal: String,
    val region: String, // EUROPE, ASIA, AMERICA, CHINA
    val logoUrl: String? = null,
    val isPopular: Boolean = false,
    val sortOrder: Int = 0,
    val isDownloaded: Boolean = false,
    val regionalVariant: String? = null,
    val aliasNames: String = "[]"
) : Serializable
