package com.example.data

import kotlinx.coroutines.flow.Flow

class ReportRepository(private val reportDao: ReportDao) {
    val allReports: Flow<List<DiagnosticReport>> = reportDao.getAllReports()

    suspend fun getReportById(id: Int): DiagnosticReport? {
        return reportDao.getReportById(id)
    }

    suspend fun insertReport(report: DiagnosticReport): Long {
        return reportDao.insertReport(report)
    }

    suspend fun updateSignature(reportId: Int, signature: String) {
        reportDao.updateSignature(reportId, signature)
    }

    suspend fun deleteReport(report: DiagnosticReport) {
        reportDao.deleteReport(report)
    }

    suspend fun clearAll() {
        reportDao.deleteAllReports()
    }
}
