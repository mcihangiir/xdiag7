package com.example.data.db

import androidx.room.*
import java.io.Serializable

@Entity(
    tableName = "vehicle_models",
    foreignKeys = [
        ForeignKey(
            entity = VehicleBrand::class,
            parentColumns = ["id"],
            childColumns = ["brandId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["brandId"])]
)
data class VehicleModel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val brandId: Int,
    val name: String,
    val nameLocal: String,
    val yearStart: Int,
    val yearEnd: Int? = null,
    val engineCodes: String, // JSON array string
    val bodyTypes: String, // JSON array string
    val vin: String? = null,
    val registrationDate: String? = null,
    val color: String? = null,
    val engineNumber: String? = null,
    val type: String? = null,
    val generation: String? = null,
    val ecuType: String? = null
) : Serializable
