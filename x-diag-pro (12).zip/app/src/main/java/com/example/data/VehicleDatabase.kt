package com.example.data

object VehicleDatabase {
    val SIMULATED_VEHICLES = listOf(
        VehicleInfo(
            vin = "WBAJU71000G823101",
            make = "BMW",
            model = "M5 Competition (F90)",
            year = 2021,
            mileage = 42500,
            commercialName = "BMW M5",
            type = "F90 (M5)",
            registrationDate = "15/04/2021",
            color = "Metalik Gri (Marina Bay)",
            engineNumber = "S63B44B0817294",
            registrationSequenceNo = "20210415110294817253",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "DME - Dijital Motor Elektroniği Motor Kontrol Ünitesi", abbreviation = "ECM",
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "113026",
                            description = "Ateşleme, silindir 3: yanma kaçırma tespit edildi.",
                            moduleName = "DME Motor Kontrolü",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Yanma kaçırmaları katalitik konvertöre zarar verebilir. Buji aralığını, ateşleme bobini direncini veya silindir 3'teki yakıt enjektörü darbe genişliğini kontrol edin."
                        ),
                        TroubleCode(
                            code = "101F01",
                            description = "Gaz kelebeği valf açısı - basınç korelasyon limiti aşıldı.",
                            moduleName = "DME Motor Kontrolü",
                            status = "Beklemede",
                            severity = "Uyarı",
                            helpText = "Gaz kelebeği gövdesi tertibatını temizleyin ve adaptasyon değerlerini sıfırlayın. Hava akış sensörü sonrasındaki emme yolu vakum sızıntılarını kontrol edin."
                        )
                    )
                ),
                VehicleSystem(
                    id = "tc_u", name = "EGS - Elektronik Şanzıman Kontrol Modülü", abbreviation = "TCM",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "abs", name = "DSC - Dinamik Stabilite Kontrolü Kilitlenme Karşıtı Fren Sistemi", abbreviation = "ABS",
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "480A12",
                            description = "DSC Tekerlek Hız Sensörü: Ön sol, sinyal kablosu açık devre.",
                            moduleName = "DSC Stabilite Kontrolü",
                            status = "Aktif",
                            severity = "Uyarı",
                            helpText = "Ön sol tekerlek yuvasındaki konnektör pinlerini inceleyin. Sensör direncini ölçün (normalde 0.8-1.5 kΩ). Değerler sonsuz ise ABS tekerlek hız sensörünü değiştirin."
                        )
                    )
                ),
                VehicleSystem(
                    id = "srs", name = "ACSM - Gelişmiş Çarpışma Güvenliği Modülü (Hava Yastığı)", abbreviation = "SRS",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "bcm", name = "BDC - Gövde Alan Denetleyici Elektroniği", abbreviation = "BCM",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "ihka", name = "IHKA - Entegre Otomatik Isıtma / Klima", abbreviation = "HVAC",
                    troubleCodes = emptyList()
                )
            )
        ),
        VehicleInfo(
            vin = "WDD2130041A928412",
            make = "Mercedes-Benz",
            model = "E-Class 300 4MATIC (W213)",
            year = 2020,
            mileage = 58200,
            commercialName = "Mercedes-Benz E300",
            type = "W213 (E-Class)",
            registrationDate = "11/11/2020",
            color = "Siyah (Obsidian)",
            engineNumber = "M2649200384712",
            registrationSequenceNo = "20201111140928412839",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "ME - Motor Elektroniği Motor Kontrol Modülü", abbreviation = "ECM",
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "P017100",
                            description = "Silindir sırası 1'deki karışım çok fakir.",
                            moduleName = "ME Motor Kontrolü",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Sisteme ölçülmemiş hava giriyor. PCV valfi diyaframını, emme manifoldu contalarını veya yakıt pompası basıncını kontrol edin (hedef: 3.5 - 4.2 bar)."
                        )
                    )
                ),
                VehicleSystem(
                    id = "tc_u", name = "VGS - Elektronik Şanzıman Kontrolü (9G-TRONIC)", abbreviation = "TCM",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "abs", name = "ESP - Elektronik Stabilite Programı Fren Kontrolü", abbreviation = "ABS",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "srs", name = "ORC - Yolcu Koruma Sistemi Kontrolü", abbreviation = "SRS",
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "B0001-13",
                            description = "Sürücü Hava Yastığı Kapsülü 1: Açık Devre.",
                            moduleName = "ORC Hava Yastığı Kontrolörü",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Genellikle kırık bir direksiyon sargısından (zemberek) kaynaklanır. Sürücü hava yastığı devresinin direncini ölçün (normalde 2.2Ω). Multimetreyi doğrudan patlayıcı modül üzerinde kullanmayın!"
                        )
                    )
                ),
                VehicleSystem(
                    id = "bcm", name = "SAM - Sinyal Alım ve Kontrol Modülü (Ön)", abbreviation = "SAM",
                    troubleCodes = emptyList()
                )
            )
        ),
        VehicleInfo(
            vin = "SB1KT31E30E039202",
            make = "Toyota",
            model = "Auris 1.33 Dual VVT-i",
            year = 2016,
            mileage = 84500,
            commercialName = "Toyota Auris",
            type = "E15UT(A)",
            registrationDate = "22/08/2015",
            color = "Mavi (Denim)",
            engineNumber = "1NR0890275",
            registrationSequenceNo = "2025082215041996748",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "EFI - Elektronik Yakıt Enjeksiyon Sistemi (Motor)", abbreviation = "ECM",
                    errorCount = 2,
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "P1601",
                            description = "Enjektör Sınıflandırma Kodu Hatası / Kayıt Eksik veya Yanlış.",
                            moduleName = "EFI Motor Kontrolü",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "X-DIAG Pro Enjektör Kodlama fonksiyonunu kullanarak enjektör gövdesi üzerindeki 30 haneli kompanzasyon kodunu ECU beynine yeniden programlayın."
                        ),
                        TroubleCode(
                            code = "P0201",
                            description = "Silindir 1 Enjektör Devresi Açık Devre.",
                            moduleName = "EFI Motor Kontrolü",
                            status = "Beklemede",
                            severity = "Uyarı",
                            helpText = "Silindir 1 enjektör soketini, pin korozyonunu ve kablo tesisatını inceleyin. Bobin direncini ölçün (hedef: 11.6 - 12.4 Ω)."
                        )
                    )
                ),
                VehicleSystem(
                    id = "abs", name = "ABS/VSC - Kilitlenme Karşıtı Fren / Araç Denge Kontrolü", abbreviation = "ABS",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "srs", name = "SRS - Hava Yastığı Koruma Sistemi", abbreviation = "SRS",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "emps", name = "EMPS - Elektrik Destekli Hidrolik Direksiyon Sistemi", abbreviation = "EMPS",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "ac", name = "A/C - Entegre Klima ve Isıtma İklim Kontrolü", abbreviation = "HVAC",
                    troubleCodes = emptyList()
                )
            )
        ),
        VehicleInfo(
            vin = "JTDKN3DU4F0123594",
            make = "Toyota",
            model = "Prius Hybrid Gen 4",
            year = 2018,
            mileage = 95300,
            commercialName = "Toyota Prius",
            type = "XW50 (Prius)",
            registrationDate = "09/01/2018",
            color = "Beyaz (Sedefli)",
            engineNumber = "2ZR-FXE0283912",
            registrationSequenceNo = "20180109150392817283",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "EFI - Elektronik Yakıt Enjeksiyon Sistemi (Motor)", abbreviation = "ECM",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "hvb", name = "HV - Hibrit Araç Kontrolü ECU ve Akü Sistemi", abbreviation = "HV-BAT",
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "P0A80",
                            description = "Hibrit Akü Paketini Değiştirin.",
                            moduleName = "HV Akü Kontrolörü",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Dahili bloklar arasındaki voltaj farkı 0.3V'u aşıyor. Hücre blok voltajlarını kontrol edin, akü fan kanallarını temizleyin ve hibrit invertör soğutma sıvısı pompası çalışmasını kontrol edin."
                        )
                    )
                ),
                VehicleSystem(
                    id = "abs", name = "ABS/VSC - Kilitlenme Karşıtı Fren / Araç Denge Kontrolü", abbreviation = "ABS",
                    troubleCodes = emptyList()
                )
            )
        ),
        VehicleInfo(
            vin = "WVWZZZAUZJP082914",
            make = "Volkswagen",
            model = "Golf R Mk7.5",
            year = 2019,
            mileage = 37900,
            commercialName = "Volkswagen Golf",
            type = "AU (Golf R)",
            registrationDate = "20/06/2019",
            color = "Yarış Mavisi (Lapiz)",
            engineNumber = "DJHA082914",
            registrationSequenceNo = "20190620130924182930",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "01 - Motor Kontrol Modülü (EA888 Gen 3)", abbreviation = "ECM",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "tc_u", name = "02 - Şanzıman Kontrol Modülü (DQ381 DSG)", abbreviation = "TCM",
                    troubleCodes = emptyList()
                ),
                VehicleSystem(
                    id = "hal", name = "22 - AWD Haldex Kavrama Kontrol Ünitesi", abbreviation = "4WD",
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "C111F07",
                            description = "Haldex debriyaj pompası: Mekanik arıza.",
                            moduleName = "Haldex Kavrama Kontrolü",
                            status = "Aktif",
                            severity = "Uyarı",
                            helpText = "Haldex yağ pompasındaki tıkalı ön filtre süzgecini simüle eder. Çok plakalı kavrama yağ filtresi süzgecini temizleyin, havayı tahliye edin ve pompa adaptasyon testini gerçekleştirin."
                        )
                    )
                ),
                VehicleSystem(
                    id = "abs", name = "03 - Frenler ABS Stabilite Sistemi", abbreviation = "ABS",
                    troubleCodes = emptyList()
                )
            )
        ),
        VehicleInfo(
            vin = "NMTBA3BE50R123456",
            make = "Toyota",
            model = "Corolla 1.6 Valvematic",
            year = 2020,
            mileage = 65000,
            commercialName = "Toyota Corolla",
            type = "E210 (Corolla)",
            registrationDate = "22/02/2020",
            color = "Beyaz (Sedefli)",
            engineNumber = "1ZR0981724",
            registrationSequenceNo = "20200222110294827163",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "EFI - Elektronik Yakıt Enjeksiyon Sistemi", abbreviation = "ECM",
                    errorCount = 2,
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "P0171",
                            description = "Sistem Karışımı Çok Fakir (Bank 1)",
                            moduleName = "EFI Motor Kontrolü",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Manifold hava kaçaklarını kontrol edin, MAF sensörünü temizleyin ve yakıt basıncını ölçün."
                        ),
                        TroubleCode(
                            code = "P0420",
                            description = "Katalitik Dönüştürücü Sistemi Verimliliği Eşik Değerin Altında (Bank 1)",
                            moduleName = "EFI Motor Kontrolü",
                            status = "Beklemede",
                            severity = "Uyarı",
                            helpText = "Egzoz kaçaklarını araştırın. Arka oksijen sensörü (B1S2) voltaj dalgalanmalarını izleyin."
                        )
                    )
                ),
                VehicleSystem(id = "tc_u", name = "CVT - Sürekli Değişken Şanzıman Kontrolü", abbreviation = "TCM"),
                VehicleSystem(id = "abs", name = "ABS/VSC - Dinamik Stabilite Kontrolü", abbreviation = "ABS"),
                VehicleSystem(id = "srs", name = "SRS - Hava Yastığı Emniyet Modülü", abbreviation = "SRS"),
                VehicleSystem(id = "bcm", name = "BCM - Gövde Kontrol Modülü", abbreviation = "BCM")
            )
        ),
        VehicleInfo(
            vin = "WVWZZZAUZMW100001",
            make = "Volkswagen",
            model = "Golf 8 GTI 2.0 TSI",
            year = 2022,
            mileage = 29000,
            commercialName = "Volkswagen Golf",
            type = "Golf Mk8 (GTI)",
            registrationDate = "10/05/2022",
            color = "Kırmızı (Tornado)",
            engineNumber = "EA88821948",
            registrationSequenceNo = "20220510100918471253",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "01 - Motor Kontrol Modülü (DKZA EA888)", abbreviation = "ECM",
                    errorCount = 2,
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "P0299",
                            description = "Turbo/Süperşarj Düşük Takviye (Underboost)",
                            moduleName = "Motor Kontrol Grubu",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Turbo şarj emme hattındaki hortum çatlaklarını ve wastegate aktüatör mekanizmasını kontrol edin."
                        ),
                        TroubleCode(
                            code = "P0087",
                            description = "Yakıt Rayı / Sistem Basıncı - Çok Düşük",
                            moduleName = "Motor Kontrol Grubu",
                            status = "Beklemede",
                            severity = "Kritik",
                            helpText = "Yüksek basınçlı yakıt pompasının (HPFP) ve yakıt ray hattındaki basınç sensörünün doğruluğunu kontrol edin."
                        )
                    )
                ),
                VehicleSystem(id = "tc_u", name = "02 - DQ381 DSG Şanzıman Kontrolü", abbreviation = "TCM"),
                VehicleSystem(id = "abs", name = "03 - Kilitlenme Karşıtı Fren Sistemi (ESP)", abbreviation = "ABS"),
                VehicleSystem(id = "srs", name = "15 - Hava Yastığı Pasif Güvenlik Modülü", abbreviation = "SRS"),
                VehicleSystem(id = "bcm", name = "09 - Karosseriesteuergerät Gövde Elektroniği", abbreviation = "BCM")
            )
        ),
        VehicleInfo(
            vin = "WBA5R1C03LFH12345",
            make = "BMW",
            model = "320i Sedan (G20 Edition)",
            year = 2021,
            mileage = 45000,
            commercialName = "BMW 3 Serisi",
            type = "G20 (3 Serisi)",
            registrationDate = "19/08/2021",
            color = "Metalik Mavi (Portimao)",
            engineNumber = "B48B20812739",
            registrationSequenceNo = "2021081912083917462",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "DME - Dijital Motor Elektroniği", abbreviation = "ECM",
                    errorCount = 2,
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "29CD",
                            description = "DME: Kütlesel Hava Akış Sensörü - sinyal geçerli aralığın dışında",
                            moduleName = "DME Motor Kontrolör",
                            status = "Aktif",
                            severity = "Uyarı",
                            helpText = "MAF sensörünü hava sızıntıları açısından inceleyin ve alkol bazlı sprey yardımıyla kirlerden arındırın."
                        ),
                        TroubleCode(
                            code = "2A67",
                            description = "DME: VANOS eksantrik kapama valfı, pozisyon sapması",
                            moduleName = "DME Motor Kontrolör",
                            status = "Beklemede",
                            severity = "Kritik",
                            helpText = "VANOS solenoid valflerini temizleyin, direnç ve voltaj besleme hatlarını ölçün."
                        )
                    )
                ),
                VehicleSystem(id = "tc_u", name = "EGS - Elektronik Otomatik Şanzıman Kontrolü", abbreviation = "TCM"),
                VehicleSystem(
                    id = "abs", name = "DSC - Dinamik Denge Kontrol Sistemi (ABS)", abbreviation = "ABS",
                    errorCount = 1,
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "480A",
                            description = "DSC: Ön sol ABS tekerlek hız sensörü sinyal hattı kopuk",
                            moduleName = "DSC Fren Denetleyicisi",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Ön sol tekerlek yuvasındaki ABS kablo tesisatını ve konnektörü kontrol edin, korozyon varsa temizleyin."
                        )
                    )
                ),
                VehicleSystem(id = "srs", name = "ACSM - Gelişmiş Çarpışma Emniyeti (SRS)", abbreviation = "SRS"),
                VehicleSystem(id = "bcm", name = "BDC - Gövde Alan Elektronik Kontrolörü", abbreviation = "BCM")
            )
        ),
        VehicleInfo(
            vin = "WF0TXXGAHT1234567",
            make = "Ford",
            model = "Focus 1.5 EcoBoost Active",
            year = 2019,
            mileage = 82000,
            commercialName = "Ford Focus",
            type = "Focus IV (C519)",
            registrationDate = "05/10/2019",
            color = "Krom Mavi",
            engineNumber = "FOX15928173",
            registrationSequenceNo = "20191005120893172839",
            systems = listOf(
                VehicleSystem(
                    id = "ecm", name = "PCM - Güç Aktarım Organı Kontrol Modülü", abbreviation = "ECM",
                    errorCount = 2,
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "P0316",
                            description = "Motor Çalışmaya Başlarken İlk Krank Anında Misfire / Ateşleme Kaçırma",
                            moduleName = "PCM Motor Güç Grubu",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "Soğuk ilk çalıştırma performansını değerlendirin. Bobin ve buji durumlarını kontrolden geçirin."
                        ),
                        TroubleCode(
                            code = "P0191",
                            description = "Yakıt Rayı Basınç Sensörü Devre Performans Hatası",
                            moduleName = "PCM Motor Güç Grubu",
                            status = "Beklemede",
                            severity = "Kritik",
                            helpText = "Yakıt rayı basınç sensörü soketini kontrol edin, düşük basınç pompası beslemesini doğrulayın."
                        )
                    )
                ),
                VehicleSystem(id = "tc_u", name = "TCM - Şanzıman Elektronik Kontrolörü", abbreviation = "TCM"),
                VehicleSystem(id = "abs", name = "ABS - Kilitleme Karşıtı Fren Bilgisayarı", abbreviation = "ABS"),
                VehicleSystem(id = "srs", name = "SRS - Pasif Güvenlik Hava Yastığı Bloku", abbreviation = "SRS"),
                VehicleSystem(id = "bcm", name = "BCM - Gövde Kontrol Birimi", abbreviation = "BCM")
            )
        ),
        VehicleInfo(
            vin = "TMAJ381AAME123456",
            make = "Hyundai",
            model = "Tucson 1.6 T-GDI Comfort",
            year = 2021,
            mileage = 48000,
            commercialName = "Hyundai Tucson",
            type = "NX4 (Tucson)",
            registrationDate = "11/04/2021",
            color = "Kurşun Gri",
            engineNumber = "G4TGD812739",
            registrationSequenceNo = "20210411130928127389",
            systems = listOf(
                VehicleSystem(id = "ecm", name = "ECM - Motor Kontrol Ünitesi", abbreviation = "ECM"),
                VehicleSystem(id = "tc_u", name = "DCT - Çift Kavramalı Şanzıman Kontrol Sistemi", abbreviation = "TCM"),
                VehicleSystem(
                    id = "abs", name = "ABS/ESC - Elektronik Stabilite ve Fren Yönetimi", abbreviation = "ABS",
                    errorCount = 1,
                    troubleCodes = listOf(
                        TroubleCode(
                            code = "C1201",
                            description = "ABS Valf Rölesi Solenoid Devresi Hatası",
                            moduleName = "ABS/ESC Denge Fren Beyni",
                            status = "Aktif",
                            severity = "Kritik",
                            helpText = "ABS sigorta kutusunu, valf motor röle soketini ve besleme hattı voltajını kontrol edin."
                        )
                    )
                ),
                VehicleSystem(id = "srs", name = "SRS - Yardımcı Emniyet Sistemi (Airbag)", abbreviation = "SRS"),
                VehicleSystem(id = "bcm", name = "BCM - Gövde Elektronik Donanımı", abbreviation = "BCM")
            )
        )
    )

    // Fallback default vehicle for other OBD connections
    val DEFAULT_VEHICLE = VehicleInfo(
        vin = "1M8GDM9A0KP841209",
        make = "Genel",
        model = "OBDII Uyumlu Araç",
        year = 2016,
        mileage = 112000,
        commercialName = "Genel Uyumlu Araç",
        type = "OBDII Standardı",
        registrationDate = "10/10/2016",
        color = "Bilinmeyen Renk",
        engineNumber = "GENEL09283182",
        registrationSequenceNo = "201610101509201928",
        systems = listOf(
            VehicleSystem(
                id = "ecm", name = "Güç Aktarım Organı Motor Kontrol Ünitesi (PCM)", abbreviation = "ECM",
                troubleCodes = listOf(
                    TroubleCode(
                        code = "P0420",
                        description = "Katalizör Sistemi Verimliliği Eşik Değerin Altında (Sıra 1).",
                        moduleName = "PCM Güç Aktarım Sistemi",
                        status = "Aktif",
                        severity = "Uyarı",
                        helpText = "Katalitik konvertör çalışma sıcaklığını doğrulayın (normalde arka O2 sensörü, katalizör arızalandığında ön sensör dalgalanmalarıyla eşleşir). O2 sensörü öncesindeki egzoz sızıntılarını kontrol edin."
                    )
                )
            ),
            VehicleSystem(
                id = "abs", name = "Şasi ABS Fren Denetleyicisi", abbreviation = "ABS",
                troubleCodes = emptyList()
            )
        )
    )
}
