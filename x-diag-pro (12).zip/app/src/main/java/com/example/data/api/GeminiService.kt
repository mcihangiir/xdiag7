package com.example.data.api

import android.content.Context
import com.example.data.TroubleCode
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import com.example.BuildConfig

class GeminiService {

    companion object {
        private const val BASE_URL = "https://generativelanguage.googleapis.com/"
        private const val MODEL = "gemini-3.5-flash"
    }

    @JsonClass(generateAdapter = true)
    data class GeminiRequest(
        val contents: List<Content>
    )

    @JsonClass(generateAdapter = true)
    data class Content(
        val parts: List<Part>
    )

    @JsonClass(generateAdapter = true)
    data class Part(
        val text: String
    )

    @JsonClass(generateAdapter = true)
    data class GeminiResponse(
        val candidates: List<Candidate>?
    )

    @JsonClass(generateAdapter = true)
    data class Candidate(
        val content: Content?
    )

    suspend fun analyzeWithPrompt(
        apiKey: String,
        prompt: String,
        history: List<Content> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val contentsList = mutableListOf<Content>()
        contentsList.addAll(history)
        contentsList.add(Content(parts = listOf(Part(text = prompt))))

        val request = GeminiRequest(contents = contentsList)

        val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
        val adapter = moshi.adapter(GeminiRequest::class.java)
        val json = adapter.toJson(request)

        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        val body = json.toRequestBody("application/json".toMediaType())
        val httpRequest = Request.Builder()
            .url("${BASE_URL}v1beta/models/${MODEL}:generateContent?key=${apiKey}")
            .post(body)
            .build()

        try {
            client.newCall(httpRequest).execute().use { response ->
                val responseBody = response.body?.string()
                if (!response.isSuccessful || responseBody == null) {
                    return@withContext "AI yanıt vermedi veya hata oluştu (HTTP ${response.code})"
                }
                val respAdapter = moshi.adapter(GeminiResponse::class.java)
                val geminiResp = respAdapter.fromJson(responseBody)
                geminiResp?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Analiz yapılamadı"
            }
        } catch (e: Exception) {
            "Hata: ${e.message}"
        }
    }

    suspend fun analyzeVehicleFaults(
        apiKey: String,
        vehicleMake: String,
        vehicleModel: String,
        vehicleYear: Int,
        activeDtcs: List<TroubleCode>,
        liveDataSnapshot: Map<String, String>
    ): String {
        val dtcList = activeDtcs.joinToString("\n") {
            "• ${it.code}: ${it.description} (${it.severity})"
        }
        val liveDataStr = liveDataSnapshot.entries.joinToString("\n") {
            "• ${it.key}: ${it.value}"
        }

        val prompt = """
        Sen uzman bir araç teşhis mühendisisin. 
        Aşağıdaki araç bilgilerine dayanarak kapsamlı bir analiz yap.
        
        ARAÇ: $vehicleYear $vehicleMake $vehicleModel
        
        AKTİF HATA KODLARI:
        $dtcList
        
        ANLIK CANLI VERİ:
        $liveDataStr
        
        Lütfen şunları ver (Türkçe olarak):
        
        1. GENEL DEĞERLENDİRME (2-3 cümle)
        2. EN KRİTİK SORUN (başlık + açıklama)
        3. OLASI NEDENLER (madde madde, olasılık sırasıyla)
        4. ÖNERİLEN TAMİR SIRASI (adım adım)
        5. SÜRÜŞ GÜVENLİĞİ (Şu an sürülebilir mi?)
        6. TAHMİNİ TAMİR SÜRESİ
        
        Yanıtını düz metin olarak ver, markdown kullanma.
        """.trimIndent()

        return analyzeWithPrompt(apiKey, prompt)
    }
}
