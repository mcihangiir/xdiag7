package com.example.data

object PidRepository {
    val allPids = listOf(
        ObdPidDefinition("010C", "Motor Devri", "RPM", "Speed", "((A*256)+B)/4", isSelected = true, 0f, 8000f),
        ObdPidDefinition("010D", "Araç Hızı", "km/h", "DirectionsRun", "A", isSelected = true, 0f, 260f),
        ObdPidDefinition("0105", "Soğutma Sıvısı Sıcaklığı", "°C", "Thermostat", "A-40", isSelected = true, -40f, 215f),
        ObdPidDefinition("010F", "Emme Havası Sıcaklığı", "°C", "Air", "A-40", isSelected = false, -40f, 215f),
        ObdPidDefinition("0104", "Hesaplanan Motor Yükü", "%", "BarChart", "A/2.55", isSelected = false, 0f, 100f),
        ObdPidDefinition("0111", "Gaz Kelebeği Pozisyonu", "%", "Settings", "A/2.55", isSelected = false, 0f, 100f),
        ObdPidDefinition("012F", "Yakıt Seviyesi Girişi", "%", "LocalGasStation", "A/2.55", isSelected = false, 0f, 100f),
        ObdPidDefinition("0142", "Kontrol Modülü Voltajı", "V", "ElectricCar", "((A*256)+B)/1000", isSelected = false, 0f, 24f),
        ObdPidDefinition("010B", "Emme Manifoldu Basıncı", "kPa", "Compress", "A", isSelected = false, 0f, 255f),
        ObdPidDefinition("010A", "Yakıt Basıncı", "kPa", "GasMeter", "A*3", isSelected = false, 0f, 765f),
        ObdPidDefinition("0106", "Kısa Dönem Yakıt Trim (B1)", "%", "TrendingUp", "(A-128)/1.28", isSelected = false, -100f, 99.2f),
        ObdPidDefinition("0107", "Uzun Dönem Yakıt Trim (B1)", "%", "TrendingUp", "(A-128)/1.28", isSelected = false, -100f, 99.2f),
        ObdPidDefinition("0113", "O2 Sensör Konumları", "Bits", "DeviceThermostat", "A", isSelected = false, 0f, 255f),
        ObdPidDefinition("011C", "Desteklenen OBD Standartı", "ID", "Info", "A", isSelected = false, 0f, 10f),
        ObdPidDefinition("0121", "Arıza Işığıyla Kat Edilen Yol", "km", "Explore", "(A*256)+B", isSelected = false, 0f, 65535f),
        ObdPidDefinition("0131", "Katalizör O2 Voltajı B1S1", "V", "Bolt", "((A*256)+B)/8192", isSelected = false, 0f, 1.275f),
        ObdPidDefinition("0133", "Mutlak Barometrik Basınç", "kPa", "CloudQueue", "A", isSelected = false, 0f, 255f),
        ObdPidDefinition("015C", "Motor Yağı Sıcaklığı", "°C", "OilBarrel", "A-40", isSelected = false, -40f, 210f),
        ObdPidDefinition("015E", "Motor Yakıt Akış Hızı", "L/h", "WaterDrop", "((A*256)+B)/20", isSelected = false, 0f, 3212f),
        ObdPidDefinition("0143", "Mutlak Yük Değeri", "%", "Percent", "((A*256)+B)/2.55", isSelected = false, 0f, 100f)
    )
}
