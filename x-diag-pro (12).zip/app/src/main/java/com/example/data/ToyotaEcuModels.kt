package com.example.data

import android.content.Context
import android.util.Log
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

/**
 * Toyota V49.50 BIN Parsing Models and Emulation Engine
 */

data class EcuBinaryHeader(
    val magic: String,          // e.g., "XDIAG"
    val version: String,        // e.g., "V49.50"
    val ecuCode: Int,           // e.g., 0x1001 for Engine OBD/UDS
    val systemName: String,     // e.g., "EFI (Engine Control)"
    val pidOffset: Int,
    val pidCount: Int,
    val dtcOffset: Int,
    val dtcCount: Int,
    val specOffset: Int,
    val specCount: Int
)

data class ToyotaPidDefinition(
    val id: Int,
    val hexCode: String,        // e.g., "010C" (RPM) or custom "2144"
    val name: String,
    val dscTr: String,
    val unit: String,
    val iconName: String = "TrendingUp",
    val formula: String = "A",
    val minValue: Float = 0f,
    val maxValue: Float = 100f,
    var currentValue: Float = 0f
)

data class ToyotaDtcDefinition(
    val code: String,           // e.g., "P0101"
    val dscTr: String,          // Turkish description
    val statusTr: String = "Aktif",
    val subsystem: String = "Güç Grubu (Powertrain)"
)

data class ToyotaSpecialFunction(
    val id: Int,
    val nameTr: String,
    val descriptionTr: String,
    val udsServiceId: String,  // e.g. "31010F"
    val isExecutable: Boolean = true
)

data class ToyotaEcuData(
    val header: EcuBinaryHeader,
    val pids: List<ToyotaPidDefinition>,
    val dtcs: List<ToyotaDtcDefinition>,
    val specialFunctions: List<ToyotaSpecialFunction>
)

/**
 * EcuBinaryParser handles the reading of the binary ".BIN" blocks
 * simulated for Toyota V49.50 professional ECU configurations.
 */
object EcuBinaryParser {
    fun parseAssetBinary(context: Context, assetPath: String, fallbackEcuCode: Int): ToyotaEcuData {
        return EcuDataParser.parseAssetBinary(context, assetPath, fallbackEcuCode)
    }

    fun parseEcuBinary(ecuCode: Int, customBytes: ByteArray? = null): ToyotaEcuData {
        return EcuDataParser.parse(ecuCode, customBytes)
    }

    fun createSimulatedBinary(ecuCode: Int): ByteArray {
        return EcuDataParser.createSimulatedBinary(ecuCode)
    }
}

object LegacyEcuBinaryParser {

    /**
     * Parses an ECU binary file directly from the application's assets (e.g. "toyota_v49/ecu_data_1000.bin").
     * Falls back to dynamically simulated binaries if the physical asset does not exist.
     */
    fun parseAssetBinary(context: Context, assetPath: String, fallbackEcuCode: Int): ToyotaEcuData {
        return try {
            val assetManager = context.assets
            val inputStream: InputStream = assetManager.open(assetPath)
            val bytes = inputStream.readBytes()
            inputStream.close()
            Log.d("EcuBinaryParser", "Successfully loaded real asset file: $assetPath (${bytes.size} bytes)")
            parseEcuBinary(fallbackEcuCode, bytes)
        } catch (e: Exception) {
            Log.w("EcuBinaryParser", "Asset '$assetPath' not found or failed to load. Using standard emulation.", e)
            parseEcuBinary(fallbackEcuCode, null)
        }
    }

    /**
     * Parse simulation that builds structured EcuData out of simulated byte buffers.
     */
    fun parseEcuBinary(ecuCode: Int, customBytes: ByteArray? = null): ToyotaEcuData {
        val bytes = customBytes ?: createSimulatedBinary(ecuCode)
        val buffer = ByteBuffer.wrap(bytes).apply {
            order(ByteOrder.LITTLE_ENDIAN)
        }

        try {
            // Read Header
            val magicBytes = ByteArray(5)
            buffer.get(magicBytes)
            val magic = String(magicBytes, StandardCharsets.US_ASCII)

            val verBytes = ByteArray(6)
            buffer.get(verBytes)
            val version = String(verBytes, StandardCharsets.US_ASCII).trim()

            val readEcuCode = buffer.short.toInt() and 0xFFFF
            
            val nameBytes = ByteArray(32)
            buffer.get(nameBytes)
            val systemName = String(nameBytes, StandardCharsets.UTF_8).trim()

            val pidOffset = buffer.int
            val pidCount = buffer.int
            val dtcOffset = buffer.int
            val dtcCount = buffer.int
            val specOffset = buffer.int
            val specCount = buffer.int

            val header = EcuBinaryHeader(
                magic, version, readEcuCode, systemName,
                pidOffset, pidCount, dtcOffset, dtcCount, specOffset, specCount
            )

            // Extract PIDs
            val pids = mutableListOf<ToyotaPidDefinition>()
            buffer.position(pidOffset)
            for (i in 0 until pidCount) {
                val pidId = buffer.short.toInt() and 0xFFFF
                
                val codeBytes = ByteArray(8)
                buffer.get(codeBytes)
                val hexCode = String(codeBytes, StandardCharsets.US_ASCII).trim()

                val nameBytesField = ByteArray(24)
                buffer.get(nameBytesField)
                val name = String(nameBytesField, StandardCharsets.UTF_8).trim()

                val dscBytes = ByteArray(48)
                buffer.get(dscBytes)
                val dscTr = String(dscBytes, StandardCharsets.UTF_8).trim()

                val unitBytes = ByteArray(12)
                buffer.get(unitBytes)
                val unit = String(unitBytes, StandardCharsets.UTF_8).trim()

                val minVal = buffer.float
                val maxVal = buffer.float

                pids.add(
                    ToyotaPidDefinition(
                        id = pidId,
                        hexCode = hexCode,
                        name = name,
                        dscTr = dscTr,
                        unit = unit,
                        minValue = minVal,
                        maxValue = maxVal
                    )
                )
            }

            // Extract DTCs
            val dtcs = mutableListOf<ToyotaDtcDefinition>()
            buffer.position(dtcOffset)
            for (i in 0 until dtcCount) {
                val codeBytes = ByteArray(8)
                buffer.get(codeBytes)
                val code = String(codeBytes, StandardCharsets.US_ASCII).trim()

                val descBytes = ByteArray(64)
                buffer.get(descBytes)
                val dscTr = String(descBytes, StandardCharsets.UTF_8).trim()

                val statusBytes = ByteArray(16)
                buffer.get(statusBytes)
                val statusTr = String(statusBytes, StandardCharsets.UTF_8).trim()

                val subsysBytes = ByteArray(32)
                buffer.get(subsysBytes)
                val subsystem = String(subsysBytes, StandardCharsets.UTF_8).trim()

                dtcs.add(
                    ToyotaDtcDefinition(
                        code = code,
                        dscTr = dscTr,
                        statusTr = statusTr,
                        subsystem = subsystem
                    )
                )
            }

            // Extract Special Functions
            val specials = mutableListOf<ToyotaSpecialFunction>()
            buffer.position(specOffset)
            for (i in 0 until specCount) {
                val specId = buffer.short.toInt() and 0xFFFF

                val nameBytesField = ByteArray(48)
                buffer.get(nameBytesField)
                val nameTr = String(nameBytesField, StandardCharsets.UTF_8).trim()

                val dscBytes = ByteArray(80)
                buffer.get(dscBytes)
                val dscTr = String(dscBytes, StandardCharsets.UTF_8).trim()

                val uidBytes = ByteArray(12)
                buffer.get(uidBytes)
                val udsId = String(uidBytes, StandardCharsets.US_ASCII).trim()

                specials.add(
                    ToyotaSpecialFunction(
                        id = specId,
                        nameTr = nameTr,
                        descriptionTr = dscTr,
                        udsServiceId = udsId
                    )
                )
            }

            return ToyotaEcuData(header, pids, dtcs, specials)

        } catch (e: Exception) {
            Log.e("EcuBinaryParser", "Error parsing simulated binary data", e)
            // Fallback default
            return createFallbackEcu(ecuCode)
        }
    }

    /**
     * Builds a real binary byte stream representing a professional .BIN automotive index file.
     */
    fun createSimulatedBinary(ecuCode: Int): ByteArray {
        val out = ByteBuffer.allocate(4096).apply {
            order(ByteOrder.LITTLE_ENDIAN)
        }

        // Header (Magic + Version + EcuCode + SystemName)
        out.put("XDIAG".toByteArray(StandardCharsets.US_ASCII)) // 5 bytes
        out.put("V49.50".toByteArray(StandardCharsets.US_ASCII)) // 6 bytes
        out.putShort(ecuCode.toShort()) // 2 bytes

        val name = when (ecuCode) {
            0x1000 -> "Engine Control Module (ECM)"
            0x2000 -> "Transmission Control (TCM)"
            0x3000 -> "Anti-lock Braking (ABS)"
            0x4000 -> "Supplemental Restraint (SRS)"
            0x5000 -> "Body Control Module (BCM)"
            0x6000 -> "Steering Angle Sensor (SAS)"
            0x7000 -> "Tire Pressure Monitor (TPMS)"
            0x8000 -> "Advanced Driver Assist (ADAS)"
            else -> "Multiplex Gateway System (BCM)"
        }
        val nameBytes = name.padToBytes(32)
        out.put(nameBytes) // 32 bytes

        // Dynamic Offset Declarations
        val pidOffset = 120
        var pidCount = 4
        val dtcOffset = 600
        var dtcCount = 2
        val specOffset = 1200
        var specCount = 3

        out.putInt(pidOffset)
        out.putInt(pidCount)
        out.putInt(dtcOffset)
        out.putInt(dtcCount)
        out.putInt(specOffset)
        out.putInt(specCount)

        // Fill PID Data Section
        out.position(pidOffset)
        val pidsList = getEcuSpecificPids(ecuCode)
        pidCount = pidsList.size
        // Override count in header bytes
        out.putInt(56, pidCount) // PID count index in header is 56 (5+6+2+32+4)

        for (pid in pidsList) {
            out.putShort(pid.id.toShort())
            out.put(pid.hexCode.padToBytes(8, StandardCharsets.US_ASCII))
            out.put(pid.name.padToBytes(24))
            out.put(pid.dscTr.padToBytes(48))
            out.put(pid.unit.padToBytes(12))
            out.putFloat(pid.minValue)
            out.putFloat(pid.maxValue)
        }

        // Fill DTC Data Section
        out.position(dtcOffset)
        val dtcsList = getEcuSpecificDtcs(ecuCode)
        dtcCount = dtcsList.size
        // Override count in header
        out.putInt(64, dtcCount) // DTC count index is 64

        for (dtc in dtcsList) {
            out.put(dtc.code.padToBytes(8, StandardCharsets.US_ASCII))
            out.put(dtc.dscTr.padToBytes(64))
            out.put(dtc.statusTr.padToBytes(16))
            out.put(dtc.subsystem.padToBytes(32))
        }

        // Fill Specials Section
        out.position(specOffset)
        val specialsList = getEcuSpecificSpecials(ecuCode)
        specCount = specialsList.size
        // Override count in header
        out.putInt(72, specCount) // Specials count is 72

        for (spec in specialsList) {
            out.putShort(spec.id.toShort())
            out.put(spec.nameTr.padToBytes(48))
            out.put(spec.descriptionTr.padToBytes(80))
            out.put(spec.udsServiceId.padToBytes(12, StandardCharsets.US_ASCII))
        }

        val totalSize = out.position()
        val finalBytes = ByteArray(totalSize)
        out.position(0)
        out.get(finalBytes)
        return finalBytes
    }

    private fun String.padToBytes(size: Int, charset: java.nio.charset.Charset = StandardCharsets.UTF_8): ByteArray {
        val raw = this.toByteArray(charset)
        val out = ByteArray(size)
        System.arraycopy(raw, 0, out, 0, minOf(raw.size, size))
        return out
    }

    private fun getEcuSpecificPids(ecuCode: Int): List<ToyotaPidDefinition> {
        return when (ecuCode) {
            0x1000 -> listOf(
                ToyotaPidDefinition(1, "010C", "Engine_RPM", "Motor Devri", "RPM", "TrendingUp", "A*4", 0f, 8000f),
                ToyotaPidDefinition(2, "010D", "Vehicle_Speed", "Araç Hızı", "km/h", "Speed", "A", 0f, 260f),
                ToyotaPidDefinition(3, "0105", "Coolant_Temp", "Motor Soğutma Suyu Sıcaklığı", "°C", "Thermostat", "A-40", -40f, 215f),
                ToyotaPidDefinition(4, "0110", "MAF_Flow", "Kütle Hava Akış Sensörü", "g/s", "Air", "((A*256)+B)/100", 0f, 650f),
                ToyotaPidDefinition(5, "2144", "VVT_Advance", "VVT-i Eksantrik Açısı", "°", "RotateLeft", "A/2-64", -64f, 63.5f),
                ToyotaPidDefinition(6, "2130", "Injection_Dur", "Enjeksiyon Süresi", "ms", "Bolt", "((A*256)+B)/100", 0f, 30f)
            )
            0x2000 -> listOf(
                ToyotaPidDefinition(11, "2182", "ATF_Temp", "Şanzıman Hidrolik Yağ Sıcaklığı", "°C", "Thermostat", "A-40", -40f, 150f),
                ToyotaPidDefinition(12, "2183", "LockUp_Solenoid", "Tork Konvertör Lock-Up Solenoidi", "%", "Settings", "A*100/255", 0f, 100f),
                ToyotaPidDefinition(13, "2184", "Gear_Position", "Aktif Şanzıman Vites Oranı", "Vites", "FilterAlt", "A", 1f, 8f)
            )
            0x3000 -> listOf(
                ToyotaPidDefinition(21, "2231", "FL_Wheel_Speed", "Ön Sol Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(22, "2232", "FR_Wheel_Speed", "Ön Sağ Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(23, "2233", "RL_Wheel_Speed", "Arka Sol Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(24, "2234", "RR_Wheel_Speed", "Arka Sağ Tekerlek Hız Sensörü", "km/h", "Speed", "((A*256)+B)/100", 0f, 300f),
                ToyotaPidDefinition(25, "2235", "YAW_Rate", "ABS Cayro Yalpalama Oranı (Yaw)", "°/s", "Compare", "((A*256)+B)/10-100", -100f, 100f)
            )
            0x7000 -> listOf(
                ToyotaPidDefinition(31, "2241", "FL_TPMS_Press", "Ön Sol Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f),
                ToyotaPidDefinition(32, "2242", "FR_TPMS_Press", "Ön Sağ Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f),
                ToyotaPidDefinition(33, "2243", "RL_TPMS_Press", "Arka Sol Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f),
                ToyotaPidDefinition(34, "2244", "RR_TPMS_Press", "Arka Sağ Lastik Basıncı", "kPa", "Tire", "A*2.5", 0f, 500f)
            )
            else -> listOf(
                ToyotaPidDefinition(41, "2101", "Control_Module_V", "ECU Kontrol Modülü Voltajı", "V", "Bolt", "A/10", 0f, 18f),
                ToyotaPidDefinition(42, "2102", "Ground_Resistance", "Şasi Toprak Direnci", "Ohm", "SettingsEthernet", "A/100", 0f, 5f)
            )
        }
    }

    private fun getEcuSpecificDtcs(ecuCode: Int): List<ToyotaDtcDefinition> {
        return when (ecuCode) {
            0x1000 -> listOf(
                ToyotaDtcDefinition("P0101", "Düşük Akış - Kütle veya Hacim Hava Akış Devresi Arızası", "Kayıtlı", "Güç Grubu (Powertrain)"),
                ToyotaDtcDefinition("P0300", "Rastgele/Çoklu Silindir Ateşleme Atlaması Saptandı", "Geçici", "Güç Grubu (Powertrain)")
            )
            0x2000 -> listOf(
                ToyotaDtcDefinition("P0741", "Tork Konvertörü Kavraması Solenoid Devresi Performans/Kapalı Kalma", "Kayıtlı", "Transmisyon Kontrol")
            )
            0x3000 -> listOf(
                ToyotaDtcDefinition("C1201", "Motor Kontrol Sistemi Arızası (Hata Sinyali Alındı)", "Aktif", "Fren Kontrol (ABS)")
            )
            0x8000 -> listOf(
                ToyotaDtcDefinition("C1A14", "Ön Radar Sensör Kirli veya Görüşü Engellenmiş", "Aktif", "Kamera/Radar ADAS")
            )
            else -> emptyList()
        }
    }

    private fun getEcuSpecificSpecials(ecuCode: Int): List<ToyotaSpecialFunction> {
        return when (ecuCode) {
            0x1000 -> listOf(
                ToyotaSpecialFunction(101, "Enjektör Kodlama (Compensation Code)", "Yeni enjektörlerin 30 haneli kalibrasyon kodlarını silindir kafasına göre ECU'ya tanımlama.", "31010F"),
                ToyotaSpecialFunction(102, "DPF Rejenerasyonu (DPF Manual Regen)", "Dizel Partikül Filtresinde biriken kurumları yakmak için manuel egzoz ısıtmalı rejen aktivasyonu.", "31011A"),
                ToyotaSpecialFunction(103, "Gaz Kelebeği Öğrenme Sıfırlama (ETCS Reset)", "Gaz kelebeği gövdesi temizlendikten sonra adaptasyon değerlerinin sıfırlanması.", "2F01CA")
            )
            0x2000 -> listOf(
                ToyotaSpecialFunction(104, "CVT Yağ Değişim Ömrü Sıfırlama", "Şanzıman sıvı bozulma katsayısının yeni ATF yağına göre sıfırlanması.", "3101FA"),
                ToyotaSpecialFunction(105, "Vaka Kalibrasyonu (Solenoid Learn)", "Değiştirilen kontrol valfi solenoidleri için debriyaj basma noktalarının öğretilmesi.", "3101FE")
            )
            0x3000 -> listOf(
                ToyotaSpecialFunction(106, "Direksiyon Açı Sensörü Sıfırlama (SAS Reset)", "Direksiyon simidi tam düz konumdayken açısal sıfır noktasının kalibre edilmesi.", "3102A0"),
                ToyotaSpecialFunction(107, "Yalpalama ve G-Sensör Kalibrasyonu", "ABS / ESP beyni içindeki jiroskop yerçekimi sensörlerinin düz zeminde sıfırlanması.", "3102A2")
            )
            else -> listOf(
                ToyotaSpecialFunction(108, "Akıllı Anahtar Tanımlama (IMMO Key Match)", "Kaybolan veya yeni eklenen transponder anahtarın immobilizer modülüyle eşleştirilmesi.", "3103CC")
            )
        }
    }

    private fun createFallbackEcu(ecuCode: Int): ToyotaEcuData {
        val magic = "XDIAG"
        val version = "V49.50"
        val systemName = "General Multiplex System"
        val header = EcuBinaryHeader(magic, version, ecuCode, systemName, 120, 2, 600, 0, 1200, 1)

        return ToyotaEcuData(
            header = header,
            pids = listOf(ToyotaPidDefinition(1, "2101", "Module_V", "Kontrol Voltajı", "V", "Bolt", "A/10", 0f, 16f)),
            dtcs = emptyList(),
            specialFunctions = listOf(ToyotaSpecialFunction(1, "Sistem Sıfırlama", "Modül yazılımsal sıfırlama işlemi", "1101"))
        )
    }
}
