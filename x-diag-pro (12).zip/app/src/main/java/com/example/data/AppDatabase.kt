package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.launch

@Database(
    entities = [
        DiagnosticReport::class,
        com.example.data.db.VehicleBrand::class,
        com.example.data.db.VehicleModel::class,
        com.example.data.db.EcuSystem::class,
        com.example.data.db.TroubleCode::class,
        com.example.data.db.LivePidDefinition::class,
        com.example.data.db.SpecialFunction::class,
        DataRecording::class
    ],
    version = 5,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun reportDao(): ReportDao
    abstract fun dataRecordingDao(): DataRecordingDao
    abstract fun vehicleBrandDao(): com.example.data.db.VehicleBrandDao
    abstract fun vehicleModelDao(): com.example.data.db.VehicleModelDao
    abstract fun ecuSystemDao(): com.example.data.db.EcuSystemDao
    abstract fun troubleCodeDao(): com.example.data.db.TroubleCodeDao
    abstract fun livePidDefinitionDao(): com.example.data.db.LivePidDefinitionDao
    abstract fun specialFunctionDao(): com.example.data.db.SpecialFunctionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "xdiag_database"
                )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        super.onCreate(db)
                        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                            try {
                                kotlinx.coroutines.delay(1000) // Non-blocking delay to let build() finish and assign INSTANCE
                                val targetDb = INSTANCE
                                if (targetDb != null) {
                                    com.example.data.db.DatabaseSeeder.seedDatabase(targetDb, context.applicationContext)
                                } else {
                                    android.util.Log.e("AppDatabase", "Seeding failed: INSTANCE is still null after delay")
                                }
                            } catch (e: Exception) {
                                android.util.Log.e("AppDatabase", "Seeding failed", e)
                            }
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
