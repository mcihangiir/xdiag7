package com.example.data.db

import androidx.room.*
import java.io.Serializable

@Entity(
    tableName = "trouble_codes",
    foreignKeys = [
        ForeignKey(
            entity = EcuSystem::class,
            parentColumns = ["id"],
            childColumns = ["systemId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["systemId"])]
)
data class TroubleCode(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val systemId: Int,
    val code: String, // "P0301", "C0035", etc.
    val codeType: String, // POWERTRAIN, CHASSIS, BODY, NETWORK
    val descriptionTr: String,
    val descriptionEn: String,
    val severity: String, // HIGH, MEDIUM, LOW, INFO
    val possibleCauses: String, // JSON array string
    val possibleFixes: String, // JSON array string
    val affectedComponents: String // JSON array string
) : Serializable
