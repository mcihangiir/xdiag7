package com.example.data.api

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface VehicleApiService {

    @GET("api/v1/brands")
    suspend fun getBrands(
        @Query("region") region: String?
    ): Response<SyncResponse<BrandResponse>>

    @GET("api/v1/models")
    suspend fun getModels(
        @Query("brandId") brandId: Int?
    ): Response<SyncResponse<ModelResponse>>

    @GET("api/v1/dtc")
    suspend fun getDtcCodes(
        @Query("brandId") brandId: Int,
        @Query("systemCode") systemCode: String?
    ): Response<SyncResponse<DtcResponse>>

    @GET("api/v1/pids")
    suspend fun getPids(
        @Query("brandId") brandId: Int?
    ): Response<SyncResponse<PidResponse>>

    @GET("api/v1/special-functions")
    suspend fun getSpecialFunctions(
        @Query("brandId") brandId: Int?
    ): Response<SyncResponse<SpecialFunctionResponse>>

    @GET("api/v1/db/version")
    suspend fun getDbVersion(): Response<DbVersionResponse>

    @GET("https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVin/{vin}")
    suspend fun decodeVin(
        @Path("vin") vin: String,
        @Query("format") format: String = "json"
    ): Response<VinDecodeResponse>
}
