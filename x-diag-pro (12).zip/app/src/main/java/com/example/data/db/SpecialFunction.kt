package com.example.data.db

import androidx.room.*
import java.io.Serializable

@Entity(
    tableName = "special_functions",
    foreignKeys = [
        ForeignKey(
            entity = VehicleBrand::class,
            parentColumns = ["id"],
            childColumns = ["brandId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["brandId"])]
)
data class SpecialFunction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val brandId: Int? = null,
    val modelId: Int? = null,
    val functionCode: String, // OIL_RESET, DPF_REGEN, EPB_OPEN...
    val functionName: String,
    val description: String,
    val warningText: String,
    val commandSequence: String, // JSON array string
    val requiresVehicleOff: Boolean = true,
    val requiresEngineRunning: Boolean = false,
    val minVoltage: Float = 12.1f
) : Serializable
