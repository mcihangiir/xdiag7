package com.example.data

import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class Converters {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    @TypeConverter
    fun stringToTroubleCodeList(data: String?): List<TroubleCode>? {
        if (data == null) return emptyList()
        val listType = Types.newParameterizedType(List::class.java, TroubleCode::class.java)
        val adapter = moshi.adapter<List<TroubleCode>>(listType)
        return try {
            adapter.fromJson(data)
        } catch (e: Exception) {
            emptyList()
        }
    }

    @TypeConverter
    fun troubleCodeListToString(list: List<TroubleCode>?): String {
        val listType = Types.newParameterizedType(List::class.java, TroubleCode::class.java)
        val adapter = moshi.adapter<List<TroubleCode>>(listType)
        return adapter.toJson(list ?: emptyList())
    }

    @TypeConverter
    fun stringToVehicleSystemList(data: String?): List<VehicleSystem>? {
        if (data == null) return emptyList()
        val listType = Types.newParameterizedType(List::class.java, VehicleSystem::class.java)
        val adapter = moshi.adapter<List<VehicleSystem>>(listType)
        return try {
            adapter.fromJson(data)
        } catch (e: Exception) {
            emptyList()
        }
    }

    @TypeConverter
    fun vehicleSystemListToString(list: List<VehicleSystem>?): String {
        val listType = Types.newParameterizedType(List::class.java, VehicleSystem::class.java)
        val adapter = moshi.adapter<List<VehicleSystem>>(listType)
        return adapter.toJson(list ?: emptyList())
    }
}
