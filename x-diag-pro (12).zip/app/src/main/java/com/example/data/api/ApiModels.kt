package com.example.data.api

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class BrandResponse(
    val id: Int,
    val name: String,
    val nameLocal: String,
    val region: String,
    val isPopular: Boolean,
    val sortOrder: Int = 0
)

@JsonClass(generateAdapter = true)
data class ModelResponse(
    val id: Int,
    val brandId: Int,
    val name: String,
    val nameLocal: String = "",
    val yearStart: Int,
    val yearEnd: Int?,
    val engineCodes: List<String>,
    val bodyTypes: List<String> = emptyList()
)

@JsonClass(generateAdapter = true)
data class DtcResponse(
    val code: String,
    val systemCode: String,
    val descriptionTr: String,
    val descriptionEn: String,
    val severity: String,
    val possibleCauses: List<String>,
    val possibleFixes: List<String>,
    val affectedComponents: List<String> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PidResponse(
    val pid: String,
    val name: String,
    val nameEn: String = "",
    val unit: String,
    val formula: String,
    val minValue: Float,
    val maxValue: Float,
    val mode: String = "01",
    val brandId: Int?,
    val isDefault: Boolean = false
)

@JsonClass(generateAdapter = true)
data class SpecialFunctionResponse(
    val functionCode: String,
    val functionName: String,
    val brandId: Int?,
    val modelId: Int? = null,
    val commandSequence: List<String>,
    val warningText: String,
    val description: String = "",
    val requiresVehicleOff: Boolean = true,
    val requiresEngineRunning: Boolean = false,
    val minVoltage: Float = 12.1f
)

@JsonClass(generateAdapter = true)
data class DbVersionResponse(
    val version: Int,
    val releaseDate: String,
    val changelog: String
)

@JsonClass(generateAdapter = true)
data class SyncResponse<T>(
    val success: Boolean,
    val data: List<T>,
    val totalCount: Int,
    val pageSize: Int,
    val page: Int
)

@JsonClass(generateAdapter = true)
data class VinDecodeResponse(
    val Count: Int? = null,
    val Message: String? = null,
    val SearchCriteria: String? = null,
    val Results: List<VinResultItem>? = null
)

@JsonClass(generateAdapter = true)
data class VinResultItem(
    val Value: String?,
    val ValueId: String?,
    val Variable: String?,
    val VariableId: Int?
)
