package com.example.data

enum class DtcStatusCategory {
  ACTIVE,           // Etkin, Aktif, aktif/statik, Current, Present
  STORED,           // Saklandı, Kayıtlı, KAYITLI, History, Mevcut
  INTERMITTENT,     // Aralıklı, geçici hata, pasif/kendiliginden olan
  ELECTRICAL_SHORT_PLUS,   // Short to Plus
  ELECTRICAL_SHORT_GROUND, // Short to Ground
  ELECTRICAL_OPEN,         // Open or Short to Plus/Ground
  SIGNAL_IMPLAUSIBLE,      // Implausible Signal
  LIMIT_EXCEEDED_UPPER,    // Upper Limit Exceeded
  LIMIT_EXCEEDED_LOWER,    // Lower Limit Exceeded
  RESISTANCE_FAULT,        // Resistance beyond maximum limit
  NO_COMMUNICATION,        // No Signal/Communication
  NOT_PRESENT,             // Mevcut değil, Normal, mevcut degil
  CONTINUOUS_MEMORY,       // Continuous Memory DTC (CMDTC)
  ONE_TIME_MEMORY          // One-time DTC (ODDTC)
}

data class DtcStatusInfo(
  val category: DtcStatusCategory,
  val rawLabelsEn: List<String>,   // orijinal İngilizce/karışık etiketler
  val labelTr: String,             // Türkçe gösterim
  val severity: String,            // Kritik/Uyarı/Bilgi
  val colorHex: String,            // UI rengi
  val technicianNote: String       // teknisyene özel açıklama
)

object DtcStatusDictionary {
  val ALL = listOf(
    DtcStatusInfo(DtcStatusCategory.ACTIVE, listOf("Etkin","Aktif","Current","Present","aktif/statik"),
      "Aktif Hata", "Kritik", "#EF4444",
      "Hata şu anda mevcut ve devam ediyor. Acil kontrol gerekli."),
    DtcStatusInfo(DtcStatusCategory.STORED, listOf("Saklandı","Kayıtlı","History","Mevcut"),
      "Kayıtlı (Geçmiş) Hata", "Uyarı", "#F59E0B",
      "Hata daha önce oluşmuş, şu an aktif değil. Tekrarlama riski var."),
    DtcStatusInfo(DtcStatusCategory.INTERMITTENT, listOf("Aralıklı","geçici hata","pasif/kendiliginden olan"),
      "Aralıklı Hata", "Uyarı", "#F59E0B",
      "Hata düzensiz aralıklarla ortaya çıkıyor. Bağlantı/sensör gevşekliği şüphesi."),
    DtcStatusInfo(DtcStatusCategory.ELECTRICAL_SHORT_PLUS, listOf("Short to Plus"),
      "Artıya Kısa Devre", "Kritik", "#EF4444",
      "Devre, besleme voltajına kısa devre yapmış. Kablo hasarı kontrol edilmeli."),
    DtcStatusInfo(DtcStatusCategory.ELECTRICAL_SHORT_GROUND, listOf("Short to Ground"),
      "Toprağa Kısa Devre", "Kritik", "#EF4444",
      "Devre, şaseye/topraklamaya kısa devre yapmış."),
    DtcStatusInfo(DtcStatusCategory.ELECTRICAL_OPEN, listOf("Open or Short to Plus","Open or Short to Ground"),
      "Açık Devre / Kısa Devre", "Kritik", "#EF4444",
      "Kablo kopuk veya bağlantı kesik olabilir."),
    DtcStatusInfo(DtcStatusCategory.SIGNAL_IMPLAUSIBLE, listOf("Implausible Signal"),
      "Mantıksız Sinyal", "Uyarı", "#F59E0B",
      "Sensör sinyali beklenen aralığın tamamen dışında — sensör arızası şüphesi."),
    DtcStatusInfo(DtcStatusCategory.LIMIT_EXCEEDED_UPPER, listOf("Upper Limit Exceeded"),
      "Üst Limit Aşıldı", "Uyarı", "#F59E0B",
      "Ölçülen değer maksimum kabul edilebilir sınırın üzerinde."),
    DtcStatusInfo(DtcStatusCategory.LIMIT_EXCEEDED_LOWER, listOf("Lower Limit Exceeded"),
      "Alt Limit Aşıldı", "Uyarı", "#F59E0B",
      "Ölçülen değer minimum kabul edilebilir sınırın altında."),
    DtcStatusInfo(DtcStatusCategory.RESISTANCE_FAULT, listOf("Resistance beyond maximum limit"),
      "Direnç Limit Aşımı", "Uyarı", "#F59E0B",
      "Devre direnci normal aralığın dışında — korozyon/bağlantı sorunu olabilir."),
    DtcStatusInfo(DtcStatusCategory.NO_COMMUNICATION, listOf("No Signal/Communication"),
      "Sinyal/İletişim Yok", "Kritik", "#EF4444",
      "İlgili modülden hiç yanıt alınamıyor. CAN-Bus veya modül arızası."),
    DtcStatusInfo(DtcStatusCategory.NOT_PRESENT, listOf("Mevcut değil","Normal","mevcut degil"),
      "Mevcut Değil", "Bilgi", "#22C55E",
      "Bu sistemde şu an herhangi bir arıza tespit edilmedi."),
    DtcStatusInfo(DtcStatusCategory.CONTINUOUS_MEMORY, listOf("Continuous Memory DTC","CMDTCs"),
      "Sürekli Bellek Hatası (CMDTC)", "Uyarı", "#F59E0B",
      "Bu hata her kontak açılışında otomatik kontrol edilir, silinemez kalıcı kayıt."),
    DtcStatusInfo(DtcStatusCategory.ONE_TIME_MEMORY, listOf("One-time DTC","ODDTCs"),
      "Tek Seferlik Hata (ODDTC)", "Bilgi", "#3B82F6",
      "Hata bir kez tetiklenmiş, sürekli izlenmiyor.")
  )

  fun classify(rawStatus: String): DtcStatusInfo {
    val normalized = rawStatus.trim().lowercase()
    return ALL.firstOrNull { info ->
      info.rawLabelsEn.any { it.lowercase() == normalized || normalized.contains(it.lowercase()) }
    } ?: ALL.first { it.category == DtcStatusCategory.NOT_PRESENT }
  }
}
