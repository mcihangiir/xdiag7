package com.example.data

import com.example.ui.screens.RepairGuide

object RepairGuideMatcher {
    fun findGuideForDtc(dtcCode: String, allGuides: List<RepairGuide>): RepairGuide? {
        val cleanDtc = dtcCode.trim().uppercase()
        
        // 1. Doğrudan DTC kodu eşleşmesi ara (guide.id veya guide.title veya relatedDtcCodes içinde)
        val directMatch = allGuides.firstOrNull { guide ->
            guide.id.uppercase() == cleanDtc || 
            guide.title.uppercase().contains(cleanDtc) ||
            guide.relatedDtcCodes.any { it.trim().uppercase() == cleanDtc }
        }
        if (directMatch != null) return directMatch
        
        // 2. Yoksa, DTC'nin sistem prefixine göre eşleştir (P0=Motor, B=Gövde, C=Şasi, U=Network)
        val prefix = if (cleanDtc.isNotEmpty()) cleanDtc.substring(0, 1) else ""
        val categoryPrefixMatch = when (prefix) {
            "P" -> {
                // Motor Güç Aktarma Sistemi hatası
                allGuides.firstOrNull { it.id.uppercase().contains("MOTOR") || it.title.uppercase().contains("MOTOR") || it.title.uppercase().contains("POWERTRAIN") || it.associatedSpecialFunctionRoute.contains("DPF") }
            }
            "B" -> {
                // Gövde Sistemi hatası
                allGuides.firstOrNull { it.id.uppercase().contains("BODY") || it.id.uppercase().contains("GÖVDE") || it.title.uppercase().contains("GÖVDE") }
            }
            "C" -> {
                // Şasi / Fren / ABS / SAS hatası
                allGuides.firstOrNull { it.id.uppercase().contains("CHASSIS") || it.id.uppercase().contains("ABS") || it.id.uppercase().contains("ŞASİ") || it.title.uppercase().contains("FREN") || it.associatedSpecialFunctionRoute.contains("SAS") }
            }
            "U" -> {
                // Network / CAN-Bus hatası
                allGuides.firstOrNull { it.id.uppercase().contains("BUS") || it.id.uppercase().contains("NETWORK") || it.title.uppercase().contains("İLETİŞİM") || it.title.uppercase().contains("CAN") }
            }
            else -> null
        }
        
        return categoryPrefixMatch ?: allGuides.firstOrNull()
    }
}
