package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {
    @Query("SELECT * FROM diagnostic_reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<DiagnosticReport>>

    @Query("SELECT COUNT(*) FROM diagnostic_reports WHERE timestamp > :since")
    suspend fun getReportCountSince(since: Long): Int

    @Query("SELECT AVG(healthPercentage) FROM diagnostic_reports WHERE timestamp > :since")
    suspend fun getAverageHealthSince(since: Long): Float?

    @Query("SELECT * FROM diagnostic_reports WHERE id = :id")
    suspend fun getReportById(id: Int): DiagnosticReport?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: DiagnosticReport): Long

    @Query("UPDATE diagnostic_reports SET signatureBase64 = :signature, isSigned = 1 WHERE id = :reportId")
    suspend fun updateSignature(reportId: Int, signature: String)

    @Delete
    suspend fun deleteReport(report: DiagnosticReport)

    @Query("DELETE FROM diagnostic_reports")
    suspend fun deleteAllReports()
}
