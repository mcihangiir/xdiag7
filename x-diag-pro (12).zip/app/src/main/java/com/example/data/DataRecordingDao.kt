package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DataRecordingDao {
  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insert(recording: DataRecording): Long

  @Query("SELECT * FROM data_recordings ORDER BY timestamp DESC")
  fun getAll(): Flow<List<DataRecording>>

  @Query("SELECT * FROM data_recordings WHERE id = :id")
  suspend fun getById(id: Int): DataRecording?

  @Delete
  suspend fun delete(recording: DataRecording)
}
