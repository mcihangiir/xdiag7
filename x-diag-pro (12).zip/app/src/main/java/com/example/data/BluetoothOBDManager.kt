package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class BluetoothOBDManager(private val context: Context) : IOBDConnection {
    companion object {
        // Standard SPP UUID for ELM327 and classical BT serial devices
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val TAG = "BluetoothOBDManager"
    }

    override val protocolType = ProtocolType.CLASSIC_BT_ELM327

    private val bluetoothManager: BluetoothManager? = context.getSystemService(BluetoothManager::class.java)
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    private val _isConnected = MutableStateFlow(false)
    override val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _connectionStatus = MutableStateFlow("Bekleniyor...")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    // Fiziksel bağlantı kopmasını (örn. cihaz araçtan çekildiğinde) gerçekten
    // tespit etmek için periyodik canlılık kontrolü. Bağlantı "BAĞLI" yazısı
    // artık sadece bir bayrak değil, gerçekten yanıt alındığı sürece geçerlidir.
    private var heartbeatJob: Job? = null

    fun startHeartbeat(scope: CoroutineScope) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (_isConnected.value) {
                delay(5000)
                if (!_isConnected.value) break
                val response = try {
                    withTimeoutOrNull(3000L) { sendRawCommand("ATI") }
                } catch (e: Exception) {
                    null
                }
                if (response == null || response.startsWith("ERROR") || response == "TIMEOUT" || response.isBlank()) {
                    Log.w(TAG, "Heartbeat başarısız, bağlantı koptu sayılıyor: $response")
                    _isConnected.value = false
                    _connectionStatus.value = "BAĞLANTI KOPTU (cihaz yanıt vermiyor)"
                    _connectionState.value = ConnectionState.DISCONNECTED
                    break
                }
            }
        }
    }

    fun stopHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    override suspend fun connect(): Boolean {
        // implemented in connectToDevice
        return false 
    }

    private var reconnectJob: kotlinx.coroutines.Job? = null
    private var isIntentionalDisconnect = false

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDevice> {
        return bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
    }

    @SuppressLint("MissingPermission")
    suspend fun connectToDevice(device: BluetoothDevice): Boolean = withContext(Dispatchers.IO) {
        isIntentionalDisconnect = false
        var retryCount = 0
        val maxRetries = 3
        var success = false

        _connectionState.value = ConnectionState.CONNECTING
        while (retryCount < maxRetries && !success) {
            try {
                if (retryCount > 0) {
                    _connectionStatus.value = "Yeniden deneniyor (${retryCount + 1}/$maxRetries)..."
                    delay(1000L * retryCount)
                } else {
                    _connectionStatus.value = "Bağlanıyor: ${device.name ?: device.address}..."
                }

                var connectedSocket: BluetoothSocket? = null
                
                // fallback connection sequence
                try {
                    Log.d(TAG, "Trying standard secure RFCOMM socket...")
                    connectedSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                    connectedSocket.connect()
                } catch (e1: Exception) {
                    Log.w(TAG, "Standard RFCOMM failed: ${e1.message}. Trying insecure RFCOMM...")
                    try {
                        connectedSocket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID)
                        connectedSocket.connect()
                    } catch (e2: Exception) {
                        Log.w(TAG, "Insecure RFCOMM failed: ${e2.message}. Trying reflection-based port 1 RFCOMM...")
                        try {
                            val method = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                            connectedSocket = method.invoke(device, 1) as BluetoothSocket
                            connectedSocket.connect()
                        } catch (e3: Exception) {
                            Log.e(TAG, "Reflection RFCOMM port 1 also failed: ${e3.message}")
                            throw e3
                        }
                    }
                }

                bluetoothSocket = connectedSocket
                inputStream = bluetoothSocket?.inputStream
                outputStream = bluetoothSocket?.outputStream
                
                // Initialization AT commands for ELM327 using suspend delay instead of sleep
                sendRawCommand("ATZ") // Reset
                delay(800)
                sendRawCommand("ATE0") // Echo Off
                delay(200)
                sendRawCommand("ATL0") // LineFeeds Off
                delay(200)
                sendRawCommand("ATH1") // Headers On
                delay(200)
                sendRawCommand("ATSP0") // Protocol Auto
                delay(400)

                _isConnected.value = true
                _connectionState.value = ConnectionState.CONNECTED
                _connectionStatus.value = "Gerçek Cihaza Bağlandı: ${device.name ?: device.address}"
                success = true
                
                // Cancel old reconnect jobs if any
                reconnectJob?.cancel()
            } catch (e: Exception) {
                Log.e(TAG, "Connection failed: attempt ${retryCount + 1}", e)
                retryCount++
                disconnectStreamsOnly()
                if (retryCount >= maxRetries) {
                    _connectionState.value = ConnectionState.ERROR
                    _connectionStatus.value = "Bağlantı Hatası: ${e.localizedMessage}"
                    if (!isIntentionalDisconnect) {
                        triggerAutoReconnect(device)
                    }
                }
            }
        }
        return@withContext success
    }

    private fun disconnectStreamsOnly() {
        try {
            inputStream?.close()
            outputStream?.close()
            bluetoothSocket?.close()
        } catch (_: Exception) {}
        inputStream = null
        outputStream = null
        bluetoothSocket = null
    }

    override fun disconnect() {
        isIntentionalDisconnect = true
        reconnectJob?.cancel()
        reconnectJob = null
        stopHeartbeat()
        try {
            inputStream?.close()
            outputStream?.close()
            bluetoothSocket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing socket", e)
        } finally {
            inputStream = null
            outputStream = null
            bluetoothSocket = null
            _isConnected.value = false
            _connectionState.value = ConnectionState.DISCONNECTED
            _connectionStatus.value = "Bağlantı Kesildi"
        }
    }

    @SuppressLint("MissingPermission")
    private fun triggerAutoReconnect(device: BluetoothDevice) {
        reconnectJob?.cancel()
        reconnectJob = kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            var attempt = 1
            val maxAttempts = 5
            while (attempt <= maxAttempts && !_isConnected.value && !isIntentionalDisconnect) {
                _connectionState.value = ConnectionState.CONNECTING // Reconnecting doesn't exist, use CONNECTING
                _connectionStatus.value = "Kopma Sonrası Otomatik Yeniden Bağlanma Deneniyor ($attempt/$maxAttempts)..."
                Log.d(TAG, "Auto reconnect attempt $attempt of $maxAttempts")
                
                val connectedNow = connectToDevice(device)
                if (connectedNow) {
                    Log.d(TAG, "Auto reconnect succeeded on attempt $attempt")
                    break
                }
                attempt++
                if (attempt <= maxAttempts) {
                    delay(30000) // retry every 30 seconds
                }
            }
            if (!_isConnected.value && !isIntentionalDisconnect) {
                _connectionState.value = ConnectionState.ERROR
                _connectionStatus.value = "Kalıcı Bağlantı Hatası: Cihazla bağlantı yeniden kurulamadı."
            }
        }
    }

    @SuppressLint("MissingPermission")
    override suspend fun sendRawCommand(cmd: String): String = withContext(Dispatchers.IO) {
        if (outputStream == null || inputStream == null) return@withContext ""
        
        // Timeout handling of command sending & waiting response (max 4000ms)
        val result = kotlinx.coroutines.withTimeoutOrNull(4000) {
            try {
                val commandWithReturn = "$cmd\r"
                outputStream?.write(commandWithReturn.toByteArray())
                outputStream?.flush()
                
                val buffer = ByteArray(1024)
                val sb = java.lang.StringBuilder()
                val startTime = System.currentTimeMillis()
                
                while (System.currentTimeMillis() - startTime < 2500) {
                    if (inputStream!!.available() > 0) {
                        val numRead = inputStream!!.read(buffer)
                        if (numRead > 0) {
                            val chunk = String(buffer, 0, numRead, Charsets.US_ASCII)
                            sb.append(chunk)
                            if (chunk.contains(">")) {
                                break
                            }
                        }
                    } else {
                        delay(20)
                    }
                }
                
                val rawResponse = sb.toString().trim()
                if (rawResponse.contains(">")) {
                    rawResponse.replace(">", "").trim()
                } else {
                    rawResponse
                }
            } catch (e: IOException) {
                Log.e(TAG, "IOException during command transmission: $cmd", e)
                // Do not drop the whole connection on a single command error. 
                // Return "ERROR" and let the connection remain active.
                "ERROR"
            }
        }
        
        return@withContext result ?: "TIMEOUT"
    }
}
