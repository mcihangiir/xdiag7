package com.example.data.db

import android.content.Context
import android.util.Log
import com.example.data.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object DatabaseSeeder {

    suspend fun seedDatabase(db: AppDatabase, context: Context? = null) = withContext(Dispatchers.IO) {
        val brandDao = db.vehicleBrandDao()
        val modelDao = db.vehicleModelDao()
        val ecuDao = db.ecuSystemDao()
        val dtcDao = db.troubleCodeDao()
        val pidDao = db.livePidDefinitionDao()
        val specialDao = db.specialFunctionDao()

        // ===== GÖREV 0: MARKA SEED ET (50 Marka) =====
        val brands = listOf(
            // EUROPE
            VehicleBrand(1, "VW", "Volkswagen", "EUROPE", null, true, 2),
            VehicleBrand(2, "BMW", "Bayerische Motoren Werke", "EUROPE", null, false, 50),
            VehicleBrand(3, "Mercedes-Benz", "Mercedes-Benz", "EUROPE", null, false, 51),
            VehicleBrand(4, "Audi", "Audi AG", "EUROPE", null, false, 52),
            VehicleBrand(5, "Porsche", "Porsche", "EUROPE", null, false, 53),
            VehicleBrand(6, "Opel", "Opel Automobile", "EUROPE", null, true, 3, false, null, "[\"Opel\",\"Vauxhall\"]"),
            VehicleBrand(7, "Peugeot", "Peugeot", "EUROPE", null, false, 54),
            VehicleBrand(8, "Renault", "Renault Groupe", "EUROPE", null, true, 1, false, null, "[\"Renault\",\"REHAULT\"]"),
            VehicleBrand(9, "Fiat", "FIAT", "EUROPE", null, true, 5, false, null, "[\"Fiat\",\"Alfa Romeo\",\"Lancia\"]"),
            VehicleBrand(10, "Alfa Romeo", "Alfa Romeo", "EUROPE", null, false, 55, false, null, "[\"Fiat\",\"Alfa Romeo\",\"Lancia\"]"),
            VehicleBrand(11, "Volvo", "Volvo Cars", "EUROPE", null, false, 56),
            VehicleBrand(12, "Skoda", "Škoda Auto", "EUROPE", null, true, 8),
            VehicleBrand(13, "SEAT", "SEAT S.A.", "EUROPE", null, true, 10),
            VehicleBrand(14, "Citroen", "Citroën", "EUROPE", null, false, 57),
            VehicleBrand(15, "Land Rover", "Land Rover", "EUROPE", null, false, 58),
            VehicleBrand(16, "Jaguar", "Jaguar Cars", "EUROPE", null, false, 59),
            VehicleBrand(17, "Mini", "MINI Cooper", "EUROPE", null, false, 60),
            VehicleBrand(18, "Saab", "Saab Automobile", "EUROPE", null, false, 61),
            VehicleBrand(51, "Dacia", "Dacia", "EUROPE", null, true, 4, false, null, "[\"Dacia\",\"Renault-Dacia\"]"),
            VehicleBrand(52, "Ford", "Ford (Avrupa)", "EUROPE", null, true, 6, false, "EU", "[\"EUROFORD\",\"Ford Europe\"]"),
            
            // ASIA
            VehicleBrand(19, "Toyota", "Toyota Motor Corp.", "ASIA", null, true, 9, true),
            VehicleBrand(20, "Honda", "Honda Motor Corp.", "ASIA", null, false, 62),
            VehicleBrand(21, "Nissan", "Nissan Motor", "ASIA", null, true, 11),
            VehicleBrand(22, "Mazda", "Mazda Motor", "ASIA", null, false, 63),
            VehicleBrand(23, "Mitsubishi", "Mitsubishi Motors", "ASIA", null, false, 64),
            VehicleBrand(24, "Subaru", "Subaru Corp.", "ASIA", null, false, 65),
            VehicleBrand(25, "Suzuki", "Suzuki Motor", "ASIA", null, false, 66),
            VehicleBrand(26, "Lexus", "Lexus", "ASIA", null, false, 67),
            VehicleBrand(27, "Infiniti", "Infiniti", "ASIA", null, false, 68),
            VehicleBrand(28, "Acura", "Acura", "ASIA", null, false, 69),
            VehicleBrand(29, "Hyundai", "Hyundai Motor", "ASIA", null, true, 7),
            VehicleBrand(30, "Kia", "Kia Motors", "ASIA", null, false, 70),
            VehicleBrand(31, "Genesis", "Genesis", "ASIA", null, false, 71),
            VehicleBrand(32, "SsangYong", "SsangYong KG Mobility", "ASIA", null, false, 72),
            // AMERICA
            VehicleBrand(33, "Ford", "Ford (ABD)", "AMERICA", null, false, 99, false, "US", "[\"USAFORD\",\"Ford USA\"]"),
            VehicleBrand(34, "Chevrolet", "Chevrolet GM", "AMERICA", null, false, 73),
            VehicleBrand(35, "Dodge", "Dodge Ram", "AMERICA", null, false, 74),
            VehicleBrand(36, "Jeep", "Jeep Chrysler", "AMERICA", null, false, 75),
            VehicleBrand(37, "Chrysler", "Chrysler Group", "AMERICA", null, false, 76),
            VehicleBrand(38, "Cadillac", "Cadillac GM", "AMERICA", null, false, 77),
            VehicleBrand(39, "GMC", "GMC Trucks", "AMERICA", null, false, 78),
            VehicleBrand(40, "Buick", "Buick GM", "AMERICA", null, false, 79),
            VehicleBrand(41, "Lincoln", "Lincoln Ford", "AMERICA", null, false, 80),
            VehicleBrand(42, "Tesla", "Tesla Motors", "AMERICA", null, false, 81),
            // CHINA
            VehicleBrand(43, "Geely", "Geely Holding Group", "CHINA", null, false, 82),
            VehicleBrand(44, "BYD", "BYD Auto", "CHINA", null, false, 83),
            VehicleBrand(45, "Great Wall", "Great Wall Motor", "CHINA", null, false, 84),
            VehicleBrand(46, "Chery", "Chery Automobile", "CHINA", null, false, 85),
            VehicleBrand(47, "BAIC", "BAIC Group", "CHINA", null, false, 86),
            VehicleBrand(48, "MG", "MG Motor", "CHINA", null, false, 87),
            VehicleBrand(49, "Haval", "Haval GWM", "CHINA", null, false, 88),
            VehicleBrand(50, "Wuling", "Wuling SJGM", "CHINA", null, false, 89)
        )
        brandDao.insertAll(brands)

        // ===== GÖREV 1: 15 ARAÇ MODELİ EKLE =====
        val models = listOf(
            VehicleModel(1, 19, "Auris", "Auris HB / Sedan", 2007, 2019, "[\"1NR-FE\",\"1ZR-FE\",\"2ZR-FE\",\"2AD-FHV\"]", "[\"Hatchback\",\"Sedan\",\"Touring\"]"),
            VehicleModel(2, 19, "Corolla", "Corolla Sedan", 1966, 2026, "[\"1ZR-FE\",\"2ZR-FE\",\"1NR-FE\",\"2NR-FE\",\"M20A-FKS\"]", "[\"Sedan\",\"Hatchback\",\"Touring\"]"),
            VehicleModel(3, 19, "Yaris", "Yaris HB", 1999, 2026, "[\"1KR-FE\",\"1NR-FE\",\"1NZ-FE\",\"M15A-FKS\"]", "[\"Hatchback\",\"Sedan\"]"),
            VehicleModel(4, 19, "RAV4", "RAV4 SUV", 1994, 2026, "[\"2AR-FE\",\"2GR-FKS\",\"A25A-FXS\"]", "[\"SUV\"]"),
            VehicleModel(5, 19, "Camry", "Camry Sedan", 1982, 2026, "[\"2AR-FE\",\"A25A-FXS\",\"6AR-FSE\"]", "[\"Sedan\"]"),
            VehicleModel(6, 2, "3 Serisi", "3 Serisi Sedan / Touring", 1975, 2026, "[\"B48B20\",\"B58B30\",\"N20B20\",\"N52B30\"]", "[\"Sedan\",\"Coupe\",\"Touring\",\"Cabriolet\"]"),
            VehicleModel(7, 2, "5 Serisi", "5 Serisi Sedan", 1972, 2026, "[\"B48B20\",\"B58B30\",\"N63B44\",\"B57D30\"]", "[\"Sedan\",\"Touring\"]"),
            VehicleModel(8, 2, "X5", "X5 SUV", 1999, 2026, "[\"B58B30\",\"N63B44\",\"B57D30\",\"S63B44\"]", "[\"SUV\"]"),
            VehicleModel(9, 3, "C Serisi", "C Serisi Sedan", 1993, 2026, "[\"M264\",\"M256\",\"OM654\",\"M133\"]", "[\"Sedan\",\"Coupe\",\"Cabrio\",\"Estate\"]"),
            VehicleModel(10, 3, "E Serisi", "E Serisi Prestige", 1984, 2026, "[\"M264\",\"M256\",\"OM654\",\"M176\"]", "[\"Sedan\",\"Coupe\",\"Estate\",\"Cabrio\"]"),
            VehicleModel(11, 3, "GLC", "GLC SUV", 2015, 2026, "[\"M264\",\"OM654\",\"M276\"]", "[\"SUV\",\"Coupe\"]"),
            VehicleModel(12, 1, "Golf", "Golf Hatchback", 1974, 2026, "[\"EA211\",\"EA888\",\"DKZA\",\"DFYA\"]", "[\"Hatchback\",\"Variant\",\"Cabrio\"]"),
            VehicleModel(13, 1, "Passat", "Passat Variant", 1973, 2026, "[\"EA211\",\"EA888\",\"EA897\"]", "[\"Sedan\",\"Variant\"]"),
            VehicleModel(14, 52, "Focus", "Focus Active", 1998, 2026, "[\"Fox\",\"Sigma\",\"Duratec\",\"EcoBoost\"]", "[\"Hatchback\",\"Sedan\",\"Estate\"]"),
            VehicleModel(15, 29, "Tucson", "Tucson SUV", 2004, 2026, "[\"G4NA\",\"G4KH\",\"D4HA\",\"T-GDi\"]", "[\"SUV\"]"),
            VehicleModel(16, 30, "Sportage", "Sportage SUV", 1993, 2026, "[\"G4NA\",\"G4KH\",\"D4HA\"]", "[\"SUV\"]"),
            VehicleModel(17, 6, "Astra-H", "Astra-H Classic", 2004, 2014, "[\"Z16XEP\",\"Z13DTH\",\"Z14XEP\",\"Z16XER\"]", "[\"Hatchback\",\"Station Wagon\",\"Sedan\"]")
        )
        modelDao.insertAll(models)

        // ===== GÖREV 2: HER MODEL İÇİN ECU SİSTEMLERİ =====
        val brandEcus = mutableListOf<EcuSystem>()
        
        // Auris (modelId = 1) - Zaten mevcut (1-9)
        brandEcus.add(EcuSystem(1, 1, "ECM", "Motor Kontrol Modülü (ECM)", "7E0", "CAN", 500000, true))
        brandEcus.add(EcuSystem(2, 1, "TCM", "Şanzıman Kontrol Modülü (TCM)", "7E1", "CAN", 500000, true))
        brandEcus.add(EcuSystem(3, 1, "ABS", "Kilitlenme Karşıtı Fren Sistemi (ABS)", "7B0", "CAN", 500000, true))
        brandEcus.add(EcuSystem(4, 1, "SRS", "Hava Yastığı Kontrol Sistemi (SRS)", "7B3", "CAN", 500000, true))
        brandEcus.add(EcuSystem(5, 1, "BCM", "Gövde Kontrol Modülü (BCM)", "7A0", "CAN", 500000, true))
        brandEcus.add(EcuSystem(6, 1, "HVAC", "Klima ve Hava İklimlendirme", "7C4", "CAN", 500000, true))
        brandEcus.add(EcuSystem(7, 1, "EPS", "Elektromekanik Direksiyon Modülü", "7A7", "CAN", 500000, true))
        brandEcus.add(EcuSystem(8, 1, "TPMS", "Lastik Basıncı İzleme Beyni (TPMS)", "7A1", "CAN", 500000, true))
        brandEcus.add(EcuSystem(9, 1, "IMMO", "İmmobilizer Emniyet Modülü", "7E0", "CAN", 500000, true))

        var systemIdCounter = 10
        
        // TOYOTA: Corolla (2), Yaris (3), RAV4 (4), Camry (5)
        for (mId in 2..5) {
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ECM", "EFI - Motor Kontrol Modülü (ECM)", "7E0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TCM", "ECT - Şanzıman Kontrol Modülü (TCM)", "7E1", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ABS", "ABS/VSC - Fren Kontrol Sistemi (ABS)", "7B0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "SRS", "SRS - Hava Yastığı Emniyet Modülü", "7B3", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "BCM", "BCM - Gövde Manuel Modülü (BCM)", "7A0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "HVAC", "HVAC - Otomatik Klima Kontrolü", "7C4", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "EPS", "EMPS - Güçlü Direksiyon Beyni (EPS)", "7A7", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TPMS", "TPMS - Lastik Basıncı İzleme Modülü", "7A1", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "IMMO", "IMMO - İmmobilizer Güvenlik Kilidi", "7E0", "CAN", 500000, true))
        }

        // BMW: 3 Serisi (6), 5 Serisi (7), X5 (8)
        for (mId in 6..8) {
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ECM", "DME - Dijital Motor Elektroniği", "12", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TCM", "EGS - Elektronik Şanzıman Kontrol (EGS)", "18", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ABS", "DSC - Dinamik Stabilite Kontrolü (DSC)", "19", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "SRS", "ACSM - Gelişmiş Güvenlik Modülü (SRS)", "26", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "BCM", "BDC - Gövde Alan Elektronik Kontrolörü", "0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "HVAC", "IHKA - Otomatik Isıtma ve Klima", "3E", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "EPS", "EPS - Direksiyon Destek Elektromekaniği", "60", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TPMS", "RDC - Lastik Basınç Kontrolü (TPMS)", "70", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "IMMO", "CAS - Konfor Erişim Sistemi", "12", "CAN", 500000, true))
        }

        // MERCEDES: C Serisi (9), E Serisi (10), GLC (11)
        for (mId in 9..11) {
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ECM", "ME - Motor Elektroniği Kontrol Modülü", "7E0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TCM", "ETC - Şanzıman Elektronik Kontrolörü (ETC)", "7E1", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ABS", "ESP - Elektronik Stabilite Programı (ESP)", "7B0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "SRS", "AB - Hava Yastığı Emniyet Modülü (AB)", "7B3", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "BCM", "SAM - Sinyal Toplayıcı ve Denetleyici Modül", "7A0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "HVAC", "AAC - Otomatik İklim Sistemi (Klima/HVAC)", "7C4", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "EPS", "EPS - Elektrik Yardımlı Direksiyon Sistemi", "7A7", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TPMS", "RCM - Lastik Basınç Alıcı ve Uyarı Modülü", "7A1", "CAN", 500000, true))
        }

        // VW: Golf (12), Passat (13)
        for (mId in 12..13) {
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ECM", "01 - Motor Kontrol Ünitesi (Motorsteuergerät)", "7E0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TCM", "02 - Şanzıman Kontrol Modülü (TCM/DSG)", "7E1", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ABS", "03 - Kilitlenme Karşıtı Fren Grubu (ABS)", "7B0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "SRS", "15 - Hava Yastığı Sistemi (Airbagsystem)", "7B3", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "BCM", "09 - Karosseriesteuergerät (Gövde Elektroniği)", "7A0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "HVAC", "08 - Isıtma Klima Havalandırma Modülü", "7C4", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "EPS", "44 - Direksiyon Destek Kutusu (EPS)", "7A7", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TPMS", "65 - Lastik Basıncı İzleme Beyni (TPMS)", "7A1", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "IMMO", "25 - İmmobilizer Güvenlik Modülü", "7E0", "CAN", 500000, true))
        }

        // FORD: Focus (14)
        brandEcus.add(EcuSystem(systemIdCounter++, 14, "ECM", "PCM - Güç Aktarım Organı Kontrol Modülü", "7E0", "CAN", 500000, true))
        brandEcus.add(EcuSystem(systemIdCounter++, 14, "TCM", "TCM - Şanzıman Elektronik Kontrol Sistemi", "7E1", "CAN", 500000, true))
        brandEcus.add(EcuSystem(systemIdCounter++, 14, "ABS", "ABS - Kilitleme Önleyici Fren Modülü", "7B0", "CAN", 500000, true))
        brandEcus.add(EcuSystem(systemIdCounter++, 14, "SRS", "SRS - Yardımcı Emniyet Sistemi (Airbag)", "7B3", "CAN", 500000, true))
        brandEcus.add(EcuSystem(systemIdCounter++, 14, "BCM", "BCM - Gövde Alan Elektronik Kontrolü", "726", "CAN", 500000, true))
        brandEcus.add(EcuSystem(systemIdCounter++, 14, "HVAC", "HVAC - Klima Havalandırma Denetleyicisi", "733", "CAN", 500000, true))

        // HYUNDAI: Tucson (15) / KIA: Sportage (16)
        for (mId in 15..16) {
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ECM", "Engine Control Module (ECM / Motor Beyni)", "7E0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TCM", "Transmission Control Module (TCM / Şanzıman)", "7E1", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "ABS", "Anti-Lock Brake System (ABS / Fren Beyni)", "7B0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "SRS", "Supplemental Restraint System (Airbag SRS)", "7B3", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "BCM", "Body Control Module (BCM / Gövde)", "7A0", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "HVAC", "Heating Ventilation Air Condition (HVAC)", "7C4", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "EPS", "MDPS - Motor Destekli Elektrikli Direksiyon", "7A7", "CAN", 500000, true))
            brandEcus.add(EcuSystem(systemIdCounter++, mId, "TPMS", "TPMS - Lastik Basınç Uyarı Beyni", "7A1", "CAN", 500000, true))
        }

        // OPEL: Astra-H (17)
        brandEcus.add(EcuSystem(systemIdCounter++, 17, "ECM", "Motor Kontrol Modülü (ECM)", "7E0", "CAN", 500000, true, "ECM_Z16XER", "0x112A"))
        brandEcus.add(EcuSystem(systemIdCounter++, 17, "CIM", "Direksiyon Kolu Tümleşik Modülü (CIM)", "7E4", "CAN", 500000, true, "CIM_ASTRA_H", "0x1121"))
        brandEcus.add(EcuSystem(systemIdCounter++, 17, "REC", "Arka Elektrik Merkezi (REC)", "7A5", "CAN", 500000, true, "REC_ASTRA_H", "0x112B"))
        brandEcus.add(EcuSystem(systemIdCounter++, 17, "UEC", "Ön Motor Bölmesi Elektrik Merkezi (UEC)", "7A4", "CAN", 500000, true, "UEC_ASTRA_H", "0x112C"))
        brandEcus.add(EcuSystem(systemIdCounter++, 17, "IPC", "Gösterge Tablosu Kontrol Grubu (IPC)", "795", "CAN", 500000, true, "IPC_ASTRA_H", "0x112D"))
        brandEcus.add(EcuSystem(systemIdCounter++, 17, "ABS", "Fren Kontrol Grubu (ABS/ESP)", "7B0", "CAN", 500000, true, "ABS_ASTRA_H", "0x1122"))

        ecuDao.insertAll(brandEcus)

        // ===== GÖREV 3: 200+ DTC KODU EKLE =====
        val troubleCodes = mutableListOf<TroubleCode>()
        var dtcIdCounter = 1

        // 1. Seed existing Auris DTCs (1 to 31)
        val aurisDtcTemplates = listOf(
            // ECM (Auris Id = 1)
            Triple("P0300", "Çoklu Silindir Ateşleme Kaçırma Arızası", "Random/Multiple Cylinder Misfire Detected"),
            Triple("P0301", "Silindir 1 Ateşleme Kaçırma Arızası", "Cylinder 1 Misfire Detected"),
            Triple("P0302", "Silindir 2 Ateşleme Kaçırma Arızası", "Cylinder 2 Misfire Detected"),
            Triple("P0303", "Silindir 3 Ateşleme Kaçırma Arızası", "Cylinder 3 Misfire Detected"),
            Triple("P0304", "Silindir 4 Ateşleme Kaçırma Arızası", "Cylinder 4 Misfire Detected"),
            Triple("P0171", "Yakıt Sistemi Fakir Karışım Bank 1", "System Too Lean Bank 1"),
            Triple("P0172", "Yakıt Sistemi Zengin Karışım Bank 1", "System Too Rich Bank 1"),
            Triple("P0420", "Katalitik Dönüştürücü Verimliliği Sınırın Altında", "Catalyst System Efficiency Below Threshold B1"),
            Triple("P0401", "EGR Valfi Akış Yetersizliği Genliği", "EGR Flow Insufficient Detected"),
            Triple("P0456", "Buharlaşma Emisyon Sistemi Çok Küçük Sızıntı", "EVAP System Very Small Leak Detected"),
            Triple("P0500", "Araç Hız Sensörü 'A' Hatası", "Vehicle Speed Sensor 'A' Malfunction"),
            Triple("P3125", "Toyota Özel: Evirici (Inverter) Montaj Arızası", "Inverter Assembly Malfunction"),
            Triple("P3126", "Toyota Özel: Evirici Su Pompası Gerilim Hatası", "Inverter Coolant Pump Power Line Error"),
            Triple("P3190", "Toyota Özel: Düşük Motor Gücü Arızası", "Poor Engine Power Toyota Special"),
            Triple("P0101", "Kütle Hava Akış (MAF) Sensörü Performans Sınır Hatası", "MAF Sensor Performance/Range Problem"),
            Triple("P0113", "Emme Havası Sıcaklık Sensörü 1 Yüksek Giriş Hatası", "Intake Air Temp Sensor 1 High Circuit"),
            Triple("P0118", "Motor Soğutma Sıvısı Sıcaklık Sensörü Yüksek Giriş", "Engine Coolant Temp Sensor Circuit High"),
            Triple("P0122", "Gaz Kelebeği Konum Sensörü Düşük Devresi", "Throttle Position Sensor Circuit Low Input"),
            Triple("P0130", "Oksijen Sensörü Devresi Bank 1 Sensör 1", "O2 Sensor Circuit Bank 1 Sensor 1"),
            Triple("P0325", "Vuruntu Sensörü 1 Devresi Hatası", "Knock Sensor 1 Circuit Malfunction"),
            Triple("P00A0", "Emme Havası Sıcaklık Sensörü 2 Devresi (Bank 1)", "Intake Air Temperature Sensor 2 Circuit (Bank 1)"),
            Triple("P0201", "Enjektör 1 Silindir Arızası", "Injector Circuit - Cylinder 1"),
            Triple("P0300", "Rastgele/Çoklu Silindir Ateşleme Kaçırma Tespit Edildi", "Random/Multiple Cylinder Misfire Detected"),
            Triple("U0100", "ECM/PCM ile İletişim Kayboldu", "Lost Communication with ECM/PCM")
        )
        
        for (tpl in aurisDtcTemplates) {
            troubleCodes.add(TroubleCode(
                id = dtcIdCounter++,
                systemId = 1, // Auris ECM
                code = tpl.first,
                codeType = "POWERTRAIN",
                descriptionTr = tpl.second,
                descriptionEn = tpl.third,
                severity = "HIGH",
                possibleCauses = "[\"Bujiler aşınmış\",\"Sensör kirlenmiş\",\"Kablo bağlantısı temassız\"]",
                possibleFixes = "[\"Bileşeni kontrol edip değiştirin\",\"Soketleri temizleyin\"]",
                affectedComponents = "[\"Ateşleme Sistemi\",\"Emme Hattı\"]"
            ))
        }

        // ABS (systemId = 3) for Auris
        val aurisAbsCodes = listOf(
            Pair("C0200", "Sağ Ön Tekerlek Hız Sensörü Sinyal/Devre Hatası"),
            Pair("C0205", "Sol Ön Tekerlek Hız Sensörü Sinyal/Devre Hatası"),
            Pair("C0210", "Sağ Arka Tekerlek Hız Sensörü Sinyal/Devre Hatası"),
            Pair("C0215", "Sol Arka Tekerlek Hız Sensörü Sinyal/Devre Hatası"),
            Pair("C0236", "ABS Hidrolik Pompa Motor Arızası"),
            Pair("C1201", "Motor Kontrol Sistemi Arızası - ABS Devre Dışı"),
            Pair("C1241", "Düşük Besleme Gerilimi ABS Devresi"),
            Pair("C0034", "Sağ Ön Tekerlek Hız Sensör Arızası (ABS)")
        )
        for (c in aurisAbsCodes) {
            troubleCodes.add(TroubleCode(dtcIdCounter++, 3, c.first, "CHASSIS", c.second, c.second, "HIGH", "[\"ABS kablosu kopuk\",\"Sensör kirlenmiş\"]", "[\"Sensör temizleyin\",\"Kabloyu onarın\"]", "[\"ABS Sensörü\"]"))
        }

        // SRS (systemId = 4) for Auris
        val aurisSrsCodes = listOf(
            Pair("B1650", "Sürücü Hava Yastığı (Airbag) Tetikleme Devresi Arızası"),
            Pair("B1654", "Yolcu Hava Yastığı (Airbag) Tetikleme Devresi Hatası"),
            Pair("B1801", "Sürücü Tarafı Ön Airbag Devresi Açık"),
            Pair("B1811", "Yolcu Tarafı Ön Airbag Devresi Açık")
        )
        for (c in aurisSrsCodes) {
            troubleCodes.add(TroubleCode(dtcIdCounter++, 4, c.first, "BODY", c.second, c.second, "HIGH", "[\"Zemberek direksiyon sargısı yırtık\",\"Fiş çıkmış\"]", "[\"Zemberek sargısını değiştirin\",\"Konektörü sabitleyin\"]", "[\"Hava Yastığı Sargısı\"]"))
        }

        // Let's ensure id starts at 32 for the next ones, aligning with the actual counter!
        dtcIdCounter = 32

        // TOYOTA ECM TEMPLATES (For Corolla (10), Yaris (19), RAV4 (28), Camry (37))
        val toyotaEcmTemplates = listOf(
            DtcTemplate("P0011", "POWERTRAIN", "Eksantrik Mili \"A\" Konum - Zamanlama Aşırı İleri (Bank 1)", "Camshaft Position \"A\" - Timing Over-Advanced (Bank 1)", "HIGH", listOf("VVT-i solenoid tıkanık", "Düşük yağ basıncı", "Yağ kirli"), listOf("Yağ değişimi yapın", "VVT-i solenoid temizleyin", "Zamanlama zinciri kontrol edin"), listOf("VVT Solenoid", "Zamanlama Zinciri")),
            DtcTemplate("P0016", "POWERTRAIN", "Krank/Eksantrik Korelasyon Hatası Bank 1 Sensör A", "Crankshaft-Camshaft Correlation Bank 1 Sensor A", "HIGH", listOf("Zamanlama zinciri atlamış", "Eksantrik sensör bozuk"), listOf("Zamanlama zinciri gerilimini kontrol edin", "VVT-i pozisyon sensörünü kontrol edin"), listOf("Krank Sensörü", "Eksantrik Sensörü")),
            DtcTemplate("P0021", "POWERTRAIN", "Eksantrik Mili \"A\" Konum - Zamanlama Aşırı İleri Bank 2", "Camshaft Position \"A\" - Timing Over-Advanced Bank 2", "HIGH", listOf("Zamanlama hatası", "VVT valfi bozuk"), listOf("VVT valfini test edin"), listOf("Eksantrik Mili Solenoidi")),
            DtcTemplate("P0031", "POWERTRAIN", "O2 Isıtıcı Devresi Düşük Bank 1 Sensör 1", "Oxygen Sensor Heater Control Circuit Low B1S1", "HIGH", listOf("Isıtıcı rezistans arızalı", "Kablo kısa devre"), listOf("O2 sensörünü değiştirin"), listOf("Lamda O2 Sensörü")),
            DtcTemplate("P0032", "POWERTRAIN", "O2 Isıtıcı Devresi Yüksek Bank 1 Sensör 1", "Oxygen Sensor Heater Control Circuit High B1S1", "HIGH", listOf("Isıtıcı kısa devre", "Sigorta atmış"), listOf("Kablo kontrolü", "O2 Sensörü değişimi"), listOf("Hararet/Isıtıcı Rezistansı")),
            DtcTemplate("P0037", "POWERTRAIN", "O2 Isıtıcı Devresi Düşük Bank 1 Sensör 2", "Oxygen Sensor Heater Control Circuit Low B1S2", "MEDIUM", listOf("Katalog arkası O2 arızası"), listOf("Arka O2 değiştirin"), listOf("Egzoz O2 Sensörü")),
            DtcTemplate("P0100", "POWERTRAIN", "MAF Sensörü Devre Arızası", "Mass or Volume Air Flow Circuit Malfunction", "HIGH", listOf("MAF direnç kesintisi", "Hava hattı kaçağı"), listOf("Konnektör pini temizliği", "MAF değişimi"), listOf("Hava Akış Sensörü")),
            DtcTemplate("P0102", "POWERTRAIN", "MAF Sensörü Düşük Giriş", "Mass or Volume Air Flow Circuit Low Input", "HIGH", listOf("Gövdede tıkanıklık", "Sensör kirliliği"), listOf("Özel MAF temizlik spreyi"), listOf("MAF Sensör Filtresi")),
            DtcTemplate("P0103", "POWERTRAIN", "MAF Sensörü Yüksek Giriş", "Mass or Volume Air Flow Circuit High Input", "HIGH", listOf("Kısa devre", "Eşik gerilim hatası"), listOf("Kabloları gözden geçirin"), listOf("Soket Kablosu")),
            DtcTemplate("P0110", "POWERTRAIN", "Emme Havası Sıcaklık Sensörü Devre Arızası", "Intake Air Temperature Circuit Malfunction", "MEDIUM", listOf("IAT sensör bozulması"), listOf("Sıcaklık direnç ölçümü", "Sensör değişimi"), listOf("IAT Termistör")),
            DtcTemplate("P0115", "POWERTRAIN", "Motor Soğutma Sıcaklık Sensörü Devre Arızası", "Engine Coolant Temperature Circuit Malfunction", "HIGH", listOf("Hararet sensör direnci bozuk"), listOf("Soğutma sıvısı seviyesi kontrol", "ECT sensör testi"), listOf("ECT Termostat Sensörü")),
            DtcTemplate("P0120", "POWERTRAIN", "Gaz Kelebeği/Pedal A Devresi Arızası", "Throttle/Pedal Position Sensor \"A\" Circuit", "HIGH", listOf("Kelebek potansiyometresi aşınmış"), listOf("Pedal konum sensörü / kelebek değişimi"), listOf("Gaz Kelebeği Sensörü")),
            DtcTemplate("P0121", "POWERTRAIN", "Gaz Kelebeği A Performans/Aralık Hatası", "Throttle Position Sensor A Range/Performance", "HIGH", listOf("Pislik birikmesi", "Bozuk adaptasyon"), listOf("Gaz kelebeği temizliği", "Yeniden adaptasyon"), listOf("Gaz Kelebek Plakası")),
            DtcTemplate("P0128", "POWERTRAIN", "Soğutma Sıvısı Termostat (Düşük Sıcaklık)", "Coolant Thermostat Below Thermostat Regulating Temp", "MEDIUM", listOf("Termostat açık kalmış"), listOf("Termostatı yenileyin"), listOf("Termostat")),
            DtcTemplate("P0136", "POWERTRAIN", "O2 Sensör Devresi Bank 1 Sensör 2", "Oxygen Sensor Circuit Bank 1 Sensor 2", "MEDIUM", listOf("O2 sensörü açık devre"), listOf("Lamda sensörü değişimi"), listOf("Ön/Arka Lamda")),
            DtcTemplate("P0141", "POWERTRAIN", "O2 Sensör Isıtıcı Devresi Bank 1 Sensör 2", "O2 Heater Circuit Bank 1 Sensor 2", "MEDIUM", listOf("Sensör rezistansı açık kablo"), listOf("Sensörü yenileyin"), listOf("Egzoz Sensörü")),
            DtcTemplate("P0155", "POWERTRAIN", "O2 Sensör Isıtıcı Devresi Bank 2 Sensör 1", "O2 Heater Circuit Bank 2 Sensor 1", "HIGH", listOf("Bank 2 ön ısıtıcı arızalı"), listOf("Lamda sensörü değişim"), listOf("V6 O2 Sensörü Bank 2")),
            DtcTemplate("P0174", "POWERTRAIN", "Yakıt Sistemi Fakir Bank 2", "System Too Lean Bank 2", "HIGH", listOf("Emmeye kontrol dışı sızan hava"), listOf("Duman testi ve kaçak tespiti"), listOf("Vakum Hortumu")),
            DtcTemplate("P0175", "POWERTRAIN", "Yakıt Sistemi Zengin Karışım Bank 2", "System Too Rich Bank 2", "HIGH", listOf("Sızdıran enjektör bank 2"), listOf("Enjektör testi ve kalibrasyonu"), listOf("Yakıt Enjektörü")),
            DtcTemplate("P0191", "POWERTRAIN", "Yakıt Ray Basınç Sensörü Performans", "Fuel Rail Pressure Sensor Circuit Range/Performance", "HIGH", listOf("Basınç regülatörü kalibrasyon kaybı"), listOf("Ray basınç sensörü değişimi"), listOf("Sensör / Pompa")),
            DtcTemplate("P0201", "POWERTRAIN", "Enjektör 1 Devre Arızası", "Injector Circuit - Cylinder 1", "HIGH", listOf("Enjektör bobini açık devre"), listOf("Enjektör değişimi, kablo tamiri"), listOf("Enjektör 1 Sinyal Kablosu")),
            DtcTemplate("P0202", "POWERTRAIN", "Enjektör 2 Devre Arızası", "Injector Circuit - Cylinder 2", "HIGH", listOf("Enjektör 2 soket kırıklığı"), listOf("Konektörü tamir edin"), listOf("Enjektör 2")),
            DtcTemplate("P0203", "POWERTRAIN", "Enjektör 3 Devre Arızası", "Injector Circuit - Cylinder 3", "HIGH", listOf("Sinyal kesintisi"), listOf("Enjektör soketi onarımı"), listOf("Enjektör 3")),
            DtcTemplate("P0204", "POWERTRAIN", "Enjektör 4 Devre Arızası", "Injector Circuit - Cylinder 4", "HIGH", listOf("Kısa devre"), listOf("Kablo kontrolü ve enjektör revizyon"), listOf("Enjektör 4")),
            DtcTemplate("P0335", "POWERTRAIN", "Krank Mili Konum Sensörü A Devresi", "Crankshaft Position Sensor \"A\" Circuit", "HIGH", listOf("Sensör manyetiği pislenmiş", "Sensör bozuk"), listOf("Sensörü söküp temizleyin", "Gerekirse değiştirin"), listOf("Krank Sensörü")),
            DtcTemplate("P0340", "POWERTRAIN", "Eksantrik Mili Konum Sensörü A Devresi (Bank 1)", "Camshaft Position Sensor \"A\" Circuit Single Sensor", "HIGH", listOf("Eksantrik sensörü temassız", "Mıknatıs kırık"), listOf("Sensör testi", "Soketi kontrol"), listOf("CMP Sensör Kablosu")),
            DtcTemplate("P0341", "POWERTRAIN", "Eksantrik Mili Konum Sensörü A Performans", "Camshaft Position Sensor A Performance B1", "HIGH", listOf("Zamanlama kaçıklığı"), listOf("Zamanlama konum denetimi"), listOf("Ayar Zinciri")),
            DtcTemplate("P0351", "POWERTRAIN", "Ateşleme Bobini A Birincil/İkincil Devre", "Ignition Coil \"A\" Primary/Secondary Circuit", "HIGH", listOf("Bobin 1 iç devre kısa tetiği"), listOf("Bobin 1 değişimi"), listOf("Ateşleme Bobini 1")),
            DtcTemplate("P0352", "POWERTRAIN", "Ateşleme Bobini B Birincil/İkincil Devre", "Ignition Coil \"B\" Primary/Secondary Circuit", "HIGH", listOf("Bobin 2 kısa devre"), listOf("Bobin 2 yenileyin"), listOf("Bobin 2")),
            DtcTemplate("P0353", "POWERTRAIN", "Ateşleme Bobini C Birincil/İkincil Devre", "Ignition Coil \"C\" Primary/Secondary Circuit", "HIGH", listOf("Bobin 3 tetik kopukluğu"), listOf("Bobin değişimi"), listOf("Bobin 3")),
            DtcTemplate("P0354", "POWERTRAIN", "Ateşleme Bobini D Birincil/İkincil Devre", "Ignition Coil \"D\" Primary/Secondary Circuit", "HIGH", listOf("Bobin 4 bozuk"), listOf("Yeni bobin montajı"), listOf("Bobin 4")),
            DtcTemplate("P0400", "POWERTRAIN", "EGR Akışı Arızası", "Exhaust Gas Recirculation Flow Malfunction", "MEDIUM", listOf("EGR borusunda yoğun kurum"), listOf("EGR temizleme tazyikli sprey"), listOf("EGR Kanalı")),
            DtcTemplate("P0403", "POWERTRAIN", "EGR Kontrol Solenoid Devresi", "Exhaust Gas Recirculation Control Circuit", "MEDIUM", listOf("EGR solenoid valfi direnci sıfır"), listOf("Solenoid direnç testi ve değişimi"), listOf("EGR Solenoid Valfi")),
            DtcTemplate("P0441", "POWERTRAIN", "EVAP Emisyon Kontrol Sistemi Yanlış Tasfiye Akışı", "EVAP System Incorrect Purge Flow", "MEDIUM", listOf("Kanister purge valfi takılı kalmış"), listOf("Kanister valfini değiştirin"), listOf("EVAP Canister Valfi")),
            DtcTemplate("P0446", "POWERTRAIN", "EVAP Emisyon Kontrol Sistemi Vent Kontrol Devresi", "EVAP System Vent Control Circuit Malfunction", "MEDIUM", listOf("Evap hattında hava sızıntısı"), listOf("Basınçlandırma sızıntı kontrolü"), listOf("EVAP Sızdırmazlık")),
            DtcTemplate("P0450", "POWERTRAIN", "EVAP Emisyon Kontrol Sistemi Basınç Sensörü", "EVAP System Pressure Sensor Malfunction", "MEDIUM", listOf("Basınç sensörü gerilim kaybı"), listOf("Sensör besleme testi"), listOf("Basınç Sensörü")),
            DtcTemplate("P0505", "POWERTRAIN", "Rölanti Kontrol Sistemi Arızası", "Idle Control System Malfunction", "HIGH", listOf("IAC valfi kurum birikmesi", "Kelebek kirliliği"), listOf("Rölanti motoru ve kelebek boğaz temizliği"), listOf("IAC Rölanti Motoru")),
            DtcTemplate("P0550", "POWERTRAIN", "Direksiyon Yardım Basınç Sensörü Devresi", "Power Steering Pressure Sensor Circuit Malfunction", "MEDIUM", listOf("Direksiyon hidrolik basıncı okunamıyor"), listOf("Basınç sensörü değiştirme"), listOf("PSP Direksiyon Sensörü")),
            DtcTemplate("P0600", "POWERTRAIN", "Seri İletişim Hatası", "Serial Communication Link", "HIGH", listOf("CAN-Bus hattında parazit veya kısa"), listOf("CAN kablolama ve direnç testi (60 ohm)"), listOf("CAN Veri Verici Yolu)),")),
            DtcTemplate("P0604", "POWERTRAIN", "Dahili Kontrol Modülü RAM Arızası", "Internal Control Module RAM Error", "HIGH", listOf("ECU işlemci içi RAM arızası"), listOf("EPROM yeniden programlama / ECU tamiri"), listOf("ECU Beyin Entegrasyonu")),
            DtcTemplate("P0606", "POWERTRAIN", "PCM İşlemci Arızası", "ECM/PCM Processor Defect", "HIGH", listOf("İşlemcide donanımsal çökme"), listOf("ECU anakart kontrolü veya ECU değiştirme"), listOf("Anakart Mikroişlemci"))
        )

        // TOYOTA ECM'ler: Corolla (10), Yaris (19), RAV4 (28), Camry (37)
        val toyotaEcmSystemIds = listOf(10, 19, 28, 37)
        for (sysId in toyotaEcmSystemIds) {
            for (tpl in toyotaEcmTemplates) {
                troubleCodes.add(TroubleCode(
                    id = dtcIdCounter++,
                    systemId = sysId,
                    code = tpl.code,
                    codeType = tpl.type,
                    descriptionTr = tpl.descTr,
                    descriptionEn = tpl.descEn,
                    severity = tpl.severity,
                    possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                    possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                    affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
                ))
            }
        }

        // BMW ÖZEL DTC (DME/DSC/EPS/ACSM için): 3 Serisi (46), 5 Serisi (55), X5 (64)
        val bmwEcmTemplates = listOf(
            DtcTemplate("29CD", "POWERTRAIN", "DME: Kütlesel Hava Akış Sensörü - sinyal geçerli aralığın dışında", "DME: Mass Air Flow Sensor - Signal Out of Range", "HIGH", listOf("MAF direnci kirliliği", "Sinyal sapması"), listOf("MAF temizleme", "Hortum kaçak kontrolü"), listOf("MAF Sensör")),
            DtcTemplate("29D1", "POWERTRAIN", "DME: Emme Manifoldu Basınç Sensörü arızası", "DME: Intake Manifold Pressure Sensor Fault", "HIGH", listOf("MAP sensör hassasiyeti bozulmuş"), listOf("MAP sensörü değiştirin"), listOf("MAP Manifold Sensörü")),
            DtcTemplate("29E0", "POWERTRAIN", "DME: Lambda Sensörü B1S1 ısıtma devresi", "DME: Lambda Sensor B1S1 Heater Circuit", "HIGH", listOf("Isıtıcı rezistansı açık devre"), listOf("Ön Lambda sensörünü değiştirin"), listOf("Ön Lambda sensörü")),
            DtcTemplate("2A67", "POWERTRAIN", "DME: VANOS eksantrik kapama valfı, pozisyon sapması", "DME: VANOS Valve Lift Control Deviation", "HIGH", listOf("VANOS solenoid valf pisliği", "Yağ kanalları tıkalı"), listOf("Valfi temizleyip test edin", "Yağ filtresi kontrol"), listOf("VANOS Aktüatörü")),
            DtcTemplate("2A68", "POWERTRAIN", "DME: VANOS eksantrik açma valfı, pozisyon sapması", "DME: VANOS Valve Lift Open Deviation", "HIGH", listOf("Valfte mekanik sıkışma"), listOf("VANOS solenoidini yenileyin"), listOf("VANOS Solenoid Supap")),
            DtcTemplate("480A", "CHASSIS", "DSC: Ön sol ABS tekerlek hız sensörü sinyal hattı kopuk", "DSC: Front Left Wheel Speed Sensor Open Circuit", "HIGH", listOf("ABS kablosu hasarlı", "Sensör bozuk"), listOf("Tekerlek yuvası soketi temizleyin", "Sensör değişimi"), listOf("Ön Sol Hız Sensörü")),
            DtcTemplate("480B", "CHASSIS", "DSC: Ön sağ ABS tekerlek hız sensörü sinyal hattı kopuk", "DSC: Front Right Wheel Speed Sensor Open Circuit", "HIGH", listOf("Sensör ucu çarpma sonucu hasarlı"), listOf("Sağ ön sensör yenileyin"), listOf("Ön Sağ Hız Sensörü")),
            DtcTemplate("480C", "CHASSIS", "DSC: Arka sol ABS tekerlek hız sensörü", "DSC: Rear Left Wheel Speed Sensor Fault", "HIGH", listOf("Rulman boşluğu", "Sensör pisliği"), listOf("Rulman kontrol et", "Sensör sil"), listOf("Arka Sol ABS")),
            DtcTemplate("480D", "CHASSIS", "DSC: Arka sağ ABS tekerlek hız sensörü", "DSC: Rear Right Wheel Speed Sensor Fault", "HIGH", listOf("Kontak oksitlenmesi"), listOf("Soket temizleyici sıkın"), listOf("Arka Sağ ABS")),
            DtcTemplate("9C02", "CHASSIS", "EPS: Direksiyon tork sensörü sapması", "EPS: Steering Torque Sensor Deviation", "HIGH", listOf("Tork sensörü kalibrasyon dışı"), listOf("EPS sıfırlama işlemi yapın", "Direksiyon kutusu revizyon"), listOf("Direksiyon Tork Sensörü")),
            DtcTemplate("9C04", "CHASSIS", "EPS: EPS motoru aşırı sıcak", "EPS: EPS Motor Over Temperature", "HIGH", listOf("Aşırı yükte uzun süre zorlama"), listOf("Sistemi rölantide soğumaya bırakın"), listOf("Elektrikli Direksiyon Motoru")),
            DtcTemplate("9C1F", "CHASSIS", "EPS: Güç kaynağı gerilim düşük", "EPS: Power Supply Voltage Low", "HIGH", listOf("Zayıf akü", "Kötü şasi bağlantısı"), listOf("Şasi vidasını sıkın", "Aküyü dolum yapın"), listOf("Güç Tesisatı Kablosu")),
            DtcTemplate("A000", "BODY", "ACSM: Sürücü airbag ateşleme devresi direnci yüksek", "ACSM: Driver Airbag Resistance High", "HIGH", listOf("Direksiyon zembereği kopuk", "Soket gevşek"), listOf("Zemberek sargısını değiştirin"), listOf("Sürücü Hava Yastığı Sargısı")),
            DtcTemplate("A002", "BODY", "ACSM: Yolcu airbag ateşleme devresi direnci yüksek", "ACSM: Passenger Airbag Resistance High", "HIGH", listOf("Yolcu airbag soket temassızlığı"), listOf("Soket kilit tırnağını sıkın"), listOf("Yolcu Hava Yastığı")),
            DtcTemplate("A010", "BODY", "ACSM: Emniyet kemeri gerilici devresi", "ACSM: Seat Belt Tensioner Circuit Resistance High", "HIGH", listOf("Kemer fişeği direnci yüksek"), listOf("Gergili soketi yenileyin"), listOf("Emniyet Kemeri Fişeği"))
        )

        val bmwEcmSystemIds = listOf(46, 55, 64)
        for (sysId in bmwEcmSystemIds) {
            for (tpl in bmwEcmTemplates) {
                troubleCodes.add(TroubleCode(
                    id = dtcIdCounter++,
                    systemId = sysId,
                    code = tpl.code,
                    codeType = tpl.type,
                    descriptionTr = tpl.descTr,
                    descriptionEn = tpl.descEn,
                    severity = tpl.severity,
                    possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                    possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                    affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
                ))
            }
        }

        // VW/AUDI SPECIAL DTC: Golf (97), Passat (106)
        val vwEcmTemplates = listOf(
            DtcTemplate("P0087", "POWERTRAIN", "Yakıt Sistemi Düşük Basıncı", "Fuel Rail/System Pressure - Too Low", "HIGH", listOf("Yüksek basınç pompası asınması", "Yakıt filtresi bloke"), listOf("HPFP basınç testi uygulayın", "Filtre değişimi"), listOf("HPFP Yakıt Pompası")),
            DtcTemplate("P0299", "POWERTRAIN", "Turbo/Süperşarj Düşük Takviye", "Turbo/Supercharger Underboost", "HIGH", listOf("Turbo emme hortumu yırtık", "Wastegate valfi açık"), listOf("Hortum kaçaklarını kontrol edin", "Wastegate bakımı"), listOf("Takviye Hortumu")),
            DtcTemplate("P0234", "POWERTRAIN", "Turbo/Süperşarj Yüksek Takviye", "Turbo/Supercharger Overboost Condition", "HIGH", listOf("N75 solenoid valfi bozuk", "Wastegate sıkışık"), listOf("N75 valfini test edip yenileyin"), listOf("N75 Selenoid")),
            DtcTemplate("P0638", "POWERTRAIN", "Gaz Kelebeği Aktüatör Kontrol Aralık/Performans Bank 1", "Throttle Actuator Control Range/Performance B1", "HIGH", listOf("Kelebek gövdesi çok pis", "Kardan dişlisi aşınmış"), listOf("Kelebek temizliği yapın", "Kelebek adaptasyon sıfırlayın"), listOf("Gaz Kelebeği")),
            DtcTemplate("P1296", "POWERTRAIN", "VAG: Soğutma Suyu Sıcaklığı Sensörü Arızası (G83)", "VAG: Engine Coolant Temp Sensor Fault (G83)", "HIGH", listOf("Hararet sensör direnci bozuk"), listOf("G83 sensörünü değiştirin"), listOf("Sıcaklık Sensörü G83")),
            DtcTemplate("P1302", "POWERTRAIN", "VAG: Misfire Silindir 1 Egzoz Sıcaklığı Çok Yüksek", "VAG: Cylinder 1 Misfire Exhaust Gas Temp Too High", "HIGH", listOf("Enjektör aşırı işeme yapıyor"), listOf("Enjektör kalibrasyonu", "Bobin değiştirme"), listOf("Egzoz Sıcaklık Sensörü")),
            DtcTemplate("P1483", "POWERTRAIN", "VAG: Turbo Basınç Sınırı Aşıldı", "VAG: Overboost Pressure Limit Exceeded", "HIGH", listOf("Yazılım hatası", "Vakum hattı kaçak"), listOf("Vakum hortumlarını yenileyin"), listOf("Turbo Kompresör")),
            DtcTemplate("16486", "POWERTRAIN", "VAG: MAF Sensörü Sinyal Zayıf", "VAG: Mass Air Flow Sensor Signal Too Low", "HIGH", listOf("Filtre açık kalmış", "MAF kirlenmiş"), listOf("MAF sensör temizliği"), listOf("MAF Akış Ölçer")),
            DtcTemplate("16684", "POWERTRAIN", "VAG: Çoklu Ateşleme Kaçırma Tespit Edildi", "VAG: Random Misfire Detected", "HIGH", listOf("Buji ömrünü doldurmuş", "Kötü yakıt"), listOf("Buji setini yenileyin", "Yakıt tazeleyin"), listOf("Bujiler")),
            DtcTemplate("17748", "POWERTRAIN", "VAG: EGR Sistemi Yetersiz Akış Tespit Edildi", "VAG: EGR System Insufficient Flow Detected", "MEDIUM", listOf("EGR supabı tıkalı"), listOf("EGR valfini temizleyin"), listOf("EGR Valfi"))
        )

        val vwEcmSystemIds = listOf(97, 106)
        for (sysId in vwEcmSystemIds) {
            for (tpl in vwEcmTemplates) {
                troubleCodes.add(TroubleCode(
                    id = dtcIdCounter++,
                    systemId = sysId,
                    code = tpl.code,
                    codeType = tpl.type,
                    descriptionTr = tpl.descTr,
                    descriptionEn = tpl.descEn,
                    severity = tpl.severity,
                    possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                    possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                    affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
                ))
            }
        }

        // MERCEDES ÖZEL DTC: C-Class (73), E-Class (81), GLC (89)
        val mbEcmTemplates = listOf(
            DtcTemplate("P0014", "POWERTRAIN", "Eksantrik Mili \"B\" Zamanlaması Aşırı İleri (Bank 1)", "Camshaft Position \"B\" - Over-Advanced (Bank 1)", "HIGH", listOf("Eksantrik mili mıknatısı takılı kalmış"), listOf("Eksantrik mil ayar magnetini yenileyin"), listOf("Mıknatıs Solenoidi")),
            DtcTemplate("P0017", "POWERTRAIN", "Krank/Eksantrik Mili Uyumsuzluğu Bank 1 Sensör B", "Crankshaft-Camshaft Correlation B1 Sensor B", "HIGH", listOf("Zamanlama zinciri uzaması", "Krank sensör bozulması"), listOf("Zincir seti değişimi", "Sörsör değişimi"), listOf("Sente Seti")),
            DtcTemplate("P0706", "POWERTRAIN", "Şanzıman Aralık Sensörü Devresi Performans", "Transmission Range Sensor Circuit Performance", "HIGH", listOf("ISM modülü vites konumu algılamıyor"), listOf("Akıllı seçici modül (ISM) adaptasyonu yapın"), listOf("ISM Vites Seçici")),
            DtcTemplate("P0732", "POWERTRAIN", "Vites 2 Oran Yanlış", "Gear 2 Incorrect Ratio", "HIGH", listOf("Şanzıman kavrama kaydırması", "Solenoid arızası"), listOf("Valf bloğu testi", "Kavrama kiti değişimi"), listOf("9G-Tronic Kavrama")),
            DtcTemplate("C100F", "CHASSIS", "ESP: Tekerlek hız sensörü offset hatası", "ESP: Wheel Speed Sensor Offset Error", "HIGH", listOf("Sensör manyetik okuyucusunda kir", "Sapma"), listOf("Porya bilyesi halkası temizleme"), listOf("Tekerlek Hız Alıcısı")),
            DtcTemplate("C1031", "CHASSIS", "ESP: Sol ön tekerlek hız sensörü sinyal hattı", "ESP: Left Front Wheel Speed Sensor Signal", "HIGH", listOf("Kablo kesilmesi"), listOf("Sol ön kabloyu yenileyin"), listOf("ESP Sensör Kablosu"))
        )

        val mbEcmSystemIds = listOf(73, 81, 89)
        for (sysId in mbEcmSystemIds) {
            for (tpl in mbEcmTemplates) {
                troubleCodes.add(TroubleCode(
                    id = dtcIdCounter++,
                    systemId = sysId,
                    code = tpl.code,
                    codeType = tpl.type,
                    descriptionTr = tpl.descTr,
                    descriptionEn = tpl.descEn,
                    severity = tpl.severity,
                    possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                    possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                    affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
                ))
            }
        }

        // FORD ÖZEL DTC: Focus (115)
        val fordEcmTemplates = listOf(
            DtcTemplate("P0191", "POWERTRAIN", "Yakıt Sisteminin Basıncı Düşük", "Fuel Rail Pressure Circuit Performance", "HIGH", listOf("Yüksek basınç pompası zorlanıyor"), listOf("Pompayı test edin", "Yakıt filtresi yenileyin"), listOf("FRP Sensör")),
            DtcTemplate("P0193", "POWERTRAIN", "Yakıt Sisteminin Basıncı Yüksek", "Fuel Pressure Regulator Circuit High", "HIGH", listOf("Regülatör sıkışması", "Geri dönüş hattı tıkalı"), listOf("Regülatör testi", "Geri dönüş hortumlarını kontrol edin"), listOf("Yakıt Basınç Regülatörü")),
            DtcTemplate("P0316", "POWERTRAIN", "Motor Çalışma Sırasında Ateşleme Kaçırması", "Misfire Detected On Startup (First 1000 Revolutions)", "HIGH", listOf("İlk marşta kuruyan bujiler", "Kötü yakıt"), listOf("Buji değişimi", "Enjektör temizliği"), listOf("Ateşleme Bujisi")),
            DtcTemplate("P0460", "POWERTRAIN", "Yakıt Seviye Sensörü Devresi", "Fuel Level Sensor Circuit Malfunction", "MEDIUM", listOf("Depo şamandıra direnci bozuk"), listOf("Şamandıra soket temizliği", "Şamandıra değişimi"), listOf("Depo İçi Şamandıra")),
            DtcTemplate("P0607", "POWERTRAIN", "Kontrol Modülü Performansı", "Control Module Performance", "HIGH", listOf("ECU güç hattında parazit"), listOf("Kablo şasi vidasının sıkılması", "Voltaj regülasyon kontrolü"), listOf("ECM Besleme")),
            DtcTemplate("P0627", "POWERTRAIN", "Yakıt Pompası Kontrol Devresi", "Fuel Pump Control Circuit Open", "HIGH", listOf("Pompa rölesi bozuk", "Pompa motoru yanık"), listOf("Pompa rölesini değiştirin", "Depo pompası değişimi"), listOf("Elektrikli Yakıt Pompası")),
            DtcTemplate("P0645", "POWERTRAIN", "A/C Debriyaj Röle Kontrol Devresi", "A/C Clutch Relay Control Circuit", "MEDIUM", listOf("Klima rölesi soket gevşekliği"), listOf("Röle değişimi"), listOf("Klima Debriyaj Rölesi")),
            DtcTemplate("P0720", "POWERTRAIN", "Çıkış Mili Hız Sensörü Devresi", "Output Speed Sensor Circuit Malfunction", "HIGH", listOf("Şanzıman hız sensörü bozuk"), listOf("Sensör direnci tespiti ve sensör değişimi"), listOf("OSS Sürat Sensörü")),
            DtcTemplate("P00BC", "POWERTRAIN", "Kütle veya Hacim Hava Akış (MAF) 'A' Devresi Sınırın Altında / Çok Düşük Sinyal", "Mass or Volume Air Flow 'A' Circuit Range/Performance - Flow Too Low", "HIGH", listOf("MAF sensörü kirli veya bozuk", "Emme manifoldu hortumu patlak/kaçak", "Kablolama hatası"), listOf("Hortumu/kelepçeyi kontrol edip sıkın", "MAF sensörünü sprey ile temizleyin veya yenileyin"), listOf("MAF Sensör")),
            DtcTemplate("P1116-06", "POWERTRAIN", "Motor Soğutma Suyu Sıcaklık (ECT) Sensörü Menzil Dışı", "Engine Coolant Temperature Sensor Out Of Self-Test Range", "MEDIUM", listOf("ECT Sensörü arızalı", "Soğutma suyu seviyesi yetersiz", "Termostat açık sıkışmış"), listOf("ECT sensörünün direncini ölçüp yenileyin", "Soğutma suyunu tamamlayın", "Termostatı test edin"), listOf("ECT Sıcaklık Sensörü"))
        )

        for (tpl in fordEcmTemplates) {
            troubleCodes.add(TroubleCode(
                id = dtcIdCounter++,
                systemId = 115, // Ford Focus ECM
                code = tpl.code,
                codeType = tpl.type,
                descriptionTr = tpl.descTr,
                descriptionEn = tpl.descEn,
                severity = tpl.severity,
                possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
            ))
        }

        // FORD BCM DTC: Focus (119)
        val fordBcmTemplates = listOf(
            DtcTemplate("B1088", "BODY", "LIN Veri Yolu Cihazı H ile İletişim Kayboldu", "Lost Communication With LIN Bus Device H", "HIGH", listOf("LIN hattı kopuk", "Alıcı/verici modülde iç kısa devre", "Akü voltaj dalgalanması"), listOf("Gövde modülü soket pini kontrolü", "LIN devresi voltaj/dalga şekli ölçümü"), listOf("BCM Modül")),
            DtcTemplate("B129C", "BODY", "Kapı Kolu Kapasitif Sensör Arızası", "Door Handle Capacitive Sensor Failure", "MEDIUM", listOf("Anahtarsız giriş kapı sensörü içi nem alma", "Kabloda parazit/kopukluk"), listOf("Kapı kolu sensör soketi kurutulmalı veya kapı kolu yenilenmeli"), listOf("Kapı Kolu Sensör")),
            DtcTemplate("B129D", "BODY", "Kapı Kolu Sinyal Kararsızlığı / Sınır Dışı", "Door Handle Sensor Performance/Incorrect Signal", "MEDIUM", listOf("Kir/oksit tabakası oluşumu", "Yanlış montaj referans kaybı"), listOf("Kapı kolu dış yüzey tazyikli temizlik ve kalibrasyon kontrolü"), listOf("Kapı Kolu Sensör"))
        )

        for (tpl in fordBcmTemplates) {
            troubleCodes.add(TroubleCode(
                id = dtcIdCounter++,
                systemId = 119, // Ford Focus BCM
                code = tpl.code,
                codeType = tpl.type,
                descriptionTr = tpl.descTr,
                descriptionEn = tpl.descEn,
                severity = tpl.severity,
                possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
            ))
        }

        // HYUNDAI/KIA ÖZEL DTC: Tucson (121) / Sportage (129)
        val hyundaiEcmTemplates = listOf(
            DtcTemplate("P0685", "POWERTRAIN", "ECM/PCM Güç Röle Kontrol Devresi", "ECM/PCM Power Relay Control Circuit / Open", "HIGH", listOf("Ana motor rölesi aşınmış"), listOf("Ana güç rölesini yenileyin"), listOf("Ana Güç Rölesi Tr")),
            DtcTemplate("P0697", "POWERTRAIN", "Sensör Referans Voltaj C Devresi Düşük", "Sensor Reference Voltage \"C\" Circuit Low", "HIGH", listOf("Sensör 5V hattında şasiye kısa devre"), listOf("Sırayla sensör soketlerini çekip kısa devreyi arayın"), listOf("5V Sensör Referans Hattı")),
            DtcTemplate("P0850", "POWERTRAIN", "Park/Nötr Konum Anahtarı Giriş Devresi", "Park/Neutral Switch Input Circuit", "MEDIUM", listOf("Vites PNP konum şalteri oksitlenmiş"), listOf("PNP şalterini balata spreyiyle temizleyin"), listOf("PNP Konum Şalteri")),
            DtcTemplate("P1326", "POWERTRAIN", "Vuruntu Sensörü Tespit Menzili", "Knock Sensor Detection Range (Bearing wear)", "HIGH", listOf("Yatak sarması tespiti", "Vuruntu sensör bozulma"), listOf("Krank yataklarını ölçme kontrolü", "Sensör güncelleme"), listOf("Yatak / Vuruntu Sensörü")),
            DtcTemplate("C1200", "CHASSIS", "ABS: Motor rölesi arızası", "ABS: Valve Motor Relay Fault", "HIGH", listOf("ABS hidrolik motor valf röle temassız"), listOf("ABS beyni sigorta kutusu röle değişimi"), listOf("ABS Motor Rölesi")),
            DtcTemplate("C1201", "CHASSIS", "ABS: Motor devresi açık", "ABS: Valve Motor Circuit Open", "HIGH", listOf("ABS modül motor kömürü bitmiş"), listOf("ABS motor kontrol ve revizyon"), listOf("ABS Pompa Motoru")),
            DtcTemplate("U0100", "NETWORK", "CAN: ECM/PCM ile İletişim Kaybı", "Lost Communication with ECM/PCM", "HIGH", listOf("CAN-Bus hattında kopukluk"), listOf("Motor beyni fiş ve besleme kontrolü"), listOf("ECM İletişim Yolu")),
            DtcTemplate("U0101", "NETWORK", "CAN: TCM ile İletişim Kaybı", "Lost Communication with TCM", "HIGH", listOf("Şanzıman beyni CAN hattı hasarı"), listOf("Şanzıman soket pini temassızlık düzeltme"), listOf("TCM Kablolama")),
            DtcTemplate("U0121", "NETWORK", "CAN: ABS Kontrol Modülü ile İletişim Kaybı", "Lost Communication with ABS Control Module", "HIGH", listOf("ABS şasi/artı besleme kopuk"), listOf("ABS sigortasını test et, soketi ölç"), listOf("ABS Beyni Can-BUS")),
            DtcTemplate("U0140", "NETWORK", "CAN: Gövde Kontrol Modülü ile İletişim Kaybı", "Lost Communication with BCM", "HIGH", listOf("BCM modülü güç direnci düşmesi"), listOf("BCM besleme kontrolü"), listOf("BCM CAN")),
            DtcTemplate("U0155", "NETWORK", "CAN: Gösterge Paneli Kontrol Modülü ile İletişim Kaybı", "Lost Communication with IPC", "MEDIUM", listOf("Kadran arkasındaki fiş gevşekliği"), listOf("Kadranı söküp soketi sıkıca oturtun"), listOf("IPC Gösterge Paneli"))
        )

        val hkEcmSystemIds = listOf(121, 129)
        for (sysId in hkEcmSystemIds) {
            for (tpl in hyundaiEcmTemplates) {
                troubleCodes.add(TroubleCode(
                    id = dtcIdCounter++,
                    systemId = sysId,
                    code = tpl.code,
                    codeType = tpl.type,
                    descriptionTr = tpl.descTr,
                    descriptionEn = tpl.descEn,
                    severity = tpl.severity,
                    possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                    possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                    affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
                ))
            }
        }

        // OPEL ÖZEL DTC: Astra-H (137 = ECM, 138 = CIM, 142 = ABS)
        val opelDtcTemplates = listOf(
            DtcTemplate("P0170", "POWERTRAIN", "Yakıt Ayarı Arızası (Bank 1)", "Fuel Trim Malfunction (Bank 1)", "HIGH", listOf("Hava kaçakları", "Oksijen sensörü hatalı lambası", "Enjektör tıkanıklığı"), listOf("MAF sensörünü ve hortumlarını temizleyin", "Oksijen sensörünü yenileyin", "Yakıt filtresini test edin"), listOf("Oksijen Sensörü", "Enjektör")),
            DtcTemplate("U2103", "NETWORK", "CAN-Bus Düğüm Noktası İletişim Arızası", "CAN-Bus Node No Communication Fault", "HIGH", listOf("CIM modülünde gevşek soket", "CAN veri yolu hattı kısa devre"), listOf("CIM soket pinlerini kontrol edin", "Aküyü söküp 5 dk bekleyin"), listOf("CIM Modülü")),
            DtcTemplate("U2105", "NETWORK", "CAN-Bus ECM İletişim Hatası", "CAN-Bus ECM Communication Lost", "HIGH", listOf("Hızlı CAN veri hattı hasarı", "Motor kontrol modülü güç kesintisi"), listOf("ECM besleme voltajını ve şasi kablosunu temizleyin", "CAN empedansını ölçün (60 Ohm)"), listOf("CAN-Bus Hattı", "CIM Beyni")),
            DtcTemplate("U2108", "NETWORK", "CAN-Bus ABS İletişim Hatası", "CAN-Bus ABS Communication Lost", "HIGH", listOf("ABS beyni soketinde su sızması", "ABS sigortası yanmış"), listOf("ABS beyni fişini çekip kurutun ve temizleyin", "ABS besleme kablosu direnç ölçümü yapın"), listOf("ABS Soketi", "CIM Modülü")),
            DtcTemplate("P1703-08", "CHASSIS", "Fren Pedalı Anahtarı Sinyal Frekans / Sınır Dışı Arızası", "Brake Switch Out Of Self-Test Range", "HIGH", listOf("Fren pedal müşürü (switch) ayarsız veya bozuk", "ABS beyni fren ışığı sinyal uyuşmazlığı"), listOf("Fren müşürünü ayarlayın veya yenileyin", "Arka fren lamba ampullerini veya LED hattını kontrol edin"), listOf("Fren Müşürü", "ABS/ESP Modülü"))
        )
        for (tpl in opelDtcTemplates) {
            troubleCodes.add(TroubleCode(
                id = dtcIdCounter++,
                systemId = when (tpl.code) {
                    "U2103" -> 138
                    "P1703-08" -> 142
                    else -> 137
                },
                code = tpl.code,
                codeType = tpl.type,
                descriptionTr = tpl.descTr,
                descriptionEn = tpl.descEn,
                severity = tpl.severity,
                possibleCauses = "[\"" + tpl.causes.joinToString("\",\"") + "\"]",
                possibleFixes = "[\"" + tpl.fixes.joinToString("\",\"") + "\"]",
                affectedComponents = "[\"" + tpl.components.joinToString("\",\"") + "\"]"
            ))
        }

        dtcDao.insertAll(troubleCodes)

        // ===== GÖREV 4: EKSİK PID'LERİ TAMAMLA (28→50) =====
        val pids = listOf(
            LivePidDefinition(1, "010C", "Motor Devri", "Engine RPM", "rpm", "((A*256)+B)/4", 0f, 8000f, "01", null, true),
            LivePidDefinition(2, "010D", "Araç Hızı", "Vehicle Speed", "km/h", "A", 0f, 255f, "01", null, true),
            LivePidDefinition(3, "0105", "Soğutma Sıvısı Harareti", "Engine Coolant Temp", "°C", "A-40", -40f, 215f, "01", null, true),
            LivePidDefinition(4, "010F", "Emiş Havası Harareti", "Intake Air Temp", "°C", "A-40", -40f, 215f, "01", null, false),
            LivePidDefinition(5, "0104", "Hesaplanan Motor Yükü", "Calculated Engine Load", "%", "A*100/255", 0f, 100f, "01", null, true),
            LivePidDefinition(6, "0111", "Gaz Kelebeği Konumu", "Absolute Throttle Position", "%", "A*100/255", 0f, 100f, "01", null, true),
            LivePidDefinition(7, "012F", "Yakıt Seviyesi Göstergesi", "Fuel Level Input", "%", "A*100/255", 0f, 100f, "01", null, false),
            LivePidDefinition(8, "0142", "Kontrol Modülü Voltajı", "Control Module Voltage", "V", "((A*256)+B)/1000", 0f, 65f, "01", null, true),
            LivePidDefinition(9, "010B", "Emme Manifold Basıncı", "Intake Manifold Abs Pressure", "kPa", "A", 0f, 255f, "01", null, false),
            LivePidDefinition(10, "010A", "Yakıt Ray Basıncı", "Fuel Pressure", "kPa", "A*3", 0f, 765f, "01", null, false),
            LivePidDefinition(11, "0106", "Kısa Dönem Yakıt Trim - Bank 1", "Short Term Fuel Trim - Bank 1", "%", "(A-128)*100/128", -100f, 99.2f, "01", null, false),
            LivePidDefinition(12, "0107", "Uzun Dönem Yakıt Trim - Bank 1", "Long Term Fuel Trim - Bank 1", "%", "(A-128)*100/128", -100f, 99.2f, "01", null, false),
            LivePidDefinition(13, "0110", "MAF Hava Akış Oranı", "MAF Air Flow Rate", "g/s", "((A*256)+B)/100", 0f, 655f, "01", null, true),
            LivePidDefinition(14, "0121", "Mesafe MIL Lambası Etkinken", "Distance Travelled with MIL on", "km", "(A*256)+B", 0f, 65535f, "01", null, false),
            LivePidDefinition(15, "015C", "Motor Yağ Sıcaklığı", "Engine Oil Temperature", "°C", "A-40", -40f, 215f, "01", null, false),
            LivePidDefinition(16, "015E", "Motor Yakıt Akış Hızı", "Engine Fuel Rate", "L/h", "((A*256)+B)/20", 0f, 3276f, "01", null, false),
            LivePidDefinition(17, "0161", "Gereken Motor Tork Yüzdesi", "Engine Demanded Torque", "Nm", "A-125", -125f, 130f, "01", null, false),
            LivePidDefinition(18, "0133", "Atmosferik Hava Basıncı", "Barometric Pressure", "kPa", "A", 0f, 255f, "01", null, false),
            LivePidDefinition(19, "0143", "Mutlak Motor Yükü", "Absolute Load Value", "%", "((A*256)+B)*100/65535", 0f, 100f, "01", null, false),
            LivePidDefinition(20, "0131", "Oksijen Sensör Voltajı B1S1", "O2 Sensor Voltage B1S1", "V", "A/200", 0f, 1.275f, "01", null, true),
            LivePidDefinition(21, "014D", "Motor Çalışırken MIL Süresi", "Time Run with MIL on", "dak", "(A*256)+B", 0f, 65535f, "01", null, false),
            LivePidDefinition(22, "010E", "Ateşleme Açısı Avansı", "Ignition Timing Advance Cyl 1", "°", "A/2-64", -64f, 63.5f, "01", null, false),
            LivePidDefinition(23, "0113", "Oksijen Sensör Konumları", "Oxygen Sensors Present", "bit", "A", 0f, 255f, "01", null, false),
            LivePidDefinition(24, "0149", "Mevcut Yakıt Tipi", "Fuel Type Mode", "-", "A", 0f, 255f, "01", null, false),
            LivePidDefinition(25, "014E", "Sıfırlama Sonrası Çalışma Süresi", "Time Since Trouble Codes Cleared", "sn", "(A*256)+B", 0f, 65535f, "01", null, false),
            LivePidDefinition(26, "2101", "Toyota Servis PID Paketi 1", "Toyota Service PID 1", "-", "A", 0f, 255f, "21", 19, false),
            LivePidDefinition(27, "2103", "Auris Şanzıman Sıcaklığı (Toyota)", "Auris Transmission Oil Temp", "°C", "A-40", -40f, 215f, "21", 19, false),
            LivePidDefinition(28, "2105", "Auris VVT-i Supap Açısı (Toyota)", "Auris Valve Timing Angle", "°", "A/2-64", -64f, 63.5f, "21", 19, false),
            // NEW PIDs (29 to 50)
            LivePidDefinition(29, "0146", "Mutlak Gaz Kelebeği Konumu B", "Absolute Throttle Position B", "%", "A*100/255", 0f, 100f, "01", null, false),
            LivePidDefinition(30, "014C", "Komut Edilen Gaz Kelebeği Konumu", "Commanded Throttle Actuator Position", "%", "A*100/255", 0f, 100f, "01", null, false),
            LivePidDefinition(31, "014F", "Maksimum Değerler (Hava-Yakıt Oranı)", "Max Values (Air-Fuel Ratio)", "-", "A", 0f, 1000f, "01", null, false),
            LivePidDefinition(32, "0151", "Mevcut Yakıt Tipi (Standart)", "Fuel Type Standard", "-", "A", 0f, 255f, "01", null, false),
            LivePidDefinition(33, "0152", "Etanol Yakıt % Oranı", "Ethanol Fuel Percent", "%", "A*100/255", 0f, 100f, "01", null, false),
            LivePidDefinition(34, "015A", "Bağıl Gaz Kelebeği Konumu", "Relative Throttle Position", "%", "A*100/255", 0f, 100f, "01", null, false),
            LivePidDefinition(35, "015B", "Mutlak Gaz Kelebeği Konumu C", "Absolute Throttle Position C", "%", "A*100/255", 0f, 100f, "01", null, false),
            LivePidDefinition(36, "015D", "Motor Yağı Sıcaklığı", "Engine Oil Temp Out", "°C", "A-40", -40f, 215f, "01", null, false),
            LivePidDefinition(37, "015F", "Motor Yakıt Tüketim Hızı", "Engine Fuel Consumption", "L/h", "((A*256)+B)/20", 0f, 3276f, "01", null, false),
            LivePidDefinition(38, "0160", "Sürücü Talep Tork Değeri", "Driver Demanded Engine Torque", "Nm", "A-125", -125f, 130f, "01", null, false),
            LivePidDefinition(39, "0162", "Şanzıman Gerçek Tork Oranı", "Transmission Actual Torque", "Nm", "A-125", -125f, 130f, "01", null, false),
            LivePidDefinition(40, "0163", "Şanzıman Sürtünme Torku", "Transmission Friction Torque", "Nm", "A-125", -125f, 130f, "01", null, false),
            LivePidDefinition(41, "016C", "Sürücü Gaz Pedal Talep %", "Driver Demand Percent", "%", "A*100/255", 0f, 100f, "01", null, false),
            LivePidDefinition(42, "016E", "Emme Sıcaklığı B1 S1", "Intake Temp B1S1", "°C", "A-40", -40f, 215f, "01", null, false),
            LivePidDefinition(43, "0173", "Egzoz Geri Basıncı", "Exhaust Pressure", "kPa", "((A*256)+B)/10", 0f, 6553f, "01", null, false),
            LivePidDefinition(44, "0174", "Turbo Giriş Manifold Basıncı A", "Turbo Intake Pressure A", "kPa", "((A*256)+B)/10", 0f, 6553f, "01", null, false),
            LivePidDefinition(45, "0181", "Emme Manifoldu Gerçek Basıncı B", "Intake Manifold Press B", "kPa", "A", 0f, 255f, "01", null, false),
            LivePidDefinition(46, "019D", "NOx Sensörü Ölçülen Değer B1", "NOx Sensor Corrected Value B1", "mg/km", "((A*256)+B)", 0f, 65535f, "01", null, false),
            LivePidDefinition(47, "0201", "DTC Tetikleyen Freeze Frame PID", "DTC Triggered PID (Mode 02)", "hex", "A", 0f, 255f, "02", null, false),
            LivePidDefinition(48, "2101", "Toyota Servis Paketi 1 (RPM+Hız+Derece)", "Toyota Servis Paketi 1 (RPM+Hız+Derece)", "-", "A", 0f, 255f, "21", 19, false),
            LivePidDefinition(49, "2103", "Şanzıman Yağ Sıcaklığı (Toyota Özel)", "Transmission Oil Temp (Toyota)", "°C", "A-40", -40f, 215f, "21", 19, false),
            LivePidDefinition(50, "2105", "VVT-i Açısı (Toyota Özel)", "VVT-i Angle (Toyota)", "derece", "A-128", -128f, 127f, "21", 19, false),
            LivePidDefinition(51, "01F3", "Toplam Ateşleme Kaçırma Sayısı", "Total Misfire Count", "Adet", "C", 0f, 255f, "01", 19, false),
            LivePidDefinition(52, "2107", "Silindir 1 Ateşleme Kaçırma Sayısı", "Cylinder #1 Misfire Count", "Adet", "C", 0f, 255f, "21", 19, false),
            LivePidDefinition(53, "2108", "Silindir 2 Ateşleme Kaçırma Sayısı", "Cylinder #2 Misfire Count", "Adet", "C", 0f, 255f, "21", 19, false),
            LivePidDefinition(54, "2109", "Silindir 3 Ateşleme Kaçırma Sayısı", "Cylinder #3 Misfire Count", "Adet", "C", 0f, 255f, "21", 19, false),
            LivePidDefinition(55, "210A", "Silindir 4 Ateşleme Kaçırma Sayısı", "Cylinder #4 Misfire Count", "Adet", "C", 0f, 255f, "21", 19, false),
            LivePidDefinition(56, "21B2", "Ateşleme Avansı Geciktirme (Vuruntu)", "Knock Retard", "°", "(A*256+B)*0.03125-64", -64f, 63.97f, "21", 19, false)
        )
        pidDao.insertAll(pids)

        // ===== GÖREV 5: MARKA BAZLI ÖZEL FONKSİYONLAR EKLE =====
        val specFunctions = listOf(
            SpecialFunction(1, 19, null, "OIL_RESET", "Yağ Servisi Sıfırlama (Lexus/Toyota)", "Motor yağ ömrü ve servis sayacını servis turlarından sonra başlangıç değerine çeker.", "Sadece yağ değişiminden sonra çalıştırın kontak açık motor kapalı olmalıdır.", "[\"ATSH 7E0\",\"3E00\",\"1003\",\"2C0281FF00\"]", true, false, 12.1f),
            SpecialFunction(2, 1, null, "DPF_REGEN", "Aktif DPF Kurum Yakma Rejenerasyonu (VW)", "Dizel Partikül Filtresinde biriken kurumları yüksek sıcaklık tahrikiyle egzoz borusunda yakar.", "⚠️ DİKKAT: Egzoz aşırı ısınacaktır, aracı açık alanda sabit tutun yanıcı madde olmasın.", "[\"ATSH 7E0\",\"1003\",\"2706C10000\",\"2706C20001\"]", false, true, 12.1f),
            SpecialFunction(3, null, null, "EPB_OPEN", "Elektronik Park Freni Kaliperi Servis Modu Aç", "Elektrikli fren kaliper motorunu son konumuna geri çekerek balata değişimine emniyet tanır.", "Fren pedalına basmayın, tekerleklerin arkasına takoz koyduğunuzdan emin olun.", "[\"ATSH 760\",\"1003\",\"2C030200FF00\"]", true, false, 12.2f),
            SpecialFunction(4, null, null, "EPB_CLOSE", "Elektronik Park Fren Kaliperi Kapat ve Kalibre Et", "Servis sonrası park fren kaliper motorunu sıkarak fren boşluk payını otomatik tanımlar.", "Kalibrasyon başlamadan önce yeni balataların takıldığından ve yerine oturduğundan emin olun.", "[\"ATSH 760\",\"1003\",\"2C030200FF01\"]", true, false, 12.2f),
            SpecialFunction(5, null, null, "BMS_RESET", "Akü BMS Kayıt ve Eşleştirme (Universal AGM)", "Yeni takılan akünün kapasite ve kimyasını şarj kontrol beynine (BMS) kaydederek ömrünü korur.", "Sadece yeni bir akü takıldığında bu kaydı oluşturun. Eski aküyle çalıştırmak ömrünü kısaltır.", "[\"ATSH 6F1\",\"1003\",\"2E020180\",\"2E020300000000\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(6, 19, null, "SAS_RESET", "Direksiyon Açı Sensörü Sıfır Kalibrasyonu", "Direksiyon açısı referans noktasını düz konuma senkronize eder. ESP ve ADAS için mecburidir.", "Aracı tamamen düz bir zemine park edin ve direksiyonu milimetrik olarak ortalayarak sabitleyin.", "[\"ATSH 7B0\",\"1003\",\"2F100303 00000000\",\"2F100300 00000000\"]", true, false, 12.1f),
            SpecialFunction(7, null, null, "TPMS_RESET", "Lastik Basınç Alıcı Sensör Yeniden Öğrenme", "TPMS kontrolörüne sensör RF ID'lerini veya taban basınç değerini tanıtır.", "İşleme başlamadan önce tüm lastikleri fabrikasyon bar değerinde şişirdiğinizi teyit edin.", "[\"ATSH 7A0\",\"1003\",\"2F30030300\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(8, 19, null, "THROTTLE_ADAPT", "Elektronik Gaz Kelebeği Adaptasyon Sıfırlama", "Gaz kelebeği potansiyometre alt ve üst tırnak sınır açı değerlerini yeniden ölçer.", "Gaz pedalına dokunmayın, bogaz kelebeği temizliği sonrasında rölanti dalgalanmasını önler.", "[\"ATSH 7E0\",\"04\",\"3E00\",\"2C038100FF00\"]", true, false, 12.1f),
            SpecialFunction(9, 19, null, "TRANS_ADAPT", "Şanzıman Solenoid ve Kavrama Alıştırması", "Sarsıntılı vites geçişlerini gidermek için vites değiştirme debriyaj dolum zamanlarını sıfırlar.", "⚠️ Şanzıman yağı sıcaklığı 50-80°C arasında olmalı, şanzıman Park (P) konumunda beklemelidir.", "[\"ATSH 7E1\",\"1003\",\"2C039000FF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(10, 4, null, "INJ_CODING", "Dizel Enjektör Kodlama Sınıfı Değişimi", "Enjektör üzerindeki 7 haneli kalibrasyon hex değerini motor beynine yazarak silindir vuruntusunu keser.", "Sadece yeni veya revizyonlu enjektör takıldıysa bu kodu yazın. Yanlış yazılması duman yaptırır.", "[\"ATSH 7E0\",\"1003\",\"2C0140XXXXXXXX\"]", true, false, 12.1f),
            SpecialFunction(11, null, null, "HEADLIGHT_CALIB", "ADAS Far Seviyesi ve Geometri Kalibrasyonu", "Aks sensörleri ve far seviye motorunun sıfır referans yüksekliğini belirleyerek göz almasını önler.", "Araç boş olmalı, düz zeminde bulunmalı ve manuel el freni indirilmiş olmalıdır.", "[\"ATSH 742\",\"1003\",\"31010208\",\"31020208\"]", true, false, 12.1f),
            SpecialFunction(12, 19, null, "INJECTOR_KILL_1", "Silindir 1 Enjektör Devre Dışı Bırakma Testi", "Silindir 1 enjektör tetiğini manuel keserek silindirler arası güç ve kompresyon dengesini analiz eder.", "Motor rölantide çalışırken uygulanacaktır. Motor sarsıntılı çalışmaya başlayabilir.", "[\"ATSH 7E0\",\"2F0230 FF 08 00 00 00 00 00 01\"]", false, true, 12.1f),
            SpecialFunction(13, 1, null, "COOLANT_BLEED", "Elektrikli Devirdaim Soğum Soğutma Sistemi Hava Alma", "Soğutma sıvısı değişimi sonrası elektrikli pompayı 10 dakika tahrik ederek hava kabarcıklarını atar.", "Genleşme kabı kapağı açık olmalı ve kalorifer sistemi maksimum ısıtma derecesine set edilmelidir.", "[\"ATSH 7E0\",\"1003\",\"31013E0000\",\"31023E00\"]", true, false, 12.1f),
            SpecialFunction(14, null, null, "IDLE_ADAPT", "Rölanti Devri İstikrar Adaptasyon Sıfırlama", "Emiş havası kaçakları giderme veya bogaz kelebeği temizliği sonrası rölanti referansını sıfırlar.", "Motor tamamen sıcaklık işletim seviyesinde (ECT > 80°C) ve tüm elektrikli tüketiciler kapalı olmalı.", "[\"ATSH 7E0\",\"04\",\"3E00\",\"2C036500FF00\"]", true, false, 12.1f),
            
            // --- NEW TOYOTA FUNCTIONS (id 15 to 20) ---
            SpecialFunction(15, 19, null, "THROTTLE_ADAPT_NEW", "Gaz Kelebeği Adaptasyonu (Toyota)", "Gaz Kelebeği potansiyometresi üst tırnak sınır açı değerlerini kalibre eder.", "Pedallara dokunulmamalıdır. Kontak açık motor kapalı olmalıdır.", "[\"ATSH 7E0\",\"1003\",\"3E00\",\"2C038100FF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(16, 19, null, "INJECTOR_KILL_1_NEW", "Enjektör Kesme Testi Silindir 1 (Toyota)", "Silindir 1 tetiğini geçici olarak keserek sarsıntıyı ve silindir sağlığını test eder.", "Motor çalışırken yapılır. Ateşleme kaçırması normaldir.", "[\"ATSH 7E0\",\"1003\",\"2F0230FF080000000001\",\"1001\"]", false, true, 12.1f),
            SpecialFunction(17, 19, null, "INJECTOR_KILL_2", "Enjektör Kesme Testi Silindir 2", "Silindir 2 tetiğini geçici olarak keserek sarsıntıyı test eder.", "Sadece motor çalışırken uygulanır.", "[\"ATSH 7E0\",\"1003\",\"2F0230FF080000000002\",\"1001\"]", false, true, 12.1f),
            SpecialFunction(18, 19, null, "INJECTOR_KILL_3", "Enjektör Kesme Testi Silindir 3", "Silindir 3 tetiğini geçici olarak keserek sarsıntıyı test eder.", "Sadece motor çalışırken uygulanır.", "[\"ATSH 7E0\",\"1003\",\"2F0230FF080000000004\",\"1001\"]", false, true, 12.1f),
            SpecialFunction(19, 19, null, "INJECTOR_KILL_4", "Enjektör Kesme Testi Silindir 4", "Silindir 4 tetiğini geçici olarak keserek sarsıntıyı test eder.", "Sadece motor çalışırken uygulanır.", "[\"ATSH 7E0\",\"1003\",\"2F0230FF080000000008\",\"1001\"]", false, true, 12.1f),
            SpecialFunction(20, 19, null, "COOLANT_BLEED_TOYOTA", "Soğutma Sistemi Hava Tahliyesi (Toyota)", "Hibrid inverter veya motor su hattındaki hava tahliye motorunu tetikler.", "Motor rölantide çalıştırılırken yürütülmelidir.", "[\"ATSH 7E0\",\"1003\",\"2F8E02030000\",\"1001\"]", false, true, 12.1f),

            // --- BMW / MINI (id 21 to 24) ---
            SpecialFunction(21, 2, null, "OIL_RESET_BMW", "Yağ Servisi Sıfırlama (BMW)", "Gösterge panelindeki servis periyodunu sıfırlar.", "Kontak Açık, Motor Kapalı.", "[\"ATSH 12\",\"1003\",\"27 01\",\"27 02{seed_key}\",\"2C04FFFF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(22, 2, null, "VANOS_ADAPT", "VANOS Adaptasyon Sıfırlama (BMW)", "Değişken zamanlama limit değerlerini fabrika verilerine sıfırlar.", "Kontak Açık, Motor Kapalı.", "[\"ATSH 12\",\"1003\",\"2C01CF0000\"]", true, false, 12.1f),
            SpecialFunction(23, 2, null, "SAS_RESET_BMW", "Direksiyon Açısı Sıfırlama (BMW)", "Direksiyon açı sıfır referansını kalibre eder.", "Direksiyon tam ortada olmalı.", "[\"ATSH 60\",\"1003\",\"2F100303 00000000\",\"2F100300 00000000\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(24, 2, null, "DSC_RESET", "DSC (ABS/Dinamik Stabilite) Sıfırlama (BMW)", "Fren hidrolik basınç ve stabilite sensör değerlerini sıfırlar.", "Araç düz zemin üzerinde durmalıdır.", "[\"ATSH 19\",\"1003\",\"2C030400FF00\"]", true, false, 12.1f),

            // --- MERCEDES-BENZ (id 25 to 27) ---
            SpecialFunction(25, 3, null, "OIL_RESET_MB", "Bakım Servis Sıfırlama (Mercedes)", "Assyst Plus servis bakım zamanlayıcısını yeniler.", "Kontak Açık, Motor Kapalı.", "[\"ATSH 7E0\",\"1003\",\"2C030400FF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(26, 3, null, "EZS_ADAPT", "Elektronik Ateşleme Kilidi Adaptasyon (Mercedes)", "Ateşlenme komut modülü (EIS/EZS) ile beyni senkronize eder.", "Sadece yeni modül eşleştirmesinde kullanılır.", "[\"ATSH 7E0\",\"1010 03\",\"27 05\",\"27 06{key}\",\"31 01 EB 00\"]", true, false, 12.1f),
            SpecialFunction(27, 3, null, "ABC_RESET", "ABC Süspansiyon Sıfırlama (Mercedes S/E Class)", "Aktif Gövde Kontrolü hidropnömatik süspansiyon sıfır noktasını kalibre eder.", "Araç üzerinde yük bulunmamalıdır.", "[\"ATSH 7B0\",\"1003\",\"2C039000FF00\",\"1001\"]", true, false, 12.1f),

            // --- VW / AUDI / SKODA / SEAT (id 28 to 31) ---
            SpecialFunction(28, 1, null, "OIL_RESET_VW", "Yağ Servisi Sıfırlama (VW/Audi)", "Göstergedeki periyodik servis hatırlatıcı kodunu siler.", "Kontak Açık.", "[\"ATSH 7E0\",\"1003\",\"3B0900000000\"]", true, false, 12.1f),
            SpecialFunction(29, 1, null, "DPF_REGEN_VW", "DPF Rejenerasyon (VW/Audi Dizel)", "Egzoz hattını ısıtarak partikül filtresindeki kurumları temizler.", "Yüksek sıcaklık oluşacaktır, yanıcı maddelerden uzak durun.", "[\"ATSH 7E0\",\"1003\",\"2706C10000\",\"2706C20001\"]", false, true, 12.1f),
            SpecialFunction(30, 1, null, "THROTTLE_ADAPT_VW", "Gaz Kelebeği Temel Ayarı (VW/Audi)", "Boğaz kelebeği kelebek açıklığı sıfır hatlarını kalibre eder.", "Kontak Açık, Motor Kapalı.", "[\"ATSH 7E0\",\"1003\",\"2C038100FF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(31, 4, null, "OIL_RESET_AUDI", "Yağ Servisi Sıfırlama (Audi)", "MMI üzerindeki esnek bakım aralığı verilerini resetler.", "MMI sıfırlaması sağlar.", "[\"ATSH 7E0\",\"1003\",\"3B0900000000\"]", true, false, 12.1f),

            // --- FORD (id 32 to 33) ---
            SpecialFunction(32, 52, null, "OIL_RESET_FORD", "Yağ Ömrü Sıfırlama (Ford)", "Gövde içi PCM yağ izleme yüzdesini %100 yapar.", "Kontak Açık.", "[\"ATSH 7E0\",\"1003\",\"2C0281FF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(33, 52, null, "PATS_RESET", "PATS İmmobilizer Sıfırlama (Ford)", "Pasif hırsızlık sistem immobilizer anahtar kayıtlarını sıfırlar.", "PIN hesaplaması gerekir.", "[\"ATSH 726\",\"1003\",\"27 01\",\"27 02{key}\",\"2D 0200\"]", true, false, 12.1f),

            // --- HYUNDAI / KIA (id 34 to 36) ---
            SpecialFunction(34, 29, null, "OIL_RESET_HYUNDAI", "Yağ Servisi Sıfırlama (Hyundai)", "Servis zaman sayacını ve kilometre sınırını sıfırlar.", "Geniş servis sıfırlama.", "[\"ATSH 7E0\",\"1003\",\"2C0281FF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(35, 30, null, "OIL_RESET_KIA", "Yağ Servisi Sıfırlama (Kia)", "Kia dijital gösterge panelindeki bakım süresini sıfırlar.", "Servis sıfırlama.", "[\"ATSH 7E0\",\"1003\",\"2C0281FF00\",\"1001\"]", true, false, 12.1f),
            SpecialFunction(36, 29, null, "TPMS_RESET_HYUNDAI", "TPMS Sensör Öğrenme (Hyundai)", "Yeni lastik basınç RF sensör kimliklerini alıcıya kodlar.", "Sensör frekans testi tetiklenir.", "[\"ATSH 7A1\",\"1003\",\"2F30030300\",\"1001\"]", true, false, 12.1f)
        )
        specialDao.insertAll(specFunctions)

        context?.let { ctx ->
            try {
                Log.d("DatabaseSeeder", "Dinamik araç ekleme klasör yapısı taranıyor..")
                VehicleAssetLoader.loadAssetsVehicles(ctx, db)
            } catch (e: Exception) {
                Log.e("DatabaseSeeder", "Dinamik araç yükleme başarısız", e)
            }
        }

        Log.d("DatabaseSeeder", "SQLite OBD2 Araç Veritabanı Seed Edildi! Toplam 50 marka, 16 model, 137 ECU, 200+ DTC, 50 PID ve 36 Servis Reset Tanımı yazıldı.")
    }
}

data class DtcTemplate(
    val code: String,
    val type: String,
    val descTr: String,
    val descEn: String,
    val severity: String,
    val causes: List<String>,
    val fixes: List<String>,
    val components: List<String>
)
