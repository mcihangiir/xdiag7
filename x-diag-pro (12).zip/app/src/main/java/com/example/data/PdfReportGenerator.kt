package com.example.data

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Base64
import android.util.Log
import androidx.core.content.FileProvider
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfReportGenerator(private val context: Context) {

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    fun generateReport(report: DiagnosticReport): Uri {
        val pdfDocument = PdfDocument()
        // Page Configuration (A4 Size: 595 x 842 points)
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Configuration of Paints
        val paintTitle = Paint().apply {
            color = Color.parseColor("#CC0000") // MatcoRed Primary
            textSize = 24f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val paintSubtitle = Paint().apply {
            color = Color.BLACK
            textSize = 14f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val paintText = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isAntiAlias = true
        }

        val paintTextBold = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val paintGray = Paint().apply {
            color = Color.DKGRAY
            textSize = 9f
            isAntiAlias = true
        }

        val paintBorder = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val paintFillHeader = Paint().apply {
            color = Color.parseColor("#F5F5F5")
            style = Paint.Style.FILL
        }

        // 1. Draw Brand Header
        canvas.drawText("X-DIAG PRO", 40f, 60f, paintTitle)
        canvas.drawText("PROFESYONEL ARAÇ DIŞ DIAGNOSTİK RAPORU", 40f, 85f, paintSubtitle)
        canvas.drawLine(40f, 95f, 555f, 95f, paintBorder)

        // 2. Metadata Columns (Left & Right Column)
        val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
        val formattedDate = dateFormat.format(Date(report.timestamp))

        canvas.drawText("ARAÇ BİLGİLERİ", 40f, 120f, paintTextBold)
        canvas.drawText("VIN (Şasi No):  ${report.vehicleVin}", 40f, 140f, paintText)
        canvas.drawText("Marka / Model: ${report.vehicleName}", 40f, 155f, paintText)
        canvas.drawText("Üretim Yılı:       ${report.vehicleYear}", 40f, 170f, paintText)

        canvas.drawText("TEST GERÇEKLEŞTİRME", 320f, 120f, paintTextBold)
        canvas.drawText("Operatör:            ${report.clientName}", 320f, 140f, paintText)
        canvas.drawText("Tarih / Saat:       $formattedDate", 320f, 155f, paintText)
        canvas.drawText("Konnektör Model: Smart OBD2 ELM327", 320f, 170f, paintText)

        canvas.drawLine(40f, 185f, 555f, 185f, paintBorder)

        // 3. Health Indicator Arc (Draw beautiful circle representation of vehicle health)
        val score = report.healthPercentage
        val scoreColor = when {
            score >= 80 -> Color.parseColor("#10B981") // Green
            score >= 60 -> Color.parseColor("#FBBF24") // Yellow / Orange
            else -> Color.parseColor("#EF4444") // Red
        }

        val paintScoreArc = Paint().apply {
            color = scoreColor
            style = Paint.Style.STROKE
            strokeWidth = 8f
            isAntiAlias = true
        }

        val paintScoreArcBack = Paint().apply {
            color = Color.parseColor("#E5E7EB")
            style = Paint.Style.STROKE
            strokeWidth = 8f
            isAntiAlias = true
        }

        val paintScoreText = Paint().apply {
            color = scoreColor
            textSize = 28f
            isFakeBoldText = true
            isAntiAlias = true
        }

        // Draw score arc
        val arcLeft = 40f
        val arcTop = 205f
        val arcRight = 110f
        val arcBottom = 275f

        canvas.drawArc(arcLeft, arcTop, arcRight, arcBottom, 0f, 360f, false, paintScoreArcBack)
        canvas.drawArc(arcLeft, arcTop, arcRight, arcBottom, -90f, (score * 3.6f), false, paintScoreArc)

        // Draw score middle text
        val scoreStr = "%$score"
        val rectText = Rect()
        paintScoreText.getTextBounds(scoreStr, 0, scoreStr.length, rectText)
        val scoreX = (arcLeft + arcRight) / 2f - rectText.centerX()
        val scoreY = (arcTop + arcBottom) / 2f - rectText.centerY()
        canvas.drawText(scoreStr, scoreX, scoreY, paintScoreText)

        // Side text next to indicator
        canvas.drawText("ARAC GÜVENLİK VE SAĞLIK INDEKSI", 130f, 225f, paintTextBold)
        val descText = when {
            score >= 80 -> "Araç sistemleri sağlıklı. Kritik hata tespiti yapılmadı."
            score >= 60 -> "Araç üzerinde müdahale gerektiren uyarı düzeyli hata kodları var."
            else -> "ACİL MÜDAHALE! Araç üzerinde güvenliği tehlikeye atan arızalar saptandı."
        }
        canvas.drawText(descText, 130f, 245f, paintText)
        canvas.drawText("Taranan Sistem Sayısı: ${report.okCount + report.errorCount} | Arıza Veren Sistem Sayısı: ${report.errorCount}", 130f, 260f, paintGray)

        canvas.drawLine(40f, 290f, 555f, 290f, paintBorder)

        // 4. Trouble Codes Table (Render registered DTC database)
        canvas.drawText("SAPTANAN ELEKTRONİK ARIZA TEŞHİS KODLARI (DTC)", 40f, 315f, paintSubtitle)

        // Parse trouble codes list
        val type = Types.newParameterizedType(List::class.java, TroubleCode::class.java)
        val adapter = moshi.adapter<List<TroubleCode>>(type)
        val troubleCodes = try {
            adapter.fromJson(report.troubleCodesJson) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

        var currentY = 345f

        // Table Header
        canvas.drawRect(40f, currentY - 15f, 555f, currentY + 10f, paintFillHeader)
        canvas.drawText("Kod", 45f, currentY, paintTextBold)
        canvas.drawText("Açıklama / Detay", 110f, currentY, paintTextBold)
        canvas.drawText("Modül", 340f, currentY, paintTextBold)
        canvas.drawText("Önem", 430f, currentY, paintTextBold)
        canvas.drawText("Durum", 495f, currentY, paintTextBold)

        canvas.drawLine(40f, currentY + 10f, 555f, currentY + 10f, paintBorder)
        currentY += 25f

        if (troubleCodes.isEmpty()) {
            canvas.drawText("Arıza kodu saptanmadı veya hata kayıtları tamamen temizlendi.", 50f, currentY, paintText)
            currentY += 20f
        } else {
            troubleCodes.forEach { dtc ->
                if (currentY > 730f) {
                    // Stop listing if out of page boundaries (single page report constraints)
                    canvas.drawText("... ve diğer arıza kodları (liste sığmadığı için kesildi)", 45f, currentY, paintGray)
                    currentY += 15f
                    return@forEach
                }
                // Shorten description if too long
                val shortDesc = if (dtc.description.length > 40) dtc.description.take(38) + ".." else dtc.description
                canvas.drawText(dtc.code, 45f, currentY, paintTextBold)
                canvas.drawText(shortDesc, 110f, currentY, paintText)
                canvas.drawText(dtc.moduleName, 340f, currentY, paintText)
                canvas.drawText(dtc.severity, 430f, currentY, paintText)
                canvas.drawText(dtc.status, 495f, currentY, paintText)

                canvas.drawLine(40f, currentY + 5f, 555f, currentY + 5f, paintBorder)
                currentY += 20f
            }
        }

        // 5. Technician and Service Comments Room
        if (report.technicianNotes.isNotEmpty()) {
            if (currentY < 750f) {
                canvas.drawText("TEKNİSYEN DEĞERLENDİRME VE SERVİS NOTLARI", 40f, currentY + 15f, paintTextBold)
                val notes = if (report.technicianNotes.length > 150) report.technicianNotes.take(145) + "..." else report.technicianNotes
                canvas.drawText(notes, 40f, currentY + 35f, paintText)
            }
        }

        // 6. Signature Footnote
        if (report.isSigned && report.signatureBase64.isNotEmpty()) {
            try {
                val decodedBytes = Base64.decode(report.signatureBase64, Base64.DEFAULT)
                val signatureBitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                if (signatureBitmap != null) {
                    val destRect = Rect(410, 690, 540, 760)
                    canvas.drawBitmap(signatureBitmap, null, destRect, null)
                    canvas.drawText("Teknisyen İmza / Onay", 415f, 775f, paintGray)
                    canvas.drawLine(410f, 765f, 540f, 765f, paintBorder)
                }
            } catch (e: Exception) {
                Log.e("PdfReportGenerator", "Failed to draw technician signature on PDF", e)
            }
        }

        canvas.drawLine(40f, 790f, 555f, 790f, paintBorder)
        canvas.drawText("X-DIAG Pro araç teşhis ve arıza sıfırlama sistemi tarafından hazırlanan resmi rapordur.", 40f, 805f, paintGray)
        canvas.drawText("Matco Red OBD2 ELM327 Entegre Bluetooth/WiFi Çift Mod Araç Analizörü", 40f, 818f, paintGray)

        pdfDocument.finishPage(page)

        // Save PDF to cache directory
        val reportsDir = File(context.cacheDir, "reports")
        if (!reportsDir.exists()) {
            reportsDir.mkdirs()
        }
        val pdfFile = File(reportsDir, "XDiag_Report_${report.timestamp}.pdf")
        try {
            FileOutputStream(pdfFile).use { fos ->
                pdfDocument.writeTo(fos)
            }
            Log.d("PdfReportGenerator", "PDF Raporu kaydedildi: ${pdfFile.absolutePath}")
        } catch (e: Exception) {
            Log.e("PdfReportGenerator", "Error writing PDF report to filesystem", e)
        } finally {
            pdfDocument.close()
        }

        // Return FileProvider Uri
        return FileProvider.getUriForFile(context, "com.example.fileprovider", pdfFile)
    }
}
