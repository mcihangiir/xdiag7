package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

class WifiOBDManager(private val context: Context) : IOBDConnection {
    companion object {
        private const val TAG = "WifiOBDManager"
    }

    override val protocolType = ProtocolType.WIFI_ELM327

    private var socket: Socket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    private val _isConnected = MutableStateFlow(false)
    override val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _connectionStatus = MutableStateFlow("Bekleniyor...")
    val connectionStatus: StateFlow<String> = _connectionStatus.asStateFlow()

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    override suspend fun connect(): Boolean {
        // implemented in connectToWifi
        return false
    }

    suspend fun connectToWifi(host: String, port: Int): Boolean = withContext(Dispatchers.IO) {
        var retryCount = 0
        val maxRetries = 3
        var success = false

        _connectionState.value = ConnectionState.CONNECTING
        while (retryCount < maxRetries && !success) {
            try {
                _connectionStatus.value = "Wi-Fi Bağlantısı Kuruluyor (${retryCount + 1}/$maxRetries)..."
                socket = Socket()
                socket?.connect(InetSocketAddress(host, port), 3000) // 3 seconds timeout

                inputStream = socket?.inputStream
                outputStream = socket?.outputStream

                // Connection successful! Run ELM327 initiations.
                // Reset ELM327: ATZ
                sendInitCommand("ATZ\r")
                delay(1000)
                // Echo Off
                sendInitCommand("ATE0\r")
                delay(300)
                // Linefeeds Off
                sendInitCommand("ATL0\r")
                delay(300)
                // Headers On (so we get complete replies for CAN protocol)
                sendInitCommand("ATH1\r")
                delay(300)
                // Protocol Auto: ATSP0
                sendInitCommand("ATSP0\r")
                delay(500)

                _isConnected.value = true
                _connectionState.value = ConnectionState.CONNECTED
                _connectionStatus.value = "Wi-Fi OBD Cihazına Bağlandı ($host:$port)"
                success = true
            } catch (e: Exception) {
                Log.e(TAG, "Wi-Fi connection attempt failed: Retry $retryCount", e)
                retryCount++
                disconnectStreamsOnly()
                if (retryCount < maxRetries) {
                    delay(1000) // wait 1s before retry
                } else {
                    _connectionState.value = ConnectionState.ERROR
                    _connectionStatus.value = "Wi-Fi Bağlantı Hatası: ${e.localizedMessage}"
                }
            }
        }
        return@withContext success
    }

    private fun disconnectStreamsOnly() {
        try {
            inputStream?.close()
            outputStream?.close()
            socket?.close()
        } catch (_: Exception) {}
        inputStream = null
        outputStream = null
        socket = null
    }

    override fun disconnect() {
        try {
            inputStream?.close()
            outputStream?.close()
            socket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error closing Wi-Fi socket", e)
        } finally {
            inputStream = null
            outputStream = null
            socket = null
            _isConnected.value = false
            _connectionState.value = ConnectionState.DISCONNECTED
            _connectionStatus.value = "Bağlantı Kesildi"
        }
    }

    private suspend fun sendInitCommand(cmd: String) {
        if (outputStream == null) return
        try {
            outputStream?.write(cmd.toByteArray())
            outputStream?.flush()
        } catch (e: Exception) {
            Log.e(TAG, "Error sending init command", e)
        }
    }

    override suspend fun sendRawCommand(cmd: String): String = withContext(Dispatchers.IO) {
        if (outputStream == null || inputStream == null) return@withContext ""
        try {
            val commandWithReturn = "$cmd\r"
            outputStream?.write(commandWithReturn.toByteArray())
            outputStream?.flush()

            // Read response with 3s timeout
            val sb = java.lang.StringBuilder()
            val startTime = System.currentTimeMillis()
            val buffer = ByteArray(1024)

            while (System.currentTimeMillis() - startTime < 3000) {
                val available = inputStream?.available() ?: 0
                if (available > 0) {
                    val bytesRead = inputStream?.read(buffer) ?: -1
                    if (bytesRead > 0) {
                        val chunk = String(buffer, 0, bytesRead)
                        sb.append(chunk)
                        if (sb.contains(">")) {
                            break
                        }
                    }
                } else {
                    delay(50) // Small delay to avoid busy looping
                }
            }

            return@withContext sb.toString().trim().replace(">", "")
        } catch (e: IOException) {
            Log.e(TAG, "Wi-Fi Connection lost during command: $cmd", e)
            disconnect()
            return@withContext "ERROR"
        }
    }
}
