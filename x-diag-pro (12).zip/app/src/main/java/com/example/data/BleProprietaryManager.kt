package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import kotlin.coroutines.resume

class BleProprietaryManager(
    private val bleCore: BleConnectionCore,
    private val context: Context
) : IOBDConnection {

    override val protocolType = ProtocolType.BLE_PROPRIETARY
    override val connectionState = bleCore.connectionState
    private val _isConnected = MutableStateFlow(false)
    override val isConnected: StateFlow<Boolean> = _isConnected

    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private val rawResponseBuffer = mutableListOf<Byte>()
    private var pendingCallback: ((ByteArray) -> Unit)? = null

    private val prefs = context.getSharedPreferences("ble_proprietary_config", Context.MODE_PRIVATE)

    fun saveManualConfig(serviceUuid: String, writeUuid: String, notifyUuid: String) {
        prefs.edit()
            .putString("service_uuid", serviceUuid)
            .putString("write_uuid", writeUuid)
            .putString("notify_uuid", notifyUuid)
            .apply()
    }

    fun getManualConfig(): Triple<String?, String?, String?> {
        return Triple(
            prefs.getString("service_uuid", null),
            prefs.getString("write_uuid", null),
            prefs.getString("notify_uuid", null)
        )
    }

    @SuppressLint("MissingPermission")
    override suspend fun connect(): Boolean {
        var serviceUuid = prefs.getString("service_uuid", null)
        var writeUuid = prefs.getString("write_uuid", null)
        var notifyUuid = prefs.getString("notify_uuid", null)

        val services = bleCore.discoveredServices.value

        if (serviceUuid.isNullOrBlank() || writeUuid.isNullOrBlank() || notifyUuid.isNullOrBlank()) {
            var found = false
            for (service in services) {
                val w = service.characteristics.find {
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) ||
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                }
                val n = service.characteristics.find {
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) ||
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
                }
                if (w != null && n != null) {
                    serviceUuid = service.uuid.toString()
                    writeUuid = w.uuid.toString()
                    notifyUuid = n.uuid.toString()
                    saveManualConfig(serviceUuid, writeUuid, notifyUuid)
                    found = true
                    break
                }
            }
            if (!found) return false
        }

        val finalNotifyUuid = notifyUuid!!
        bleCore.onDataReceived = { uuid, data ->
            if (uuid == finalNotifyUuid) {
                rawResponseBuffer.addAll(data.toList())
                pendingCallback?.invoke(rawResponseBuffer.toByteArray())
            }
        }

        val service = services.find { it.uuid.toString() == serviceUuid }
        writeChar = service?.getCharacteristic(UUID.fromString(writeUuid!!))
        notifyChar = service?.getCharacteristic(UUID.fromString(finalNotifyUuid))

        if (writeChar == null || notifyChar == null) {
            // As a robust last resort, try direct binding to any available write/notify channel
            for (srv in services) {
                val w = srv.characteristics.find {
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) ||
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                }
                val n = srv.characteristics.find {
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) ||
                    (it.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
                }
                if (w != null && n != null) {
                    writeChar = w
                    notifyChar = n
                    saveManualConfig(srv.uuid.toString(), w.uuid.toString(), n.uuid.toString())
                    break
                }
            }
        }

        if (writeChar == null || notifyChar == null) return false

        bleCore.bluetoothGatt?.setCharacteristicNotification(notifyChar, true)
        val descriptor = notifyChar?.getDescriptor(
            UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        )
        descriptor?.let {
            it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            bleCore.bluetoothGatt?.writeDescriptor(it)
        }

        _isConnected.value = true

        // KRİTİK: Gerçek handshake doğrulaması — birkaç farklı komut dene,
        // HİÇBİRİ yanıt vermezse bağlantıyı BAŞARISIZ say
        val handshakeAttempts = listOf(
            "ATI" to true,           // ASCII ELM327 info komutu
            "ATZ" to true,           // ASCII reset
            "3E00" to false,         // UDS Tester Present (hex)
            "AAFF0001" to false      // Launch-tarzı olası probe (hex)
        )

        var handshakeSuccess = false
        for ((cmd, isAscii) in handshakeAttempts) {
            val testBytes = if (isAscii) "$cmd\r".toByteArray(Charsets.US_ASCII)
                            else hexStringToBytes(cmd)
            val response = kotlinx.coroutines.withTimeoutOrNull(2000L) { sendRawBytesInternal(testBytes) }
            if (response != null && response.isNotEmpty()) {
                handshakeSuccess = true
                break
            }
            kotlinx.coroutines.delay(200)
        }

        if (!handshakeSuccess) {
            _isConnected.value = false
            return false  // GATT bağlandı ama cihaz HİÇBİR komuta yanıt vermedi
        }

        return true
    }

    private suspend fun sendRawBytesInternal(bytes: ByteArray): ByteArray =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            rawResponseBuffer.clear()
            pendingCallback = { data -> if (cont.isActive) cont.resume(data) }
            val char = writeChar ?: run {
                if (cont.isActive) cont.resume(ByteArray(0))
                return@suspendCancellableCoroutine
            }
            bleCore.writeChunked(char, bytes)
        }

    private fun hexStringToBytes(hex: String): ByteArray {
        val clean = hex.replace(" ", "")
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    override suspend fun sendRawBytes(bytes: ByteArray): ByteArray = 
        withTimeoutOrNull(5000L) {
            suspendCancellableCoroutine { cont ->
                rawResponseBuffer.clear()
                pendingCallback = { data -> 
                    if (cont.isActive) cont.resume(data) 
                }
                val char = writeChar ?: run {
                    if (cont.isActive) cont.resume(ByteArray(0))
                    return@suspendCancellableCoroutine
                }
                bleCore.writeChunked(char, bytes)
            }
        } ?: ByteArray(0)

    override suspend fun sendRawCommand(cmd: String): String {
        val response = sendRawBytes(cmd.toByteArray(Charsets.US_ASCII))
        return String(response, Charsets.US_ASCII)
    }

    override fun disconnect() {
        bleCore.disconnect()
        _isConnected.value = false
    }
}
