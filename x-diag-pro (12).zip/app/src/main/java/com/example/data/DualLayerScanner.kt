package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class DualLayerScanner(
    private val context: Context,
    private val classicAdapter: BluetoothAdapter?,
    private val bleCore: BleConnectionCore,
    private val autoDiscovery: BleAutoDiscoveryEngine
) {
    data class ScanResult(
        val name: String,
        val address: String,
        val layer: String,        // "CLASSIC_BONDED", "CLASSIC_DISCOVERED", "BLE"
        val rssi: Int? = null,
        val deviceClass: String? = null  // Classic için cihaz sınıfı (örn: "Bilgisayar", "Telefon")
    )

    private val _allResults = MutableStateFlow<List<ScanResult>>(emptyList())
    val allResults: StateFlow<List<ScanResult>> = _allResults.asStateFlow()

    private val _scanLog = MutableStateFlow<List<String>>(emptyList())
    val scanLog: StateFlow<List<String>> = _scanLog.asStateFlow()

    private val _lastCapturedResponse = MutableStateFlow<String?>(null)
    val lastCapturedResponse: StateFlow<String?> = _lastCapturedResponse.asStateFlow()

    private var scannerScope = CoroutineScope(Dispatchers.Main + Job())

    private val logFile: File by lazy {
        val dir = File(context.getExternalFilesDir(null), "ds401_tani")
        if (!dir.exists()) dir.mkdirs()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        File(dir, "ds401_tani_log_$timestamp.txt")
    }

    fun clearLog() {
        _scanLog.value = emptyList()
        _lastCapturedResponse.value = null
    }

    fun log(msg: String) {
        val timestamp = System.currentTimeMillis() % 100000
        val line = "[$timestamp] $msg"
        _scanLog.value = _scanLog.value + line
        try {
            logFile.appendText(line + "\n")
        } catch (e: Exception) {
            // dosya yazma hatası UI'ı bozmasın, sessizce geç
        }
    }

    fun getLogFilePath(): String = logFile.absolutePath

    @SuppressLint("MissingPermission")
    fun scanBoth() {
        _allResults.value = emptyList()
        log("=== ÇİFT KATMAN TARAMA BAŞLADI ===")

        // 1. EŞLEŞTİRİLMİŞ (BONDED) CLASSIC CİHAZLAR — anında, taramasız
        val bonded = classicAdapter?.bondedDevices ?: emptySet()
        log("Eşleştirilmiş Classic cihaz sayısı: ${bonded.size}")
        bonded.forEach { d ->
            val cls = d.bluetoothClass?.deviceClass?.toString() ?: "Bilinmiyor"
            log("  BONDED: ${d.name ?: "İsimsiz"} (${d.address}) sınıf=$cls")
            _allResults.value = _allResults.value + ScanResult(
                d.name ?: "İsimsiz", d.address, "CLASSIC_BONDED", deviceClass = cls
            )
        }

        // 2. CLASSIC DISCOVERY (eşleşmemiş ama yayın yapan cihazlar)
        log("Classic discovery başlatılıyor (12 sn)...")
        val discoveryReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == BluetoothDevice.ACTION_FOUND) {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    device?.let { d ->
                        log("  DISCOVERED: ${d.name ?: "İsimsiz"} (${d.address}) RSSI=$rssi")
                        val exists = _allResults.value.any { it.address == d.address }
                        if (!exists) {
                            _allResults.value = _allResults.value + ScanResult(
                                d.name ?: "İsimsiz", d.address, "CLASSIC_DISCOVERED", rssi
                            )
                        }
                    }
                }
            }
        }
        try {
            context.registerReceiver(discoveryReceiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
        } catch (e: Exception) {
            log("Receiver kayit hatasi: ${e.message}")
        }
        classicAdapter?.startDiscovery()

        // 3. BLE TARAMA (paralel)
        log("BLE tarama başlatılıyor (12 sn)...")
        bleCore.startScan(durationMs = 12000L)

        scannerScope.launch {
            // BLE sonuçlarını izle
            bleCore.scannedDevices.collect { bleDevices ->
                bleDevices.forEach { info ->
                    val exists = _allResults.value.any { it.address == info.address }
                    if (!exists) {
                        log("  BLE: ${info.name} (${info.address}) RSSI=${info.rssi}")
                        _allResults.value = _allResults.value + ScanResult(
                            info.name, info.address, "BLE", info.rssi
                        )
                    }
                }
            }
        }

        scannerScope.launch {
            delay(12000)
            try {
                classicAdapter?.cancelDiscovery()
            } catch (e: Exception) {}
            try { 
                context.unregisterReceiver(discoveryReceiver) 
            } catch (e: Exception) {}
            log("=== TARAMA TAMAMLANDI: ${_allResults.value.size} cihaz bulundu ===")
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun testClassicConnection(device: BluetoothDevice) = withContext(Dispatchers.IO) {
        log("Classic RFCOMM soket deneniyor: kanal otomatik (UUID SPP)...")
        _lastCapturedResponse.value = null
        
        // 3 farklı UUID/yöntem dene, HER BİRİNİN SONUCUNU AYRI LOGLA
        val attempts = listOf(
            "Standart SPP UUID" to { d: BluetoothDevice -> 
                d.createRfcommSocketToServiceRecord(
                    UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")) },
            "Insecure SPP UUID" to { d: BluetoothDevice ->
                d.createInsecureRfcommSocketToServiceRecord(
                    UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")) },
            "Reflection Kanal 1" to { d: BluetoothDevice ->
                val m = d.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                m.invoke(d, 1) as BluetoothSocket }
        )

        for ((name, factory) in attempts) {
            log("  Deneniyor: $name")
            var socket: BluetoothSocket? = null
            try {
                socket = factory(device)
                socket.connect()
                log("  ✅ $name BAŞARILI — soket açık")
                
                val out = socket.outputStream
                val inp = socket.inputStream
                
                // ATI gönder, ham yanıtı bekle (3 saniye)
                log("  ATI gönderiliyor (ham byte: 41 54 49 0D)...")
                out.write("ATI\r".toByteArray())
                out.flush()
                
                val buffer = ByteArray(256)
                val response = withTimeoutOrNull(3000L) {
                    val bytesRead = inp.read(buffer)
                    if (bytesRead > 0) buffer.copyOfRange(0, bytesRead) else ByteArray(0)
                } ?: ByteArray(0)
                
                val hex = response.joinToString(" ") { "%02X".format(it) }
                val ascii = String(response, Charsets.US_ASCII).filter { it.isDefined() }
                log("  HAM YANIT (HEX): $hex")
                log("  HAM YANIT (ASCII): $ascii")
                
                if (response.isEmpty()) {
                    log("  ❌ HİÇ YANIT GELMEDİ (3 sn timeout) — soket açık ama cihaz sessiz")
                } else {
                    log("  🎉 CİHAZ YANIT VERDİ! Bu kanıttır, teori değil.")
                    _lastCapturedResponse.value = hex
                    
                    // Otomatik kaydet
                    val profile = WorkingDeviceProfile(
                        deviceAddress = device.address,
                        layer = "CLASSIC",
                        workingMethod = name,
                        firstByteResponseHex = hex,
                        timestamp = System.currentTimeMillis()
                    )
                    WorkingDeviceProfile.saveProfile(context, profile)
                    log("  💾 Profil otomatik kaydedildi: ${device.address} ($name)")
                }
                
                socket.close()
                return@withContext
                
            } catch (e: Exception) {
                log("  ❌ $name BAŞARISIZ: ${e.javaClass.simpleName}: ${e.message}")
                try { socket?.close() } catch (ex: Exception) {}
            }
        }
        log("=== Classic katmanda HİÇBİR yöntem soket açamadı ===")
    }

    @SuppressLint("MissingPermission")
    suspend fun testBleConnection(device: BluetoothDevice) = withContext(Dispatchers.Main) {
        log("BLE GATT bağlantısı deneniyor...")
        _lastCapturedResponse.value = null
        
        val connected = bleCore.connectAndDiscover(device)
        
        if (!connected) {
            log("❌ GATT bağlantısı KURULAMADI")
            return@withContext
        }
        
        log("✅ GATT bağlandı. MTU: ${bleCore.negotiatedMtu}")
        log("Servisler taranıyor...")
        
        bleCore.discoveredServices.value.forEach { service ->
            log("  SERVİS: ${service.uuid}")
            service.characteristics.forEach { char ->
                val props = mutableListOf<String>()
                if (char.properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) props.add("READ")
                if (char.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) props.add("WRITE")
                if (char.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) props.add("WRITE_NR")
                if (char.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) props.add("NOTIFY")
                log("    CHAR: ${char.uuid} [${props.joinToString(",")}]")
            }
        }
        
        log("Otomatik komut taraması başlatılıyor (genişletilmiş liste)...")
        _lastCapturedResponse.value = "BLE_PENDING" // mark that we tried BLE
        
        val profile = autoDiscovery.autoDiscover(device)
        
        if (profile != null) {
            log("🎉 PROFİL BULUNDU: ${profile.protocolType}, write=${profile.writeUuid}")
            val wp = WorkingDeviceProfile(
                deviceAddress = device.address,
                layer = "BLE",
                workingMethod = "BLE Protocol: ${profile.protocolType}",
                firstByteResponseHex = profile.handshakeCommand,
                timestamp = System.currentTimeMillis()
            )
            WorkingDeviceProfile.saveProfile(context, wp)
            log("  💾 Profil otomatik kaydedildi: ${device.address} (BLE)")
            _lastCapturedResponse.value = profile.handshakeCommand
        } else {
            log("❌ Hiçbir bilinen handshake yanıt almadı")
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun bruteForceRfcommChannels(device: BluetoothDevice) = withContext(Dispatchers.IO) {
        log("=== BRUTE-FORCE: Kanal 1-30 arası deneniyor ===")
        log("Bu işlem 30-60 saniye sürebilir, sabırlı olun...")
        _lastCapturedResponse.value = null
        var foundAny = false
        
        for (channel in 1..30) {
            log("Kanal $channel deneniyor...")
            var socket: BluetoothSocket? = null
            try {
                val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                socket = m.invoke(device, channel) as BluetoothSocket
                
                val connectResult = withTimeoutOrNull(1500L) {
                    try { socket.connect(); true } catch (e: Exception) { false }
                } ?: false
                
                if (connectResult) {
                    log("  ✅ KANAL $channel BAĞLANDI")
                    foundAny = true
                    
                    socket.outputStream.write("ATI\r".toByteArray())
                    socket.outputStream.flush()
                    
                    val buffer = ByteArray(128)
                    val responseBytes = withTimeoutOrNull(1500L) {
                        try {
                            val read = socket.inputStream.read(buffer)
                            if (read > 0) buffer.copyOfRange(0, read) else null
                        } catch (e: Exception) { null }
                    }
                    
                    if (responseBytes != null && responseBytes.isNotEmpty()) {
                        val hex = responseBytes.joinToString(" ") { "%02X".format(it) }
                        val ascii = String(responseBytes, Charsets.US_ASCII).filter { it.isDefined() }
                        log("  🎉 KANAL $channel YANIT VERDİ (HEX): $hex")
                        log("  🎉 KANAL $channel YANIT VERDİ (ASCII): $ascii")
                        _lastCapturedResponse.value = hex

                        // Kaydet
                        val wp = WorkingDeviceProfile(
                            deviceAddress = device.address,
                            layer = "CLASSIC",
                            workingMethod = "Brute-force Kanal $channel",
                            firstByteResponseHex = hex,
                            timestamp = System.currentTimeMillis()
                        )
                        WorkingDeviceProfile.saveProfile(context, wp)
                        log("  💾 Profil otomatik kaydedildi: ${device.address} (Kanal $channel)")
                    } else {
                        log("  ⚠️ Kanal $channel bağlandı ama yanıt yok")
                    }
                    socket.close()
                }
            } catch (e: Exception) {
                // Sessizce devam et
                try { socket?.close() } catch (ex: Exception) {}
            }
            delay(100)
        }
        log("=== BRUTE-FORCE TAMAMLANDI ===")
        if (!foundAny) {
            log("❌ Kanal 1-30 arasında hiçbir kanaldan bağlantı kurulamadı.")
        }
    }

    fun shareLogFile(): File? {
        return try {
            val dir = File(context.cacheDir, "logs")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, "ds401_scan_diagnostic_log.txt")
            val writer = FileWriter(file)
            _scanLog.value.forEach { line ->
                writer.write(line + "\n")
            }
            writer.close()
            file
        } catch (e: Exception) {
            null
        }
    }
}
