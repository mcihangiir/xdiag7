package com.example.data

enum class ConnectionType {
    BLUETOOTH,
    BLE,
    WIFI,
    NONE
}
