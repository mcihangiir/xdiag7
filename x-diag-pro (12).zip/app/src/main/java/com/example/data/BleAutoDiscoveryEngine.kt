package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import kotlin.coroutines.resume

class BleAutoDiscoveryEngine(
    private val bleCore: BleConnectionCore,
    private val context: Context
) {
    private val prefs = context.getSharedPreferences("ble_device_profiles", Context.MODE_PRIVATE)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    data class DeviceProfile(
        val deviceAddress: String,
        val deviceName: String,
        val serviceUuid: String,
        val writeUuid: String,
        val notifyUuid: String,
        val handshakeCommand: String,   // HEX string, örn "41545A0D"
        val protocolType: String,       // "ELM327_ASCII" veya "BINARY_ECHO" vb.
        val confirmedWorking: Boolean
    )

    private val _discoveryProgress = MutableStateFlow<DiscoveryStep>(DiscoveryStep.Idle)
    val discoveryProgress: StateFlow<DiscoveryStep> = _discoveryProgress

    sealed class DiscoveryStep {
        object Idle : DiscoveryStep()
        object ScanningServices : DiscoveryStep()
        data class TestingCandidate(val current: Int, val total: Int, val description: String) : DiscoveryStep()
        data class Success(val profile: DeviceProfile) : DiscoveryStep()
        object Failed : DiscoveryStep()
        object RecordingMode : DiscoveryStep()
    }

    private fun findAllCandidatePairs(): List<CharacteristicPair> {
        val services = bleCore.discoveredServices.value
        val candidates = mutableListOf<CharacteristicPair>()

        for (service in services) {
            val writers = service.characteristics.filter {
                (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) ||
                (it.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
            }
            val notifiers = service.characteristics.filter {
                (it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) ||
                (it.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
            }
            for (w in writers) {
                for (n in notifiers) {
                    candidates.add(CharacteristicPair(service, w, n))
                }
            }
        }
        return candidates.sortedByDescending { isKnownUuid(it.service.uuid.toString()) }
    }

    data class CharacteristicPair(
        val service: BluetoothGattService,
        val write: BluetoothGattCharacteristic,
        val notify: BluetoothGattCharacteristic
    )

    private fun isKnownUuid(uuid: String): Boolean {
        val known = listOf("fff0", "ffe0", "ff9f", "ffd8", "6e400001", "ffe5", "ffd0")
        return known.any { uuid.lowercase().contains(it) }
    }

    private val handshakeCandidates = listOf(
        HandshakeCandidate("ELM327_ASCII", "ATZ\r", isAscii = true,
            successCheck = { resp -> 
                val str = resp.toString()
                str.contains("ELM", true) || str.contains("OK", true) || str.contains(">") 
            }),
        HandshakeCandidate("ELM327_ASCII_LOWER", "atz\r", isAscii = true,
            successCheck = { resp -> 
                val str = resp.toString()
                str.contains("ELM", true) || str.contains(">") 
            }),
        HandshakeCandidate("AT_ECHO", "AT\r", isAscii = true,
            successCheck = { resp -> 
                val str = resp.toString()
                str.isNotBlank() && str.any { it.isLetterOrDigit() } 
            }),
        HandshakeCandidate("UDS_TESTER_PRESENT", "3E00", isAscii = false,
            successCheck = { resp -> 
                val arr = resp as? ByteArray
                arr != null && arr.isNotEmpty() && arr[0] == 0x7E.toByte() 
            }),
        HandshakeCandidate("LAUNCH_PROBE_01", "AAFF0001", isAscii = false,
            successCheck = { resp -> 
                val arr = resp as? ByteArray
                arr != null && arr.isNotEmpty() 
            }),
        HandshakeCandidate("GENERIC_NEWLINE", "\r\n", isAscii = true,
            successCheck = { resp -> 
                resp.toString().isNotBlank() 
            }),
        HandshakeCandidate("RAW_ECHO_TEST", "01", isAscii = false,
            successCheck = { resp -> 
                val arr = resp as? ByteArray
                arr != null && arr.isNotEmpty() 
            })
    )

    data class HandshakeCandidate(
        val name: String,
        val command: String,
        val isAscii: Boolean,
        val successCheck: (Any) -> Boolean
    )

    @SuppressLint("MissingPermission")
    suspend fun autoDiscover(device: BluetoothDevice): DeviceProfile? {
        _discoveryProgress.value = DiscoveryStep.ScanningServices

        val cached = loadCachedProfile(device.address)
        if (cached != null && cached.confirmedWorking) {
            _discoveryProgress.value = DiscoveryStep.Success(cached)
            return cached
        }

        val candidates = findAllCandidatePairs()
        if (candidates.isEmpty()) {
            _discoveryProgress.value = DiscoveryStep.Failed
            return null
        }

        var attemptCount = 0
        val totalAttempts = candidates.size * handshakeCandidates.size

        for (pair in candidates) {
            enableNotifyFor(pair.notify)
            delay(300)

            for (handshake in handshakeCandidates) {
                attemptCount++
                _discoveryProgress.value = DiscoveryStep.TestingCandidate(
                    current = attemptCount, 
                    total = totalAttempts,
                    description = "${pair.service.uuid.toString().take(8)} → ${handshake.name}"
                )

                val response = sendAndWaitForResponse(pair.write, handshake)
                
                val success = try { 
                    if ((handshake.isAscii && response is String) || (!handshake.isAscii && response is ByteArray)) {
                        handshake.successCheck(response) 
                    } else false
                } catch (e: Exception) { false }

                if (success) {
                    val profile = DeviceProfile(
                        deviceAddress = device.address,
                        deviceName = device.name ?: "Bilinmeyen",
                        serviceUuid = pair.service.uuid.toString(),
                        writeUuid = pair.write.uuid.toString(),
                        notifyUuid = pair.notify.uuid.toString(),
                        handshakeCommand = handshake.command,
                        protocolType = handshake.name,
                        confirmedWorking = true
                    )
                    saveCachedProfile(profile)
                    _discoveryProgress.value = DiscoveryStep.Success(profile)
                    return profile
                }
                delay(150)
            }
        }

        _discoveryProgress.value = DiscoveryStep.RecordingMode
        return null
    }

    private suspend fun sendAndWaitForResponse(
        writeChar: BluetoothGattCharacteristic,
        handshake: HandshakeCandidate
    ): Any = withTimeoutOrNull(1500L) {
        suspendCancellableCoroutine<Any> { cont ->
            val buffer = mutableListOf<Byte>()
            bleCore.onDataReceived = { _, data ->
                buffer.addAll(data.toList())
                if (cont.isActive) {
                    val result: Any = if (handshake.isAscii) 
                        String(buffer.toByteArray(), Charsets.US_ASCII) 
                    else 
                        buffer.toByteArray()
                    cont.resume(result)
                }
            }
            val bytes = if (handshake.isAscii) 
                handshake.command.toByteArray(Charsets.US_ASCII)
            else 
                hexStringToByteArray(handshake.command)
            bleCore.writeChunked(writeChar, bytes)
        }
    } ?: (if (handshake.isAscii) "" else ByteArray(0))

    private fun hexStringToByteArray(hex: String): ByteArray {
        val clean = hex.replace(" ", "")
        if (clean.isEmpty() || clean.length % 2 != 0) return ByteArray(0)
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i*2, i*2+2).toInt(16).toByte()
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableNotifyFor(char: BluetoothGattCharacteristic) {
        bleCore.bluetoothGatt?.setCharacteristicNotification(char, true)
        val descriptor = char.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
        descriptor?.let {
            it.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            bleCore.bluetoothGatt?.writeDescriptor(it)
        }
    }

    fun saveCachedProfile(profile: DeviceProfile) {
        try {
            val json = moshi.adapter(DeviceProfile::class.java).toJson(profile)
            prefs.edit().putString("profile_${profile.deviceAddress}", json).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadCachedProfile(address: String): DeviceProfile? {
        val json = prefs.getString("profile_${address}", null) ?: return null
        return try {
            moshi.adapter(DeviceProfile::class.java).fromJson(json)
        } catch (e: Exception) { null }
    }

    fun forgetProfile(address: String) {
        prefs.edit().remove("profile_${address}").apply()
    }
}
