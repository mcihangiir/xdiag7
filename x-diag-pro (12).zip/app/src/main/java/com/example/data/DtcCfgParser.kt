package com.example.data

import android.content.Context
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

object DtcCfgParser {
    private const val TAG = "DtcCfgParser"

    fun parse(context: Context, fileSource: File): Map<String, String> {
        val dtcsMap = mutableMapOf<String, String>()
        try {
            if (!fileSource.exists()) return emptyMap()
            val bytes = fileSource.readBytes()
            val buffer = ByteBuffer.wrap(bytes).apply {
                order(ByteOrder.LITTLE_ENDIAN)
            }

            // Header (14 bytes)
            if (buffer.remaining() < 14) return emptyMap()
            val magic = ByteArray(5)
            buffer.get(magic)
            val ver = ByteArray(5)
            buffer.get(ver)
            val recordCount = buffer.int

            Log.d(TAG, "DTCH_CFG.BIN Parser Header - Magic: ${String(magic)}, Records: $recordCount")

            // Index offsets
            val indexList = mutableListOf<LaunchDtcMapping>()
            for (i in 0 until recordCount) {
                if (buffer.remaining() < 16) break
                val codeBytes = ByteArray(8)
                buffer.get(codeBytes)
                val code = String(codeBytes, StandardCharsets.US_ASCII).trim()
                val offset = buffer.int
                val length = buffer.int
                indexList.add(LaunchDtcMapping(code, offset, length))
            }

            // Extract translations
            for (mapping in indexList) {
                if (mapping.descriptionOffset + mapping.descriptionLength <= bytes.size) {
                    buffer.position(mapping.descriptionOffset)
                    val descBytes = ByteArray(mapping.descriptionLength)
                    buffer.get(descBytes)
                    val description = String(descBytes, StandardCharsets.UTF_8).trim()
                    dtcsMap[mapping.dtcCode] = description
                }
            }
            Log.d(TAG, "Successfully parsed ${dtcsMap.size} DTC definitions from DTCH_CFG.BIN")
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing DTCH_CFG.BIN", e)
        }
        return dtcsMap
    }
}
