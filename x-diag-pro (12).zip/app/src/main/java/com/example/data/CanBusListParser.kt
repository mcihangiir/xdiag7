package com.example.data

import android.content.Context
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

object CanBusListParser {
    private const val TAG = "CanBusListParser"

    fun parse(context: Context, fileSource: File): List<LaunchEcuSystem> {
        val systems = mutableListOf<LaunchEcuSystem>()
        try {
            if (!fileSource.exists()) return emptyList()
            val bytes = fileSource.readBytes()
            val buffer = ByteBuffer.wrap(bytes).apply {
                order(ByteOrder.LITTLE_ENDIAN)
            }

            // Header (16 bytes)
            if (buffer.remaining() < 16) return emptyList()
            val magic = ByteArray(5)
            buffer.get(magic)
            val magicStr = String(magic, StandardCharsets.US_ASCII)

            val ver = ByteArray(5)
            buffer.get(ver)
            val verStr = String(ver, StandardCharsets.US_ASCII)

            val targetBrand = buffer.short.toInt() and 0xFFFF
            val systemCount = buffer.int

            Log.d(TAG, "CANBUSLIST.BIN Parsed Header - Magic: $magicStr, Ver: $verStr, Brand: $targetBrand, Count: $systemCount")

            // Read Record Array
            for (i in 0 until systemCount) {
                if (buffer.remaining() < 32) break
                val systemId = buffer.int
                val protocolIndex = buffer.int
                val rxCanId = buffer.int
                val txCanId = buffer.int
                val baudRate = buffer.int
                val mtu = buffer.int
                val securityAccessCode = buffer.int
                val nameIndex = buffer.int

                systems.add(
                    LaunchEcuSystem(
                        systemId = systemId,
                        protocolIndex = protocolIndex,
                        rxCanId = rxCanId,
                        txCanId = txCanId,
                        baudRate = baudRate,
                        mtu = mtu,
                        nameIndex = nameIndex
                    )
                )
            }
            Log.d(TAG, "Successfully parsed $systemCount dynamic ECU profiles from CANBUSLIST.BIN")
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing CANBUSLIST.BIN", e)
        }
        return systems
    }
}
