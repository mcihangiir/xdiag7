package com.example.data

import kotlinx.coroutines.flow.StateFlow

interface IOBDConnection {
    suspend fun connect(): Boolean
    suspend fun sendRawCommand(cmd: String): String
    suspend fun sendRawBytes(bytes: ByteArray): ByteArray {
        val response = sendRawCommand(String(bytes, Charsets.US_ASCII))
        return response.toByteArray(Charsets.US_ASCII)
    }
    fun disconnect()
    
    val isConnected: StateFlow<Boolean>
    val connectionState: StateFlow<ConnectionState>
    val protocolType: ProtocolType
}

enum class ConnectionState { 
    DISCONNECTED, SCANNING, CONNECTING, 
    CONNECTED, HANDSHAKE_FAILED, ERROR 
}

enum class ProtocolType { 
    CLASSIC_BT_ELM327,   // Standart ELM327, Classic Bluetooth SPP
    BLE_ELM327,          // ELM327 ama BLE üzerinden (HM-10 vb. modüller)
    BLE_PROPRIETARY,     // DS401 tarzı kapalı protokol, BLE üzerinden
    WIFI_ELM327          // Wi-Fi kullanan ELM327 adaptörleri
}
