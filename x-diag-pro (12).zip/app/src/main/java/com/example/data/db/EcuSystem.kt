package com.example.data.db

import androidx.room.*
import java.io.Serializable

@Entity(
    tableName = "ecu_systems",
    foreignKeys = [
        ForeignKey(
            entity = VehicleModel::class,
            parentColumns = ["id"],
            childColumns = ["modelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["modelId"])]
)
data class EcuSystem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val modelId: Int,
    val systemCode: String, // ECM, TCM, ABS, SRS, BCM, HVAC, EPS, TPMS, IMMO, ACC...
    val systemName: String,
    val ecuAddress: String,
    val protocol: String, // CAN, ISO9141, KWP2000, J1850
    val baudRate: Int, // 500000, 250000, 125000
    val isSupported: Boolean = true,
    val nameId: String? = null,
    val systemUid: String? = null
) : Serializable
