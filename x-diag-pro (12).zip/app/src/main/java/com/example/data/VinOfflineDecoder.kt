package com.example.data

object VinOfflineDecoder {

    // ISO 3779 Pozisyon 10 - Model Yılı Kodu (30 yıllık döngü)
    // Kaynak: ISO 3779, SAE J853, FMVSS 115 standardı
    private val yearCodeMap = mapOf(
        'A' to 2010, 'B' to 2011, 'C' to 2012, 'D' to 2013, 'E' to 2014,
        'F' to 2015, 'G' to 2016, 'H' to 2017, 'J' to 2018, 'K' to 2019,
        'L' to 2020, 'M' to 2021, 'N' to 2022, 'P' to 2023, 'R' to 2024,
        'S' to 2025, 'T' to 2026, 'V' to 2027, 'W' to 2028, 'X' to 2029,
        'Y' to 2030, '1' to 2001, '2' to 2002, '3' to 2003, '4' to 2004,
        '5' to 2005, '6' to 2006, '7' to 2007, '8' to 2008, '9' to 2009
    )
    // Not: 1980-2009 ve 2010-2039 aynı harfleri tekrar kullanır (30 yıl
    // döngüsü). Pozisyon 7'nin rakam mı harf mi olduğuna bakarak hangi
    // döngüde olduğumuzu ayırt ederiz (eski araçlarda pozisyon 7 rakamdır).

    // Bilinen WMI önekleri (ISO 3780, halka açık üretici kod listesi)
    private val wmiPrefixes = mapOf(
        "JT" to "Toyota", "JTD" to "Toyota", "JTM" to "Toyota",
        "JTN" to "Toyota", "NMT" to "Toyota (Türkiye/Avrupa)",
        "VF1" to "Renault", "VF3" to "Peugeot", "VF7" to "Citroen",
        "WVW" to "Volkswagen", "WVG" to "Volkswagen (SUV)",
        "WBA" to "BMW", "WBS" to "BMW M", "WDB" to "Mercedes-Benz",
        "WDD" to "Mercedes-Benz", "WAU" to "Audi", "TRU" to "Audi (Macaristan)",
        "WF0" to "Ford (Avrupa)", "1FA" to "Ford (ABD)", "1FT" to "Ford Truck (ABD)",
        "W0L" to "Opel/Vauxhall", "VSS" to "SEAT", "TMB" to "Skoda",
        "UU1" to "Dacia", "VF6" to "Renault (Ticari)",
        "KMH" to "Hyundai", "KNA" to "Kia", "VNK" to "Toyota (Endonezya)"
    )

    data class OfflineVinResult(
        val wmiMatch: String?,        // "Toyota" gibi olası üretici
        val modelYear: Int?,          // ISO 3779 pozisyon 10'dan kesin yıl
        val isValid: Boolean,         // 17 karakter, I/O/Q yok mu
        val checkDigitValid: Boolean? // pozisyon 9 kontrol hanesi (Kuzey Amerika VIN'leri için)
    )

    fun decode(vin: String): OfflineVinResult {
        val clean = vin.trim().uppercase()
        val isValid = clean.length == 17 && !clean.any { it in "IOQ" }
        
        val wmi3 = if (clean.length >= 3) clean.substring(0, 3) else ""
        val wmi2 = if (clean.length >= 2) clean.substring(0, 2) else ""
        val wmiMatch = wmiPrefixes[wmi3] ?: wmiPrefixes[wmi2]

        val yearChar = if (clean.length >= 10) clean[9] else null
        val modelYear = yearChar?.let { yearCodeMap[it] }

        val checkDigitValid = if (isValid && clean.length == 17) {
            try { validateCheckDigit(clean) } catch (e: Exception) { null }
        } else null

        return OfflineVinResult(wmiMatch, modelYear, isValid, checkDigitValid)
    }

    // ISO 3779 / FMVSS 115 check digit algoritması (pozisyon 9)
    private fun validateCheckDigit(vin: String): Boolean {
        val transliteration = mapOf(
            'A' to 1,'B' to 2,'C' to 3,'D' to 4,'E' to 5,'F' to 6,'G' to 7,'H' to 8,
            'J' to 1,'K' to 2,'L' to 3,'M' to 4,'N' to 5,'P' to 7,'R' to 9,
            'S' to 2,'T' to 3,'U' to 4,'V' to 5,'W' to 6,'X' to 7,'Y' to 8,'Z' to 9
        )
        val weights = intArrayOf(8,7,6,5,4,3,2,10,0,9,8,7,6,5,4,3,2)
        var sum = 0
        for (i in vin.indices) {
            val c = vin[i]
            val value = if (c.isDigit()) c.digitToInt() else (transliteration[c] ?: 0)
            sum += value * weights[i]
        }
        val remainder = sum % 11
        val expectedChar = if (remainder == 10) 'X' else ('0' + remainder)
        return vin[8] == expectedChar
    }
}
