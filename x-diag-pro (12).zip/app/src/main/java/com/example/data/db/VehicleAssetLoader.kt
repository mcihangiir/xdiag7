package com.example.data.db

import android.content.Context
import android.util.Log
import com.example.data.AppDatabase
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object VehicleAssetLoader {
    private const val TAG = "VehicleAssetLoader"

    suspend fun loadAssetsVehicles(context: Context, db: AppDatabase) {
        val assetManager = context.assets
        try {
            // "vehicles" adındaki klasörü listele
            val fileList = assetManager.list("vehicles") ?: return
            Log.d(TAG, "assets/vehicles/ içinde ${fileList.size} adet dosya tespit edildi.")
            for (fileName in fileList) {
                if (fileName.endsWith(".json")) {
                    Log.d(TAG, "Dinamik araç dosyası yükleniyor: $fileName")
                    val inputStream = assetManager.open("vehicles/$fileName")
                    val reader = BufferedReader(InputStreamReader(inputStream))
                    val jsonStr = reader.use { it.readText() }
                    
                    parseAndInsertVehicleJson(jsonStr, db)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Araç assetleri yüklenirken hata oluştu", e)
        }
    }

    private suspend fun parseAndInsertVehicleJson(jsonStr: String, db: AppDatabase) {
        try {
            val json = JSONObject(jsonStr)
            val brandName = json.getString("brand")
            val region = json.optString("region", "ASIA")
            val logoUrl = json.optString("logo", null)
            
            val brandDao = db.vehicleBrandDao()
            val modelDao = db.vehicleModelDao()
            val ecuDao = db.ecuSystemDao()
            val pidDao = db.livePidDefinitionDao()

            // 1. Markayı Veritabanına Ekle veya Getir
            var brand = brandDao.getByName(brandName)
            val brandId = if (brand == null) {
                val newBrand = VehicleBrand(
                    name = brandName,
                    nameLocal = brandName,
                    region = region,
                    logoUrl = logoUrl,
                    isPopular = true,
                    sortOrder = 99
                )
                brandDao.insert(newBrand).toInt()
            } else {
                brand.id
            }

            // 2. Modelleri ve ECU Sistemlerini Parset
            if (json.has("example_models")) {
                val modelsArr = json.getJSONArray("example_models")
                for (i in 0 until modelsArr.length()) {
                    val modelObj = modelsArr.getJSONObject(i)
                    val modelName = modelObj.getString("model")
                    val generation = modelObj.optString("generation", "")
                    val year = modelObj.optInt("year", 2016)
                    
                    val vinValue = modelObj.optString("vin", null)
                    val registrationDate = modelObj.optString("registrationDate", null)
                    val colorValue = modelObj.optString("color", null)
                    val engineNumber = modelObj.optString("engineNumber", null)
                    val typeValue = modelObj.optString("type", null)
                    val ecuTypeValue = modelObj.optString("ecu_type", null)
                    
                    // Arac Modelini Ekle
                    val vehicleModel = VehicleModel(
                        brandId = brandId,
                        name = modelName,
                        nameLocal = "$modelName ($generation)",
                        yearStart = year - 2,
                        yearEnd = year + 4,
                        engineCodes = "[\"${modelObj.optString("engine", "")}\"]",
                        bodyTypes = "[\"Sedan/Hatchback\"]",
                        vin = vinValue,
                        registrationDate = registrationDate,
                        color = colorValue,
                        engineNumber = engineNumber,
                        type = typeValue,
                        generation = generation,
                        ecuType = ecuTypeValue
                    )
                    val modelId = modelDao.insert(vehicleModel).toInt()

                    // 3. Modüle Ait Sistemleri (ECU'ları) Ekle
                    if (modelObj.has("systems")) {
                        val systemsArr = modelObj.getJSONArray("systems")
                        for (j in 0 until systemsArr.length()) {
                            val sysObj = systemsArr.getJSONObject(j)
                            val sysId = sysObj.getString("sys_id")
                            val sysName = sysObj.getString("name")
                            val address = sysObj.optString("address", "0x7E0")
                            
                            val ecuSystem = EcuSystem(
                                modelId = modelId,
                                systemCode = sysId.uppercase(),
                                systemName = sysName,
                                ecuAddress = address,
                                protocol = "CAN",
                                baudRate = 500000,
                                isSupported = true
                            )
                            ecuDao.insert(ecuSystem)

                            // 4. Enhanced PIDs Ekle
                            if (sysObj.has("enhanced_pids")) {
                                val pidsArr = sysObj.getJSONArray("enhanced_pids")
                                for (k in 0 until pidsArr.length()) {
                                    val pidObj = pidsArr.getJSONObject(k)
                                    val pidCode = pidObj.getString("pid")
                                    val pidName = pidObj.getString("name")
                                    val unit = pidObj.optString("unit", "")
                                    val formula = pidObj.optString("formula", "")

                                    val pidDefinition = LivePidDefinition(
                                        pid = pidCode,
                                        name = pidName,
                                        nameEn = pidName,
                                        unit = unit,
                                        formula = formula,
                                        minValue = 0f,
                                        maxValue = 1000f,
                                        mode = "21",
                                        brandId = brandId,
                                        isDefault = false
                                    )
                                    pidDao.insert(pidDefinition)
                                }
                            }
                        }
                    }
                }
            }
            Log.d(TAG, "Dinamik araç veritabanı başarıyla senkronize edildi: $brandName")
        } catch (e: Exception) {
            Log.e(TAG, "Araca ait JSON yüklenirken hata oluştu", e)
        }
    }

    suspend fun downloadAndSyncVehiclesFromCloud(context: Context, db: AppDatabase): Result<Int> {
        return withContext(Dispatchers.IO) {
            try {
                // Sadece direkt indirme linki
                val urlConnection = URL("https://docs.google.com/uc?export=download&id=1qTjk3wYord3pPioW0Ng-Hv9OJSy38V92").openConnection() as HttpURLConnection
                urlConnection.connectTimeout = 15000
                urlConnection.readTimeout = 15000
                urlConnection.requestMethod = "GET"
                
                val statusCode = urlConnection.responseCode
                Log.d(TAG, "Bulut indirme HTTP durum kodu: $statusCode")
                if (statusCode != HttpURLConnection.HTTP_OK) {
                    return@withContext Result.failure(Exception("HTTP hata kodu: $statusCode"))
                }
                
                val jsonStr = urlConnection.inputStream.bufferedReader().use { it.readText() }
                if (jsonStr.isBlank()) {
                    return@withContext Result.failure(Exception("Gelen veri boş."))
                }
                
                var brandCount = 0
                val trimmed = jsonStr.trim()
                if (trimmed.startsWith("[")) {
                    val array = org.json.JSONArray(trimmed)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        parseAndInsertVehicleJson(obj.toString(), db)
                        brandCount++
                    }
                } else if (trimmed.startsWith("{")) {
                    val json = org.json.JSONObject(trimmed)
                    if (json.has("brands")) {
                        val array = json.getJSONArray("brands")
                        for (i in 0 until array.length()) {
                            val obj = array.getJSONObject(i)
                            parseAndInsertVehicleJson(obj.toString(), db)
                            brandCount++
                        }
                    } else if (json.has("brand")) {
                        parseAndInsertVehicleJson(trimmed, db)
                        brandCount++
                    } else if (json.has("example_models")) {
                        // Eğer dosya doğrudan bir Toyota benzeri tek şema barındırıyor ancak brand ismi mevcutsa
                        parseAndInsertVehicleJson(trimmed, db)
                        brandCount++
                    } else {
                        return@withContext Result.failure(Exception("Bilinmeyen JSON şeması."))
                    }
                } else {
                    return@withContext Result.failure(Exception("Geçersiz JSON formatı."))
                }
                
                val prefs = context.getSharedPreferences("vehicle_db_sync", Context.MODE_PRIVATE)
                prefs.edit()
                    .putBoolean("is_synced", true)
                    .putLong("last_sync_time", System.currentTimeMillis())
                    .putInt("synced_brand_count", brandCount)
                    .apply()
                
                Result.success(brandCount)
            } catch (e: Exception) {
                Log.e(TAG, "Bulut senkronizasyonu hatası", e)
                Result.failure(e)
            }
        }
    }
}
