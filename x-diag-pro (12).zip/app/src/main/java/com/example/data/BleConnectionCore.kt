package com.example.data

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID
import kotlin.coroutines.resume

class BleConnectionCore(private val context: Context) {

    private val bluetoothManager = context.getSystemService(BluetoothManager::class.java)
    private val bleScanner: BluetoothLeScanner? = bluetoothManager?.adapter?.bluetoothLeScanner
    var bluetoothGatt: BluetoothGatt? = null
    var negotiatedMtu: Int = 23  // varsayılan BLE MTU

    private val _scannedDevices = MutableStateFlow<List<BleDeviceInfo>>(emptyList())
    val scannedDevices: StateFlow<List<BleDeviceInfo>> = _scannedDevices

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _discoveredServices = MutableStateFlow<List<BluetoothGattService>>(emptyList())
    val discoveredServices: StateFlow<List<BluetoothGattService>> = _discoveredServices

    data class BleDeviceInfo(val device: BluetoothDevice, val name: String, val address: String, val rssi: Int)

    // ─── TARAMA ───
    @SuppressLint("MissingPermission")
    fun startScan(durationMs: Long = 10000L) {
        _scannedDevices.value = emptyList()
        _connectionState.value = ConnectionState.SCANNING

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val info = BleDeviceInfo(
                    device = result.device,
                    name = result.device.name ?: result.scanRecord?.deviceName ?: "Bilinmeyen",
                    address = result.device.address,
                    rssi = result.rssi
                )
                val current = _scannedDevices.value
                if (current.none { it.address == info.address }) {
                    _scannedDevices.value = (current + info).sortedByDescending { it.rssi }
                }
            }
            override fun onScanFailed(errorCode: Int) {
                _connectionState.value = ConnectionState.ERROR
            }
        }
        activeScanCallback = callback
        bleScanner?.startScan(emptyList(), ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), callback)

        CoroutineScope(Dispatchers.Main).launch {
            delay(durationMs)
            stopScan()
        }
    }

    private var activeScanCallback: ScanCallback? = null

    @SuppressLint("MissingPermission")
    fun stopScan() {
        activeScanCallback?.let { bleScanner?.stopScan(it) }
        activeScanCallback = null
        if (_connectionState.value == ConnectionState.SCANNING) {
            _connectionState.value = ConnectionState.DISCONNECTED
        }
    }

    // ─── BAĞLANTI + SERVİS KEŞFİ + MTU NEGOTIATION ───
    @SuppressLint("MissingPermission")
    suspend fun connectAndDiscover(device: BluetoothDevice): Boolean =
        suspendCancellableCoroutine { cont ->
            _connectionState.value = ConnectionState.CONNECTING

            val gattCallback = object : BluetoothGattCallback() {
                override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                    when (newState) {
                        BluetoothProfile.STATE_CONNECTED -> {
                            gatt.requestMtu(247)
                        }
                        BluetoothProfile.STATE_DISCONNECTED -> {
                            _connectionState.value = ConnectionState.DISCONNECTED
                            if (cont.isActive) cont.resume(false)
                        }
                    }
                }

                override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
                    negotiatedMtu = if (status == BluetoothGatt.GATT_SUCCESS) mtu else 23
                    gatt.discoverServices()
                }

                override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                    if (status == BluetoothGatt.GATT_SUCCESS) {
                        _discoveredServices.value = gatt.services
                        _connectionState.value = ConnectionState.CONNECTED
                        bluetoothGatt = gatt
                        if (cont.isActive) cont.resume(true)
                    } else {
                        _connectionState.value = ConnectionState.ERROR
                        if (cont.isActive) cont.resume(false)
                    }
                }

                @Deprecated("Android 12 ve altı için")
                override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                    onCharacteristicChangedInternal(characteristic, characteristic.value)
                }

                override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                    onCharacteristicChangedInternal(characteristic, value)
                }
            }

            device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        }

    var onDataReceived: ((characteristicUuid: String, data: ByteArray) -> Unit)? = null

    private fun onCharacteristicChangedInternal(characteristic: BluetoothGattCharacteristic, value: ByteArray) {
        onDataReceived?.invoke(characteristic.uuid.toString(), value)
    }

    // ─── PARÇALI VERİ YAZMA ───
    @SuppressLint("MissingPermission")
    fun writeChunked(characteristic: BluetoothGattCharacteristic, data: ByteArray) {
        val gatt = bluetoothGatt ?: return
        val chunkSize = negotiatedMtu - 3
        if (data.size <= chunkSize) {
            characteristic.value = data
            characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            gatt.writeCharacteristic(characteristic)
        } else {
            data.toList().chunked(chunkSize).forEach { chunk ->
                characteristic.value = chunk.toByteArray()
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                gatt.writeCharacteristic(characteristic)
                Thread.sleep(20)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
        _connectionState.value = ConnectionState.DISCONNECTED
    }
}
