package com.example.data

import android.content.Context
import android.util.Log

object FuncDataParser {
    private const val TAG = "FuncDataParser"

    fun parseAdaptations(context: Context): List<String> {
        Log.d(TAG, "Parsing adaptation function records...")
        return listOf(
            "Gaz Kelebeği Temel Ayarı (Throttle Adaptation)",
            "Direksiyon Açı Sensörü Sıfırlama (SAS Calibration)",
            "Akü Eşleştirme / Değişim Resetleme (BMS Reset)",
            "EGR Valfi Adaptasyonu (EGR Calibration)"
        )
    }

    fun parseCodings(context: Context): List<String> {
        Log.d(TAG, "Parsing coding configuration records...")
        return listOf(
            "Enjektör Sınıf Programlama (C2I / IMA Codes)",
            "Hız Limitleyici Sınırı (VMAX Limit)"
        )
    }
}
