# Launch X431 / X-DIAG Toyota V49.50 Binary Database Placement Guide

This directory holds the professional, vehicle-specific physical databases containing ECU binary frames, custom sensor registers, and trouble code configs parsed byte-by-byte by X-DIAG Pro's `EcuBinaryParser` interface.

## Recommended Assets Structure

To load your physical X-DIAG or Launch scanner database dumps, place your decrypted software files under this exact directory:

```
src/main/assets/toyota_v49/
├── README.md                           # This instructional file
├── CARNAME.BIN                         # Main vehicle brand translation module
├── DTCH_CFG.BIN                        # Global diagnostic fault-mapping definitions
├── FUNCDATA_EU.BIN                     # European target values and sensor parameters
├── INI_CONFIGS.ini                     # Peripheral parameters and adapter settings
├── ecu_data_0x1000.bin                 # EFI Engine Control ECU binary configuration
├── ecu_data_0x1001.bin                 # ECT Automatic Transmission ECU configuration
├── ecu_data_0x2000.bin                 # ABS/VSC Stability Control ECU configuration
├── ecu_data_0x3000.bin                 # SRS Airbag safety module configuration
├── ecu_data_0x4000.bin                 # EMPS/EPS Electric Steering module configuration
├── ... (other physical ECU addresses matching ToyotaV49Database.kt index)
└── ecu_data_0xE001.bin                 # HUD Head-Up Display controller configuration
```

## Binary File Protocol

The parser reads files as little-endian `ByteBuffer` streams with a structured 120-byte magic header prefix:

1. **Magic Frame Identifier (5 bytes):** `XDIAG` (ASCII block)
2. **Database Version (6 bytes):** `V49.50` (ASCII block)
3. **Database Target ECU (2 bytes):** Short Unsigned ECU Address (e.g. `0x1000`)
4. **Target System Identifier (32 bytes):** UTF-8 encoded full controller name.
5. **Offsets Matrix:**
   - Parameter PIDs offset: `4 bytes` (Int)
   - Parameter PIDs count: `4 bytes` (Int)
   - Trouble codes offset: `4 bytes` (Int)
   - Trouble codes count: `4 bytes` (Int)
   - Service operations offset: `4 bytes` (Int)
   - Service operations count: `4 bytes` (Int)

*If a file is missing or physical asset loading is bypassed, the system uses the high-fidelity dynamic emulator in `EcuBinaryParser` which dynamically compiles and resolves identical memory frames to prevent runtime crashes.*
