package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ParserUnitTest {

    @Test
    fun `test EcuDataParser with simulated binary generation`() {
        val ecuCode = 0x1000
        val binaryBytes = EcuDataParser.createSimulatedBinary(ecuCode)
        assertNotNull("Generated simulated binary should not be null", binaryBytes)
        assertTrue("Generated simulated binary should contain bytes", binaryBytes.isNotEmpty())

        val parsedData = EcuDataParser.parse(ecuCode, binaryBytes)
        assertNotNull("Parsed ECU Data should not be null", parsedData)
        assertEquals("ECU code should match", ecuCode, parsedData.header.ecuCode)
        assertEquals("Magic word should match", "XDIAG", parsedData.header.magic)
        assertTrue("PIDs list should be populated", parsedData.pids.isNotEmpty())
        assertTrue("DTCs list should be populated", parsedData.dtcs.isNotEmpty())
        assertTrue("Special functions should be populated", parsedData.specialFunctions.isNotEmpty())

        val rpmPid = parsedData.pids.find { it.hexCode == "010C" }
        assertNotNull("Should contain RPM PID", rpmPid)
        assertEquals("Motor Devri", rpmPid?.dscTr)
    }

    @Test
    fun `test FuncDataParser provides available actions`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val adaptations = FuncDataParser.parseAdaptations(context)
        val codings = FuncDataParser.parseCodings(context)

        assertNotNull("Adaptations list should not be null", adaptations)
        assertNotNull("Codings list should not be null", codings)
        assertTrue("Adaptations should contain Throttle", adaptations.any { it.contains("Throttle") })
        assertTrue("Codings should contain Injector coding", codings.any { it.contains("Enjektör") })
    }

    @Test
    fun `test CarNameParser empty file handling`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempFile = File(context.cacheDir, "temp_empty_carname.bin")
        if (tempFile.exists()) tempFile.delete()

        val results = CarNameParser.parse(context, tempFile)
        assertTrue("Parsing a missing file should result in an empty map", results.isEmpty())
    }

    @Test
    fun `test CanBusListParser empty file handling`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempFile = File(context.cacheDir, "temp_empty_canbus.bin")
        if (tempFile.exists()) tempFile.delete()

        val results = CanBusListParser.parse(context, tempFile)
        assertTrue("Parsing a missing file should result in an empty list", results.isEmpty())
    }

    @Test
    fun `test DtcCfgParser empty file handling`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempFile = File(context.cacheDir, "temp_empty_dtccfg.bin")
        if (tempFile.exists()) tempFile.delete()

        val results = DtcCfgParser.parse(context, tempFile)
        assertTrue("Parsing a missing file should result in an empty map", results.isEmpty())
    }
}
